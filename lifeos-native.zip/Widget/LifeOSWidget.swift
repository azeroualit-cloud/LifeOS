import SwiftUI
import WidgetKit

struct QuickActionsEntry: TimelineEntry { let date: Date }
struct QuickActionsProvider: TimelineProvider {
    func placeholder(in context: Context) -> QuickActionsEntry { QuickActionsEntry(date: .now) }
    func getSnapshot(in context: Context, completion: @escaping (QuickActionsEntry) -> Void) { completion(QuickActionsEntry(date: .now)) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<QuickActionsEntry>) -> Void) {
        completion(Timeline(entries: [QuickActionsEntry(date: .now)], policy: .never))
    }
}
struct QuickActionsView: View {
    @Environment(\.widgetFamily) private var family
    var body: some View {
        VStack(alignment: .leading) {
            Label("Life OS", systemImage: "square.grid.2x2").font(.headline)
            Spacer()
            if family == .systemSmall {
                Label("Nuova attività", systemImage: "plus.circle").font(.title3)
                Text("Tocca per aggiungere").font(.caption).foregroundStyle(.secondary)
            } else {
                HStack {
                    action("Attività", symbol: "plus.circle", route: "task")
                    Spacer()
                    action("Peso", symbol: "scalemass", route: "weight")
                    Spacer()
                    action("Calendario", symbol: "calendar", route: "calendar")
                }
            }
        }.widgetURL(family == .systemSmall ? URL(string: "lifeos://task") : nil)
        .containerBackground(.fill.tertiary, for: .widget)
    }
    private func action(_ title: String, symbol: String, route: String) -> some View {
        Link(destination: URL(string: "lifeos://" + route)!) {
            VStack { Image(systemName: symbol).font(.title2); Text(title).font(.caption) }
        }.accessibilityLabel(title)
    }
}
@main struct LifeOSQuickActionsWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "LifeOSQuickActions", provider: QuickActionsProvider()) { _ in QuickActionsView() }
            .configurationDisplayName("Life OS · Azioni rapide")
            .description("Apri una nuova attività, registra il peso o consulta il calendario.")
            .supportedFamilies([.systemSmall, .systemMedium])
    }
}
