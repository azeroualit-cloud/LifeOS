import SwiftUI

enum NativeDesign {
    // Platinum is an interaction colour. Shift colours retain their own meaning.
    static let accent = Color(uiColor: UIColor { trait in
        trait.userInterfaceStyle == .dark ? UIColor(white: 0.87, alpha: 1) : UIColor(white: 0.23, alpha: 1)
    })
    static let canvas = Color(uiColor: UIColor { $0.userInterfaceStyle == .dark ? UIColor(white: 0.045, alpha: 1) : .systemGroupedBackground })
    static let surface = Color(uiColor: .secondarySystemGroupedBackground)
    static let secondary = Color(uiColor: UIColor { traits in
        UIColor(white: traits.userInterfaceStyle == .dark ? 0.68 : 0.37, alpha: 1)
    })
    static let inset = Color.primary.opacity(0.045)
    // Financial direction only: red = outflow/decline, green = available/inflow/growth.
    static let financialRed = Color(uiColor: UIColor { trait in
        trait.userInterfaceStyle == .dark ? UIColor(red: 0.83, green: 0.57, blue: 0.56, alpha: 1) : UIColor(red: 0.63, green: 0.29, blue: 0.28, alpha: 1)
    })
    static let financialGreen = Color(uiColor: UIColor { trait in
        trait.userInterfaceStyle == .dark ? UIColor(red: 0.55, green: 0.73, blue: 0.63, alpha: 1) : UIColor(red: 0.22, green: 0.45, blue: 0.33, alpha: 1)
    })
    static let gap: CGFloat = 16
    static let cardRadius: CGFloat = 24
    static let controlRadius: CGFloat = 12
    static let dayRadius: CGFloat = 12
    static let badgeRadius: CGFloat = 6
    static let heading = Font.system(.headline, weight: .semibold)
    static let value = Font.system(.title, weight: .semibold)
    static let body = Font.system(.body, weight: .regular)
    static let metadata = Font.system(.footnote, weight: .regular)
    static let symbol = Font.system(size: 18, weight: .medium)
}
struct NativeSurface: ViewModifier {
    var material = false
    @ViewBuilder
    func body(content: Content) -> some View {
        if material {
            content.background(.regularMaterial, in: RoundedRectangle(cornerRadius: NativeDesign.cardRadius, style: .continuous))
        } else {
            content.background(NativeDesign.surface.opacity(0.94), in: RoundedRectangle(cornerRadius: NativeDesign.cardRadius, style: .continuous))
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: NativeDesign.cardRadius, style: .continuous))
        }
    }
}
struct NativePressStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.opacity(configuration.isPressed ? 0.75 : 1)
            .scaleEffect(configuration.isPressed && !reduceMotion ? 0.985 : 1)
            .animation(reduceMotion ? nil : .easeOut(duration: 0.18), value: configuration.isPressed)
    }
}
struct NativeCard<Content: View>: View {
    let content: Content
    var material = false
    init(material: Bool = false, @ViewBuilder content: () -> Content) { self.material = material; self.content = content() }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) { content }
            .frame(maxWidth: .infinity, alignment: .leading).padding(16)
            .modifier(NativeSurface(material: material))
    }
}
struct NativeRoutineAppearance: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.buttonStyle(.glass).buttonBorderShape(.roundedRectangle(radius: NativeDesign.controlRadius))
        } else {
            content.buttonStyle(.bordered).buttonBorderShape(.roundedRectangle(radius: NativeDesign.controlRadius))
        }
    }
}
struct NativeIcon: View {
    let name: String
    var color: Color = NativeDesign.accent
    var body: some View {
        Image(systemName: name).symbolVariant(.none).symbolRenderingMode(.monochrome).font(NativeDesign.symbol)
            .foregroundStyle(color).frame(width: 38, height: 38)
            .background(NativeDesign.inset, in: RoundedRectangle(cornerRadius: NativeDesign.controlRadius, style: .continuous))
            .accessibilityHidden(true)
    }
}
struct NativeSectionHeading: View {
    let title: String
    var body: some View { Text(title).font(.headline).frame(maxWidth: .infinity, alignment: .leading) }
}
struct NativeNavigationLabel: View {
    let title: String
    let symbol: String
    var body: some View {
        HStack(spacing: 10) {
            NativeIcon(name: symbol)
            Text(title).font(NativeDesign.body)
        }
    }
}
struct NativeListAppearance: ViewModifier {
    func body(content: Content) -> some View {
        content.listStyle(.insetGrouped).listSectionSpacing(NativeDesign.gap)
            .font(NativeDesign.body).environment(\.defaultMinListRowHeight, 52)
            .contentMargins(.horizontal, 16, for: .scrollContent)
            .listRowSpacing(0).contentMargins(.top, 8, for: .scrollContent).contentMargins(.bottom, 24, for: .scrollContent).scrollBounceBehavior(.basedOnSize)
            .scrollContentBackground(.hidden).background(NativeDesign.canvas)
    }
}
struct NativeGlass: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) { content.glassEffect(.regular.interactive(), in: Capsule()) }
        else { content.background(.regularMaterial, in: Capsule()) }
    }
}
struct NativeTabAppearance: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) { content.tabBarMinimizeBehavior(.never) }
        else { content }
    }
}
struct NativeConnectionBadge: View {
    @EnvironmentObject var store: NativeStore
    private var text: String {
        if store.isDemo { return "Demo" }
        if store.busy { return "Aggiornamento" }
        if !store.state.pending.isEmpty { return "\(store.state.pending.count) in coda" }
        if !store.syncStatus.isEmpty && store.syncStatus != "Aggiornato" { return "Da aggiornare" }
        return store.sharedDatabase ? "Condiviso con il sito" : store.server == nil ? "Sul dispositivo" : "Collegato"
    }
    var body: some View {
        HStack(spacing: 6) {
            if store.busy { ProgressView().controlSize(.mini) }
            else { Circle().fill(store.isDemo || !store.state.pending.isEmpty || (!store.syncStatus.isEmpty && store.syncStatus != "Aggiornato") ? Color.orange : Color.green).frame(width: 6, height: 6) }
            Text(text).font(.caption.weight(.medium)).lineLimit(1)
        }.foregroundStyle(NativeDesign.secondary).padding(.horizontal, 12).padding(.vertical, 8)
            .background(NativeDesign.surface, in: Capsule()).accessibilityElement(children: .combine)
    }
}
struct NativeBudgetHero: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dynamicTypeSize) private var typeSize
    @AppStorage("native-hide-money") private var hidden = false
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Label { Text("Budget rimanente") } icon: { NativeIcon(name: "wallet.bifold") }.font(NativeDesign.heading).fixedSize(horizontal: false, vertical: true)
                Spacer()
                Button { hidden.toggle() } label: {
                    Image(systemName: hidden ? "eye.slash" : "eye").font(NativeDesign.symbol).foregroundStyle(NativeDesign.accent).frame(width: 44, height: 44)
                }.buttonStyle(.plain).accessibilityLabel(hidden ? "Mostra importi" : "Nascondi importi")
            }
            Group {
                if hidden { Text("•••• €") }
                else if store.summary["monthlyRemaining"] != nil { Text(store.summary.amount("monthlyRemaining").euro).contentTransition(.numericText()) }
                else { Text("Da aggiornare") }
            }.font(NativeDesign.value).monospacedDigit().minimumScaleFactor(0.6).lineLimit(1)
            if !hidden, store.summary["monthlyRemaining"] != nil, store.financeMonth < CivilDate.month() {
                Text("Mese concluso · riepilogo del budget").font(.caption).foregroundStyle(NativeDesign.secondary)
            }
            if !hidden, store.summary["monthlyRemaining"] != nil, NativeValidation.dailyBudget(store.summary, month: store.financeMonth).days > 0 {
                let daily = NativeValidation.dailyBudget(store.summary, month: store.financeMonth)
                if typeSize.isAccessibilitySize {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("Al giorno").font(.caption)
                        Text("\(daily.low.euro) – \(daily.high.euro)").font(.subheadline.weight(.semibold)).monospacedDigit()
                        Text("\(daily.days) giorni rimasti").font(.caption)
                    }
                } else { HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 4) { Text("Al giorno").font(.caption); Text("\(daily.low.euro) – \(daily.high.euro)").font(.subheadline.weight(.semibold)).monospacedDigit() }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 4) { Text(store.financeMonth == CivilDate.month() ? "Incluso oggi" : "Giorni del mese").font(.caption); Text(String(daily.days)).font(.subheadline.weight(.semibold)) }
                } }
            }
            if !hidden { NativeBudgetAllocation(summary: store.summary) }
        }.foregroundStyle(Color.primary).padding(20)
            .modifier(NativeSurface())
            .accessibilityIdentifier("budget-hero")
    }
}

/// A separate primary action leaves all four destinations visible, including on compact phones.
struct NativeBottomNavigation: View {
    @EnvironmentObject var router: NativeRouter
    @Environment(\.dynamicTypeSize) private var typeSize
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let addLabel: String
    let add: () -> Void
    private let destinations: [(NativeTab, String, String, String)] = [
        (.dashboard, "Dashboard", "square.grid.2x2", "dashboard"),
        (.tasks, "Attività", "checklist", "tasks"),
        (.calendar, "Calendario", "calendar", "calendar"),
        (.finance, "Finanza", "chart.bar", "finance")
    ]
    var body: some View {
        HStack(spacing: 12) {
            HStack(spacing: 0) {
                ForEach(destinations, id: \.0) { destination in
                    let selected = router.tab == destination.0
                    Button { router.tab = destination.0 } label: {
                        VStack(spacing: 3) {
                            Image(systemName: destination.2).font(.title3.weight(.regular))
                            if !typeSize.isAccessibilitySize {
                                Text(destination.1).font(.caption2.weight(selected ? .semibold : .regular))
                                    .lineLimit(1).minimumScaleFactor(0.75)
                            }
                        }.frame(maxWidth: .infinity).frame(height: 52)
                            .foregroundStyle(selected ? Color.primary : NativeDesign.secondary)
                            .background(selected ? NativeDesign.accent.opacity(0.14) : Color.clear, in: Capsule())
                            .contentShape(Capsule())
                    }.buttonStyle(.plain)
                        .accessibilityLabel(destination.1).accessibilityIdentifier("tab-" + destination.3)
                        .accessibilityAddTraits(selected ? .isSelected : [])
                }
            }.padding(4).modifier(NativeGlass())
            Button(action: add) {
                Image(systemName: "plus").font(.title.weight(.regular)).frame(width: 60, height: 60)
                    .contentShape(Circle())
            }.buttonStyle(NativePressStyle()).foregroundStyle(NativeDesign.accent)
                .modifier(NativeGlass()).accessibilityLabel(addLabel).accessibilityIdentifier("primary-add")
        }.padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 8)
            .animation(reduceMotion ? nil : .easeOut(duration: 0.16), value: router.tab)
    }
}
