import SwiftUI

enum NativeDesign {
    static let accent = Color(uiColor: UIColor { trait in
        trait.userInterfaceStyle == .dark ? UIColor(red: 0.65, green: 0.69, blue: 0.94, alpha: 1) : UIColor(red: 0.34, green: 0.37, blue: 0.61, alpha: 1)
    })
    static let canvas = Color(uiColor: UIColor { $0.userInterfaceStyle == .dark ? UIColor(red: 0.045, green: 0.047, blue: 0.055, alpha: 1) : .systemGroupedBackground })
    static let surface = Color(uiColor: .secondarySystemGroupedBackground)
}
struct NativeCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) { content }
            .frame(maxWidth: .infinity, alignment: .leading).padding(16)
            .background(NativeDesign.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(Color.primary.opacity(0.06), lineWidth: 0.5))
    }
}
struct NativeIcon: View {
    let name: String
    var color: Color = NativeDesign.accent
    var body: some View {
        Image(systemName: name).font(.system(size: 17, weight: .semibold))
            .foregroundStyle(color).frame(width: 38, height: 38)
            .background(color.opacity(0.12), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
            .accessibilityHidden(true)
    }
}
struct NativeSectionHeading: View {
    let title: String
    var body: some View { Text(title).font(.headline).frame(maxWidth: .infinity, alignment: .leading) }
}
struct NativeListAppearance: ViewModifier {
    func body(content: Content) -> some View {
        content.listStyle(.insetGrouped).listSectionSpacing(14)
            .listRowSpacing(0).contentMargins(.top, 8, for: .scrollContent).contentMargins(.bottom, 24, for: .scrollContent).scrollBounceBehavior(.basedOnSize)
            .scrollContentBackground(.hidden).background(NativeDesign.canvas)
    }
}
struct NativeGlass: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) { content.glassEffect(.regular.interactive(), in: Capsule()) }
        else { content.background(.regularMaterial, in: Capsule()) }
    }
}
struct NativeTabAppearance: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) { content.tabBarMinimizeBehavior(.never) }
        else { content }
    }
}
struct NativeConnectionBadge: View {
    @EnvironmentObject var store: NativeStore
    private var text: String {
        if store.isDemo { return "Demo" }
        if store.busy { return "Aggiornamento" }
        if !store.state.pending.isEmpty { return "\(store.state.pending.count) in coda" }
        if !store.syncStatus.isEmpty && store.syncStatus != "Aggiornato" { return "Da aggiornare" }
        return store.sharedDatabase ? "Condiviso con il sito" : store.server == nil ? "Sul dispositivo" : "Collegato"
    }
    var body: some View {
        HStack(spacing: 6) {
            if store.busy { ProgressView().controlSize(.mini) }
            else { Circle().fill(store.isDemo || !store.state.pending.isEmpty || (!store.syncStatus.isEmpty && store.syncStatus != "Aggiornato") ? Color.orange : Color.green).frame(width: 6, height: 6) }
            Text(text).font(.caption.weight(.medium)).lineLimit(1)
        }.foregroundStyle(Color.secondary).padding(.horizontal, 12).padding(.vertical, 8)
            .background(NativeDesign.surface, in: Capsule()).accessibilityElement(children: .combine)
    }
}
struct NativeBudgetHero: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dynamicTypeSize) private var typeSize
    @AppStorage("native-hide-money") private var hidden = false
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("Budget rimanente", systemImage: "chart.pie.fill").font(.subheadline.weight(.medium)).fixedSize(horizontal: false, vertical: true)
                Spacer()
                Button { hidden.toggle() } label: {
                    Image(systemName: hidden ? "eye.slash" : "eye").frame(width: 36, height: 36)
                }.buttonStyle(.plain).modifier(NativeGlass()).accessibilityLabel(hidden ? "Mostra importi" : "Nascondi importi")
            }
            Group {
                if hidden { Text("•••• €") }
                else if store.summary["monthlyRemaining"] != nil { Text(store.summary.amount("monthlyRemaining").euro).contentTransition(.numericText()) }
                else { Text("Da aggiornare") }
            }.font(.system(.title, weight: .semibold)).monospacedDigit().minimumScaleFactor(0.6).lineLimit(1)
            if !hidden, store.summary["monthlyRemaining"] != nil, store.financeMonth < CivilDate.month() {
                Text("Mese concluso · riepilogo del budget").font(.caption).foregroundStyle(Color.secondary)
            }
            if !hidden, store.summary["monthlyRemaining"] != nil, NativeValidation.dailyBudget(store.summary, month: store.financeMonth).days > 0 {
                let daily = NativeValidation.dailyBudget(store.summary, month: store.financeMonth)
                if typeSize.isAccessibilitySize {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("Al giorno").font(.caption)
                        Text("\(daily.low.euro) – \(daily.high.euro)").font(.subheadline.weight(.semibold)).monospacedDigit()
                        Text("\(daily.days) giorni rimasti").font(.caption)
                    }
                } else { HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 4) { Text("Al giorno").font(.caption); Text("\(daily.low.euro) – \(daily.high.euro)").font(.subheadline.weight(.semibold)).monospacedDigit() }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 4) { Text(store.financeMonth == CivilDate.month() ? "Incluso oggi" : "Giorni del mese").font(.caption); Text(String(daily.days)).font(.subheadline.weight(.semibold)) }
                } }
            }
        }.foregroundStyle(Color.primary).padding(16)
            .background(NativeDesign.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(Color.primary.opacity(0.06), lineWidth: 0.5))
            .accessibilityIdentifier("budget-hero")
    }
}
