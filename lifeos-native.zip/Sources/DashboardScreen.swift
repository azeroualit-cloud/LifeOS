import SwiftUI

struct DashboardScreen: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    @AppStorage("native-hide-money") private var hidden = false
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(CivilDate.label(CivilDate.day()).capitalized).font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                        if !store.weather.isEmpty { Label(store.weather, systemImage: "cloud.sun").font(.caption).foregroundStyle(.secondary) }
                    }
                    Spacer(); NativeConnectionBadge()
                }
                NativeBudgetHero()
                NativeCard {
                    HStack { NativeIcon(name: "clock"); NativeSectionHeading(title: "I tuoi turni") }
                    shiftRow("Oggi", day: CivilDate.day())
                    Divider()
                    shiftRow("Domani", day: CivilDate.adding(1, to: CivilDate.day()))
                }
                VStack(alignment: .leading, spacing: 12) {
                    HStack { NativeSectionHeading(title: "Routine"); Button("Gestisci") { router.sheet = .routines }.font(.subheadline.weight(.medium)) }
                    NativeCard {
                        if store.routines.isEmpty { Text("Crea la tua prima routine").foregroundStyle(.secondary) }
                        ForEach(store.routines.map { DisplayRecord($0) }) { item in
                            Button {
                                Task { await store.run("setRoutineCheck", ["id": .int(item.value.integer("id")), "day": .string(CivilDate.day()), "checked": .bool(!item.value.flag("checked"))]) }
                            } label: {
                                HStack(spacing: 14) {
                                    Image(systemName: item.value.flag("checked") ? "checkmark.circle.fill" : "circle").font(.title2).foregroundStyle(item.value.flag("checked") ? NativeDesign.accent : Color.secondary)
                                    Text(item.value.text("title")).foregroundStyle(.primary)
                                    Spacer()
                                }.frame(minHeight: 38).contentShape(Rectangle())
                            }.buttonStyle(.plain).disabled(store.busy)
                        }
                    }
                }
                VStack(alignment: .leading, spacing: 12) {
                    HStack { NativeSectionHeading(title: "In evidenza"); Button { router.tab = .tasks } label: { Image(systemName: "arrow.up.right").frame(width: 44, height: 44) }.accessibilityLabel("Apri Attività") }
                    NativeCard {
                        if store.highlights.isEmpty { Label("Tutto in ordine", systemImage: "checkmark.seal").foregroundStyle(.secondary).padding(.vertical, 12) }
                        ForEach(store.highlights.map { DisplayRecord($0) }) { item in
                            let r = item.value
                            HStack(spacing: 14) {
                                if r.text("highlightKind") == "task" {
                                    Button { Task { await store.run("setTaskStatus", ["id": .int(r.integer("id")), "status": .string("done")]) } } label: { Image(systemName: "circle").font(.title2).frame(width: 38, height: 44) }.accessibilityLabel("Completa " + r.text("title"))
                                } else { NativeIcon(name: "calendar") }
                                Button { router.sheet = r.text("highlightKind") == "task" ? .task(r) : .event(r) } label: {
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(r.text("title")).font(.body.weight(.medium)).foregroundStyle(.primary)
                                        if r.text("highlightKind") == "event" { Text(CivilDate.label(r.text("day")) + " · " + r.text("start_time")).font(.caption).foregroundStyle(.secondary) }
                                    }.frame(maxWidth: .infinity, alignment: .leading).frame(minHeight: 44)
                                }.buttonStyle(.plain)
                            }
                        }
                    }
                }
                NativeCard {
                    HStack { NativeIcon(name: "wallet.bifold"); NativeSectionHeading(title: "Il tuo denaro") }
                    if !hidden && !store.summary.isEmpty {
                        LabeledContent("Saldo attuale", value: store.summary.amount("budget").euro).monospacedDigit()
                        LabeledContent("Impegni del mese", value: store.summary.amount("monthlyCommitted").euro).foregroundStyle(.secondary).monospacedDigit()
                    }
                    Button { router.tab = .finance } label: { HStack { Text("Apri Finanza"); Spacer(); Image(systemName: "chevron.right").font(.caption.weight(.semibold)) }.frame(minHeight: 34) }
                }
                NativeCard {
                    DisclosureGroup { ForEach(SolarTimes.calculate(CivilDate.day()), id: \.0) { value in LabeledContent(value.0, value: value.1).font(.subheadline) } } label: {
                        Label("Orari del giorno · Empoli", systemImage: "sun.horizon").font(.subheadline.weight(.medium))
                    }
                }
                if let notice = store.notice { Text(notice).font(.caption).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .center) }
            }.padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 28)
        }.background(NativeDesign.canvas).refreshable { await store.sync(); await store.loadWeather() }
    }
    private func shiftRow(_ label: String, day: String) -> some View {
        HStack {
            Text(label).foregroundStyle(.secondary); Spacer()
            if let shift = store.shift(day) {
                HStack(spacing: 10) {
                    Text(shift.letter).font(.caption.bold()).frame(width: 30, height: 30).background(shift.color.opacity(0.14), in: RoundedRectangle(cornerRadius: 10)).foregroundStyle(shift.color)
                    VStack(alignment: .trailing, spacing: 3) { Text(shift.title).font(.subheadline.weight(.semibold)); if !shift.time.isEmpty { Text(shift.time).font(.caption).foregroundStyle(.secondary) } }
                }
            } else { Text("Nessun turno").font(.subheadline).foregroundStyle(.secondary) }
        }.frame(minHeight: 42)
    }
}

enum SolarTimes {
    static func calculate(_ day: String) -> [(String, String)] {
        let deg = Double.pi / 180, lat = 43.7179, lon = 10.9478
        var utc = Calendar(identifier: .gregorian); utc.timeZone = TimeZone(secondsFromGMT: 0)!
        let parts = CivilDate.calendar.dateComponents([.year, .month, .day], from: CivilDate.date(day))
        let midnight = utc.date(from: DateComponents(year: parts.year, month: parts.month, day: parts.day))!
        let jd = midnight.timeIntervalSince1970 / 86400 + 2440587.5 - lon / 360
        func norm(_ x: Double, _ n: Double) -> Double { (x.truncatingRemainder(dividingBy: n) + n).truncatingRemainder(dividingBy: n) }
        func sun(_ t: Double) -> (Double, Double) {
            let d = jd + t / 24 - 2451545, g = norm(357.529 + 0.98560028 * d, 360), q = norm(280.459 + 0.98564736 * d, 360)
            let l = norm(q + 1.915 * sin(g * deg) + 0.02 * sin(2 * g * deg), 360), e = (23.439 - 0.00000036 * d) * deg
            let ra = norm(atan2(cos(e) * sin(l * deg), cos(l * deg)) / deg / 15, 24)
            return (asin(sin(e) * sin(l * deg)) / deg, q / 15 - ra)
        }
        func noon(_ t: Double) -> Double { norm(12 - sun(t).1, 24) }
        func angle(_ a: Double, _ t: Double, _ before: Bool) -> Double {
            let dec = sun(t).0 * deg, ratio = (-sin(a * deg) - sin(dec) * sin(lat * deg)) / (cos(dec) * cos(lat * deg))
            if abs(ratio) > 1 || !ratio.isFinite { return .nan }
            let delta = acos(max(-1, min(1, ratio))) / deg / 15
            return noon(t) + (before ? -delta : delta)
        }
        var times: [Double] = [5, 6, 12, 13, 18, 18]
        for _ in 0..<2 {
            let t = times.map { $0 / 24 }
            let altitude = -atan(1 / (1 + tan(abs(lat - sun(t[3]).0) * deg))) / deg
            times = [angle(14.5, t[0], true), angle(0.833, t[1], true), noon(t[2]), angle(altitude, t[3], false), angle(0.833, t[4], false), angle(14.8, t[5], false)]
        }
        let offset = Double(CivilDate.calendar.timeZone.secondsFromGMT(for: midnight.addingTimeInterval(43200))) / 3600
        let labels = ["Prima dell’alba", "Alba", "Mezzogiorno", "Pomeriggio", "Tramonto", "Notte"], adjustments = [0, -2, 1, 1, 2, 0]
        return times.enumerated().map { i, value in
            guard value.isFinite else { return (labels[i], "—") }
            let minutes = Int(norm(((value + offset - lon / 15) * 60 + Double(adjustments[i])).rounded(), 1440))
            return (labels[i], String(format: "%02d:%02d", minutes / 60, minutes % 60))
        }
    }
}
