import SwiftUI

struct DashboardScreen: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    @AppStorage("native-hide-money") private var hidden = false
    var body: some View {
        List {
            Section {
                HStack { Label(CivilDate.label(CivilDate.day()), systemImage: "sun.max"); Spacer(); Text(store.weather).font(.caption).foregroundStyle(.secondary) }
                shiftRow("Oggi", day: CivilDate.day())
                shiftRow("Domani", day: CivilDate.adding(1, to: CivilDate.day()))
            }
            Section {
                ForEach(store.routines.map { DisplayRecord($0) }) { item in
                    Button {
                        Task { await store.run("setRoutineCheck", ["id": .int(item.value.integer("id")), "day": .string(CivilDate.day()), "checked": .bool(!item.value.flag("checked"))]) }
                    } label: {
                        Label(item.value.text("title"), systemImage: item.value.flag("checked") ? "checkmark.circle.fill" : "circle").foregroundStyle(item.value.flag("checked") ? Color.indigo : Color.primary)
                    }.disabled(store.busy)
                }
                Button("Gestisci routine") { router.sheet = .routines }
            } header: { Text("Routine") }
            Section {
                if store.highlights.isEmpty { Text("Nessun elemento in evidenza").foregroundStyle(.secondary) }
                ForEach(store.highlights.map { DisplayRecord($0) }) { item in
                    let r = item.value
                    if r.text("highlightKind") == "task" {
                        HStack {
                            Button { Task { await store.run("setTaskStatus", ["id": .int(r.integer("id")), "status": .string("done")]) } } label: { Image(systemName: "circle").font(.title2) }.buttonStyle(.borderless).accessibilityLabel("Completa " + r.text("title"))
                            Button(r.text("title")) { router.sheet = .task(r) }.foregroundStyle(.primary)
                        }
                    } else {
                        Button { router.sheet = .event(r) } label: {
                            HStack { Image(systemName: "calendar"); VStack(alignment: .leading) { Text(r.text("title")); Text(CivilDate.label(r.text("day")) + " · " + r.text("start_time")).font(.caption).foregroundStyle(.secondary) } }.foregroundStyle(.primary)
                        }
                    }
                }
                Button("Apri Attività") { router.tab = .tasks }
            } header: { Text("In evidenza") }
            Section {
                HStack {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Budget del mese").font(.subheadline).foregroundStyle(.secondary)
                        if hidden { Text("•••• €").font(.largeTitle.bold()) }
                        else if store.summary["monthlyRemaining"] == nil { Text("Budget mensile non caricato").font(.headline) }
                        else { MoneyText(amount: store.summary.amount("monthlyRemaining"), large: true) }
                    }
                    Spacer(); Button { hidden.toggle() } label: { Image(systemName: hidden ? "eye.slash" : "eye") }.accessibilityLabel(hidden ? "Mostra importi" : "Nascondi importi")
                }
                if !store.summary.isEmpty && !hidden {
                    if store.summary["monthlyCommitted"] != nil { LabeledContent("Impegnato nel mese", value: store.summary.amount("monthlyCommitted").euro) }
                    LabeledContent("Saldo", value: store.summary.amount("budget").euro)
                }
                Button("Apri Finanza") { router.tab = .finance }
            } header: { Text("Denaro") }
            Section {
                DisclosureGroup("Orari del giorno · Empoli") {
                    ForEach(SolarTimes.calculate(CivilDate.day()), id: \.0) { value in LabeledContent(value.0, value: value.1) }
                }
            }
        }.listStyle(.insetGrouped).refreshable { await store.sync(); await store.loadWeather() }
    }
    private func shiftRow(_ label: String, day: String) -> some View {
        HStack {
            Text(label).foregroundStyle(.secondary); Spacer()
            if let shift = store.shift(day) { VStack(alignment: .trailing) { Text(shift.title).font(.headline); if !shift.time.isEmpty { Text(shift.time).font(.caption).foregroundStyle(.secondary) } } }
            else { Text("Nessun turno").foregroundStyle(.secondary) }
        }
    }
}

enum SolarTimes {
    static func calculate(_ day: String) -> [(String, String)] {
        let deg = Double.pi / 180, lat = 43.7179, lon = 10.9478
        var utc = Calendar(identifier: .gregorian); utc.timeZone = TimeZone(secondsFromGMT: 0)!
        let parts = CivilDate.calendar.dateComponents([.year, .month, .day], from: CivilDate.date(day))
        let midnight = utc.date(from: DateComponents(year: parts.year, month: parts.month, day: parts.day))!
        let jd = midnight.timeIntervalSince1970 / 86400 + 2440587.5 - lon / 360
        func norm(_ x: Double, _ n: Double) -> Double { (x.truncatingRemainder(dividingBy: n) + n).truncatingRemainder(dividingBy: n) }
        func sun(_ t: Double) -> (Double, Double) {
            let d = jd + t / 24 - 2451545, g = norm(357.529 + 0.98560028 * d, 360), q = norm(280.459 + 0.98564736 * d, 360)
            let l = norm(q + 1.915 * sin(g * deg) + 0.02 * sin(2 * g * deg), 360), e = (23.439 - 0.00000036 * d) * deg
            let ra = norm(atan2(cos(e) * sin(l * deg), cos(l * deg)) / deg / 15, 24)
            return (asin(sin(e) * sin(l * deg)) / deg, q / 15 - ra)
        }
        func noon(_ t: Double) -> Double { norm(12 - sun(t).1, 24) }
        func angle(_ a: Double, _ t: Double, _ before: Bool) -> Double {
            let dec = sun(t).0 * deg, ratio = (-sin(a * deg) - sin(dec) * sin(lat * deg)) / (cos(dec) * cos(lat * deg))
            if abs(ratio) > 1 || !ratio.isFinite { return .nan }
            let delta = acos(max(-1, min(1, ratio))) / deg / 15
            return noon(t) + (before ? -delta : delta)
        }
        var times: [Double] = [5, 6, 12, 13, 18, 18]
        for _ in 0..<2 {
            let t = times.map { $0 / 24 }
            let altitude = -atan(1 / (1 + tan(abs(lat - sun(t[3]).0) * deg))) / deg
            times = [angle(14.5, t[0], true), angle(0.833, t[1], true), noon(t[2]), angle(altitude, t[3], false), angle(0.833, t[4], false), angle(14.8, t[5], false)]
        }
        let offset = Double(CivilDate.calendar.timeZone.secondsFromGMT(for: midnight.addingTimeInterval(43200))) / 3600
        let labels = ["Prima dell’alba", "Alba", "Mezzogiorno", "Pomeriggio", "Tramonto", "Notte"], adjustments = [0, -2, 1, 1, 2, 0]
        return times.enumerated().map { i, value in
            guard value.isFinite else { return (labels[i], "—") }
            let minutes = Int(norm(((value + offset - lon / 15) * 60 + Double(adjustments[i])).rounded(), 1440))
            return (labels[i], String(format: "%02d:%02d", minutes / 60, minutes % 60))
        }
    }
}
