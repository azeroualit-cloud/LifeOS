import SwiftUI

struct DashboardScreen: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    var body: some View {
        TimelineView(.periodic(from: .now, by: 60)) { context in
            let today = CivilDate.day(context.date)
            let summary = NativeHomeSummary(now: context.date, todayShift: store.shift(today), tomorrowShift: store.shift(CivilDate.adding(1, to: today)), previousShift: store.shift(CivilDate.adding(-1, to: today)), events: store.dashboardEvents, weather: store.weatherDetails, weatherDate: store.weatherDate, includeEvents: true)
            ScrollView {
                VStack(alignment: .leading, spacing: NativeDesign.Space.section) {
                    rollingCalendar(today)
                    VStack(alignment: .leading, spacing: NativeDesign.Space.small) {
                        Text(summary.greeting).font(.footnote).foregroundStyle(NativeDesign.secondary)
                        Text(summary.text).font(.body).accessibilityIdentifier("home-summary")
                        if let weather = store.weatherDetails, let updated = store.weatherDate, context.date.timeIntervalSince(updated) < 3600 {
                            Text("Min \(Int(weather.low))° · Max \(Int(weather.high))° · \(weather.change)").font(.caption).foregroundStyle(NativeDesign.secondary)
                        }
                        if store.weather == "Meteo non disponibile" { Text(store.weather).font(.caption).foregroundStyle(NativeDesign.secondary) }
                    }
                    HStack(alignment: .top, spacing: NativeDesign.Space.medium) {
                        Button { router.sheet = .weight } label: { NativeActionLabel(title: "Aggiungi peso", symbol: "plus") }.accessibilityIdentifier("dashboard-add-weight")
                        Button { openCalendar(today) } label: { NativeActionLabel(title: "Calendario", symbol: "calendar") }.accessibilityIdentifier("dashboard-calendar")
                    }.buttonStyle(NativePressStyle()).foregroundStyle(NativeDesign.accent)
                    DailyLifePanel()
                    HealthChartPanel()
                    NativeConnectionBadge()
                    if let notice = store.notice { Text(notice).font(.caption).foregroundStyle(NativeDesign.secondary) }
                }.padding(.horizontal, NativeDesign.Layout.screenInset).padding(.top, NativeDesign.Space.small).padding(.bottom, NativeDesign.Layout.scrollClearance)
            }.background(NativeDesign.canvas).scrollBounceBehavior(.basedOnSize).accessibilityIdentifier("dashboard-scroll")
                .task(id: today) { await store.loadWeather() }
        }
        .navigationDestination(isPresented: $router.showCalendar) {
            CalendarScreen().navigationTitle("Calendario").navigationBarTitleDisplayMode(.inline)
        }
    }
    private func rollingCalendar(_ today: String) -> some View {
        VStack(spacing: NativeDesign.Space.small) {
            Text(CivilDate.monthTitle(String(today.prefix(7)))).font(.subheadline).foregroundStyle(NativeDesign.secondary).frame(maxWidth: .infinity, alignment: .leading)
            HStack(spacing: NativeDesign.Space.xs) {
                ForEach(NativeHomeSummary.rollingDays(today), id: \.self) { day in
                    let weekday = CivilDate.calendar.component(.weekday, from: CivilDate.date(day))
                    let item = CalendarDayPresentation(day: day, label: CivilDate.label(day), shift: store.shift(day), hasEvents: store.dashboardEvents.contains { $0.text("day") == day }, isToday: day == today, isWeekend: weekday == 1 || weekday == 7, isCurrentMonth: day.hasPrefix(String(today.prefix(7))))
                    Button { openCalendar(day) } label: {
                        VStack(spacing: NativeDesign.Space.xs) {
                            Text(["D", "L", "M", "M", "G", "V", "S"][weekday - 1]).font(.caption).foregroundStyle(NativeDesign.secondary)
                            CalendarDayCell(item: item, active: day == today).equatable()
                        }.frame(maxWidth: .infinity).contentShape(Rectangle())
                    }.buttonStyle(.plain).accessibilityIdentifier("dashboard-day-" + day)
                        .accessibilityLabel(CivilDate.label(day) + ", " + (store.shift(day)?.title ?? "Nessun turno"))
                        .accessibilityAddTraits(day == today ? .isSelected : [])
                }
            }.dynamicTypeSize(...DynamicTypeSize.xxxLarge)
        }
    }
    private func openCalendar(_ day: String) {
        store.calendarMonth = String(day.prefix(7)); router.calendarDay = day; router.showCalendar = true
        Task { await store.sync(scope: .life) }
    }
}
