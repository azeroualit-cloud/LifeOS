import SwiftUI

struct DashboardScreen: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    @AppStorage("native-hide-money") private var hidden = false
    private var week: [String] {
        let day = CivilDate.day(), weekday = CivilDate.calendar.component(.weekday, from: CivilDate.date(day))
        let monday = CivilDate.adding(-((weekday + 5) % 7), to: day)
        return (0..<7).map { CivilDate.adding($0, to: monday) }
    }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Text(CivilDate.monthTitle(CivilDate.month())).font(.subheadline)
                    Spacer()
                    Button { router.tab = .calendar } label: { HStack(spacing: 4) { Text("Questa settimana"); Image(systemName: "chevron.right") }.font(.caption) }.frame(minHeight: 44)
                }
                HStack(spacing: 5) {
                    ForEach(week, id: \.self) { day in
                        let today = day == CivilDate.day(), shift = store.shift(day)
                        Button { router.calendarDay = day; router.tab = .calendar } label: {
                            VStack(spacing: 6) {
                                Text(CivilDate.date(day).formatted(.dateTime.weekday(.narrow).locale(Locale(identifier: "it_IT")))).font(.caption2).foregroundStyle(Color.secondary)
                                Text(String(Int(day.suffix(2)) ?? 0)).font(.subheadline.weight(today ? .semibold : .regular))
                                Text(shift?.letter ?? " ").font(.caption2.weight(.semibold)).foregroundStyle(shift?.color ?? Color.secondary)
                            }.frame(maxWidth: .infinity).frame(height: 76)
                            .background(today ? NativeDesign.accent.opacity(0.25) : NativeDesign.surface, in: RoundedRectangle(cornerRadius: 14))
                            .overlay(RoundedRectangle(cornerRadius: 14).stroke(today ? NativeDesign.accent : .clear, lineWidth: 1))
                        }.buttonStyle(.plain).accessibilityLabel(CivilDate.label(day))
                    }
                }.padding(.bottom, 4)
                NativeCard {
                    HStack { Text("Oggi").font(.subheadline.weight(.semibold)); Spacer(); Text(CivilDate.label(CivilDate.day())).font(.caption).foregroundStyle(Color.secondary) }
                    if let shift = store.shift(CivilDate.day()) {
                        Button { router.tab = .calendar } label: {
                            HStack(spacing: 10) { NativeIcon(name: shift.symbol, color: shift.color); Text(shift.title + (shift.time.isEmpty ? "" : " · " + shift.time)).font(.subheadline).foregroundStyle(shift.color); Spacer(); Image(systemName: "chevron.right").font(.caption2) }
                        }.buttonStyle(.plain)
                    } else { Text("Nessun turno in programma").font(.subheadline).foregroundStyle(Color.secondary) }
                    if !store.weather.isEmpty { Text(store.weather).font(.caption).foregroundStyle(Color.secondary) }
                }
                NativeCard {
                    HStack {
                        Text("Attività").font(.headline); Spacer()
                        Button { router.sheet = .task(["list_kind": .string("action")]) } label: { Image(systemName: "plus.circle").font(.title3).frame(width: 44, height: 36) }.accessibilityLabel("Nuova attività dalla Dashboard")
                    }
                    if store.highlights.isEmpty { Text("Tutto in ordine").font(.subheadline).foregroundStyle(Color.secondary) }
                    ForEach(store.highlights.map { DisplayRecord($0) }) { item in
                        let r = item.value
                        Divider()
                        HStack(spacing: 8) {
                            if r.text("highlightKind") == "task" {
                                Button { Task { await store.run("setTaskStatus", ["id": .int(r.integer("id")), "status": .string("done")]) } } label: { Image(systemName: "circle").font(.system(size: 22, weight: .light)).foregroundStyle(Color.secondary).frame(width: 32, height: 44) }.disabled(store.busy).accessibilityLabel("Completa " + r.text("title"))
                            } else { Image(systemName: "calendar").foregroundStyle(NativeDesign.accent).frame(width: 32) }
                            Button { router.sheet = r.text("highlightKind") == "task" ? .task(r) : .event(r) } label: {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(r.text("title")).font(.subheadline).foregroundStyle(Color.primary)
                                    if !r.text("notes").isEmpty { Text(r.text("notes")).font(.caption).foregroundStyle(Color.secondary).lineLimit(1) }
                                    if r.text("highlightKind") == "event" { Text(CivilDate.label(r.text("day")) + " · " + r.text("start_time")).font(.caption).foregroundStyle(Color.secondary) }
                                }.frame(maxWidth: .infinity, minHeight: 44, alignment: .leading).multilineTextAlignment(.leading)
                            }.buttonStyle(.plain)
                            Image(systemName: "chevron.right").font(.caption2).foregroundStyle(Color.secondary)
                        }
                    }
                    Divider()
                    Button { router.tab = .tasks } label: { Label("Vedi tutte", systemImage: "list.bullet").font(.subheadline).frame(maxWidth: .infinity, minHeight: 32, alignment: .leading) }
                }
                NativeCard {
                    Button { router.tab = .finance } label: { HStack { Text("Finanza").font(.headline).foregroundStyle(Color.primary); Spacer(); Image(systemName: "chevron.right").font(.caption) } }
                    HStack(spacing: 16) {
                        ZStack {
                            Circle().stroke(Color.secondary.opacity(0.2), lineWidth: 7)
                            Circle().trim(from: 0, to: ring).stroke(NativeDesign.accent, style: StrokeStyle(lineWidth: 7, lineCap: .round)).rotationEffect(.degrees(-90))
                            VStack(spacing: 3) { Text(hidden ? "•••• €" : store.summary.amount("budget").euro).font(.subheadline.weight(.semibold)).minimumScaleFactor(0.5).lineLimit(1); Text("Saldo attuale").font(.system(size: 10)).foregroundStyle(Color.secondary) }.padding(10)
                        }.frame(width: 116, height: 116).accessibilityElement(children: .combine)
                        VStack(alignment: .leading, spacing: 12) {
                            if !hidden {
                                let daily = NativeValidation.dailyBudget(store.summary)
                                HStack(alignment: .top) {
                                    VStack(alignment: .leading, spacing: 3) { Text(daily.low.euro).font(.subheadline.weight(.semibold)); Text("Al giorno").font(.caption2).foregroundStyle(Color.secondary) }
                                    Spacer()
                                    VStack(alignment: .leading, spacing: 3) { Text(String(daily.days)).font(.subheadline.weight(.semibold)); Text("Giorni rimasti").font(.caption2).foregroundStyle(Color.secondary) }
                                }
                            }
                            Button { router.tab = .finance } label: { Label("Vedi dettagli", systemImage: "chart.bar.fill").font(.caption).frame(minHeight: 34) }.buttonStyle(.bordered)
                        }.frame(maxWidth: .infinity)
                    }
                }
                NativeCard {
                    HStack { Text("Routine").font(.headline); Spacer(); Button("Gestisci") { router.sheet = .routines }.font(.caption) }
                    ForEach(store.routines.map { DisplayRecord($0) }) { item in
                        Button { Task { await store.run("setRoutineCheck", ["id": .int(item.value.integer("id")), "day": .string(CivilDate.day()), "checked": .bool(!item.value.flag("checked"))]) } } label: {
                            HStack(spacing: 10) { Image(systemName: item.value.flag("checked") ? "checkmark.circle.fill" : "circle").font(.system(size: 22, weight: .light)).foregroundStyle(item.value.flag("checked") ? NativeDesign.accent : Color.secondary); Text(item.value.text("title")).font(.subheadline).foregroundStyle(Color.primary); Spacer() }.frame(minHeight: 44)
                        }.buttonStyle(.plain).disabled(store.busy)
                    }
                }
                NativeCard {
                    DisclosureGroup { ForEach(SolarTimes.calculate(CivilDate.day()), id: \.0) { LabeledContent($0.0, value: $0.1).font(.subheadline) } } label: { Label("Orari del giorno · Empoli", systemImage: "sun.horizon").font(.subheadline) }
                }
                NativeConnectionBadge()
                if let notice = store.notice { Text(notice).font(.caption).foregroundStyle(Color.secondary) }
            }.padding(.horizontal, 16).padding(.bottom, 24)
        }.background(NativeDesign.canvas).scrollBounceBehavior(.basedOnSize).accessibilityIdentifier("dashboard-scroll")
    }
    private var ring: Double {
        let total = abs(store.summary.amount("budget"))
        return total > 0 ? max(0, min(1, store.summary.amount("remainingFree") / total)) : 0
    }
}

enum SolarTimes {
    static func calculate(_ day: String) -> [(String, String)] {
        let deg = Double.pi / 180, lat = 43.7179, lon = 10.9478
        var utc = Calendar(identifier: .gregorian); utc.timeZone = TimeZone(secondsFromGMT: 0)!
        let parts = CivilDate.calendar.dateComponents([.year, .month, .day], from: CivilDate.date(day))
        let midnight = utc.date(from: DateComponents(year: parts.year, month: parts.month, day: parts.day))!
        let jd = midnight.timeIntervalSince1970 / 86400 + 2440587.5 - lon / 360
        func norm(_ x: Double, _ n: Double) -> Double { (x.truncatingRemainder(dividingBy: n) + n).truncatingRemainder(dividingBy: n) }
        func sun(_ t: Double) -> (Double, Double) {
            let d = jd + t / 24 - 2451545, g = norm(357.529 + 0.98560028 * d, 360), q = norm(280.459 + 0.98564736 * d, 360)
            let l = norm(q + 1.915 * sin(g * deg) + 0.02 * sin(2 * g * deg), 360), e = (23.439 - 0.00000036 * d) * deg
            let ra = norm(atan2(cos(e) * sin(l * deg), cos(l * deg)) / deg / 15, 24)
            return (asin(sin(e) * sin(l * deg)) / deg, q / 15 - ra)
        }
        func noon(_ t: Double) -> Double { norm(12 - sun(t).1, 24) }
        func angle(_ a: Double, _ t: Double, _ before: Bool) -> Double {
            let dec = sun(t).0 * deg, ratio = (-sin(a * deg) - sin(dec) * sin(lat * deg)) / (cos(dec) * cos(lat * deg))
            if abs(ratio) > 1 || !ratio.isFinite { return .nan }
            let delta = acos(max(-1, min(1, ratio))) / deg / 15
            return noon(t) + (before ? -delta : delta)
        }
        var times: [Double] = [5, 6, 12, 13, 18, 18]
        for _ in 0..<2 {
            let t = times.map { $0 / 24 }
            let altitude = -atan(1 / (1 + tan(abs(lat - sun(t[3]).0) * deg))) / deg
            times = [angle(14.5, t[0], true), angle(0.833, t[1], true), noon(t[2]), angle(altitude, t[3], false), angle(0.833, t[4], false), angle(14.8, t[5], false)]
        }
        let offset = Double(CivilDate.calendar.timeZone.secondsFromGMT(for: midnight.addingTimeInterval(43200))) / 3600
        let labels = ["Prima dell’alba", "Alba", "Mezzogiorno", "Pomeriggio", "Tramonto", "Notte"], adjustments = [0, -2, 1, 1, 2, 0]
        return times.enumerated().map { i, value in
            guard value.isFinite else { return (labels[i], "—") }
            let minutes = Int(norm(((value + offset - lon / 15) * 60 + Double(adjustments[i])).rounded(), 1440))
            return (labels[i], String(format: "%02d:%02d", minutes / 60, minutes % 60))
        }
    }
}
