import SwiftUI

struct DashboardScreen: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    @State private var routineBusy: Int?
    @State private var routineFeedback = false
    @AppStorage("native-hide-money") private var hidden = false

    var body: some View {
        TimelineView(.periodic(from: .now, by: 60)) { context in
            let now = context.date, today = CivilDate.day(now)
            let summary = NativeHomeSummary(now: now, todayShift: store.shift(today), tomorrowShift: store.shift(CivilDate.adding(1, to: today)), previousShift: store.shift(CivilDate.adding(-1, to: today)), events: store.dashboardEvents, weather: store.weather == "Meteo non disponibile" ? nil : store.weatherDetails, weatherDate: store.weatherDate, calendarAvailable: NativeHomeSummary.hasCalendarData(life: store.life, demo: store.isDemo))
            let todos = NativeHomeSummary.todos(store.tasks)
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    rollingCalendar(today)
                    overview(summary)
                    routines
                    todoSection(todos)
                    budget
                    NativeConnectionBadge()
                    if let notice = store.notice { Text(notice).font(.caption).foregroundStyle(NativeDesign.secondary) }
                }.padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 32)
            }
            .background(NativeDesign.canvas).scrollBounceBehavior(.basedOnSize).accessibilityIdentifier("dashboard-scroll")
            .task(id: today) {
                // Home dates follow today without changing the month being browsed in Calendar.
                await store.loadWeather()
            }
        }.sensoryFeedback(.success, trigger: routineFeedback)
    }

    private func rollingCalendar(_ today: String) -> some View {
        let days = NativeHomeSummary.rollingDays(today)
        let marked = Set(store.events.map { $0.text("day") } + store.tasks.map { $0.text("scheduled_date") })
        return VStack(spacing: 8) {
            HStack {
                Text(CivilDate.monthTitle(String(today.prefix(7)))).font(.subheadline).foregroundStyle(NativeDesign.secondary)
                Spacer()
                Button { openCalendar(today) } label: { Image(systemName: "calendar").font(NativeDesign.symbol).frame(width: 44, height: 44) }.accessibilityLabel("Apri calendario")
            }
            HStack(spacing: 4) {
                ForEach(days, id: \.self) { day in
                    let current = day == today, shift = store.shift(day)
                    let code = shift?.letter ?? ""
                    Button { openCalendar(day) } label: {
                        VStack(spacing: 4) {
                            Text(["D", "L", "M", "M", "G", "V", "S"][CivilDate.calendar.component(.weekday, from: CivilDate.date(day)) - 1]).font(.caption2).foregroundStyle(NativeDesign.secondary)
                            Text(String(Int(day.suffix(2)) ?? 0)).font(.subheadline.weight(current ? .semibold : .regular)).monospacedDigit()
                                .foregroundStyle(current ? NativeDesign.canvas : Color.primary)
                                .frame(width: 32, height: 32).background(current ? NativeDesign.accent : .clear, in: Circle())
                            Text(code.isEmpty ? "–" : code).font(.caption2.weight(.semibold)).foregroundStyle(shift?.color ?? NativeDesign.secondary).frame(height: 16)
                            Circle().fill(marked.contains(day) ? (shift?.color ?? NativeDesign.accent) : .clear).frame(width: 3, height: 3)
                        }.frame(maxWidth: .infinity).contentShape(Rectangle())
                    }.buttonStyle(.plain).accessibilityIdentifier("dashboard-day-" + day)
                        .accessibilityLabel(CivilDate.label(day) + ", " + (shift?.title ?? "Turno non disponibile"))
                        .accessibilityAddTraits(current ? .isSelected : [])
                }
            }.dynamicTypeSize(...DynamicTypeSize.xxxLarge).accessibilityIdentifier("home-days")
        }
    }
    private func openCalendar(_ day: String) {
        var transaction = Transaction(animation: nil); transaction.disablesAnimations = true
        withTransaction(transaction) { store.calendarMonth = String(day.prefix(7)); router.calendarDay = day; router.tab = .calendar }
        Task { await store.sync(scope: .life) }
    }
    private func naturalText(_ summary: NativeHomeSummary) -> Text {
        summary.phrases.enumerated().reduce(Text("")) { text, entry in
            let phrase = entry.element
            return text + Text(entry.offset == 0 ? "" : " ")
                + Text(phrase.lead).foregroundColor(NativeDesign.secondary)
                + Text(phrase.detail).foregroundColor(.primary).fontWeight(.semibold)
                + Text(phrase.tail).foregroundColor(NativeDesign.secondary)
        }
    }
    private func overview(_ summary: NativeHomeSummary) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(summary.greeting).font(.subheadline).foregroundStyle(NativeDesign.secondary).accessibilityIdentifier("home-greeting")
            naturalText(summary).font(.system(.title, weight: .regular)).lineSpacing(2)
                .fixedSize(horizontal: false, vertical: true).accessibilityIdentifier("home-summary")
            if !summary.events.isEmpty {
                NavigationLink { HomeAgendaScreen() } label: {
                    HStack(spacing: 4) {
                        Text(summary.events.count == 1 ? "Dettagli appuntamento" : "Tutti i \(summary.events.count) appuntamenti")
                        Image(systemName: "chevron.right").font(.caption2)
                    }.font(.caption).frame(minHeight: 44)
                }.accessibilityIdentifier("home-events")
            }
            if store.weather == "Meteo non disponibile" { Text("Meteo non disponibile").font(.caption).foregroundStyle(NativeDesign.secondary) }
        }
    }
    private var routines: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Abitudini").font(.title3.weight(.semibold)).accessibilityIdentifier("home-routines-heading")
                Spacer()
                NavigationLink { RoutinesEditor() } label: { Text("Gestisci").font(.caption).frame(minHeight: 44) }.accessibilityIdentifier("home-manage-routines")
            }
            if store.routines.isEmpty {
                NavigationLink { RoutinesEditor() } label: { Label("Aggiungi la prima abitudine", systemImage: "plus").font(.subheadline).frame(maxWidth: .infinity, minHeight: 44, alignment: .leading) }.accessibilityIdentifier("home-empty-routines")
            } else {
                HomeGroup {
                    ForEach(Array(store.routines.enumerated()), id: \.element.integerID) { index, record in
                        if index > 0 { Divider().padding(.leading, 52) }
                        Button { checkRoutine(record) } label: {
                            HStack(spacing: 8) {
                                Image(systemName: record.flag("checked") ? "checkmark.circle.fill" : "circle").font(.system(size: 22)).frame(width: 44, height: 44).foregroundStyle(record.flag("checked") ? NativeDesign.accent : NativeDesign.secondary)
                                Text(record.text("title")).font(.subheadline).foregroundStyle(Color.primary).fixedSize(horizontal: false, vertical: true)
                                Spacer(minLength: 0)
                                if routineBusy == record.integer("id") { ProgressView().controlSize(.small) }
                            }.frame(maxWidth: .infinity, minHeight: 44, alignment: .leading).contentShape(Rectangle())
                        }.buttonStyle(.plain).padding(.vertical, 2).disabled(store.busy || routineBusy != nil)
                            .accessibilityIdentifier("home-routine-\(record.integer("id"))")
                            .accessibilityLabel(record.text("title")).accessibilityValue(record.flag("checked") ? "Completata" : "Da completare")
                    }
                }
            }
        }
    }
    private func checkRoutine(_ record: Record) {
        guard routineBusy == nil else { return }
        routineBusy = record.integer("id")
        Task {
            defer { routineBusy = nil }
            do {
                try await store.perform("setRoutineCheck", ["id": .int(record.integer("id")), "day": .string(CivilDate.day()), "checked": .bool(!record.flag("checked"))])
                routineFeedback.toggle()
            } catch { store.error = error.localizedDescription }
        }
    }
    private func todoSection(_ rows: [Record]) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Da fare").font(.title3.weight(.semibold)).accessibilityIdentifier("home-todos-heading")
                Spacer()
                Button { router.taskCategory = "action"; router.tab = .tasks } label: { Text(rows.isEmpty ? "Apri" : "Tutte · \(rows.count)").font(.caption).frame(minHeight: 44) }.accessibilityIdentifier("home-all-todos")
            }
            if rows.isEmpty {
                Button { router.sheet = .task(["list_kind": .string("action")]) } label: {
                    Label("Nessuna attività da fare. Aggiungine una", systemImage: "plus").font(.subheadline).frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                }.accessibilityIdentifier("home-empty-todos")
            } else {
                HomeGroup {
                    ForEach(Array(rows.prefix(3).enumerated()), id: \.element.integerID) { index, record in
                        if index > 0 { Divider().padding(.leading, 52) }
                        HStack(spacing: 8) {
                            Button { Task { await store.run("setTaskStatus", ["id": .int(record.integer("id")), "status": .string("done")]) } } label: { Image(systemName: "circle").font(.system(size: 22)).foregroundStyle(NativeDesign.secondary).frame(width: 44, height: 44) }.buttonStyle(.plain).disabled(store.busy).accessibilityLabel("Completa " + record.text("title"))
                            Button { router.sheet = .task(record) } label: {
                                HStack(spacing: 8) {
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(record.text("title")).font(.subheadline).foregroundStyle(Color.primary).lineLimit(2)
                                        if !record.text("due_date").isEmpty { NativeDueBadge(day: record.text("due_date")) }
                                    }
                                    Spacer(minLength: 0)
                                    Image(systemName: "chevron.right").font(.caption2).foregroundStyle(NativeDesign.secondary)
                                }.frame(maxWidth: .infinity, minHeight: 44, alignment: .leading).contentShape(Rectangle())
                            }.buttonStyle(.plain).accessibilityIdentifier("home-todo-\(record.integer("id"))").accessibilityLabel(record.text("title"))
                        }.padding(.vertical, 2)
                    }
                }
            }
        }
    }
    private var budget: some View {
        let valid: Bool = { if case .number(let value)? = store.summary["monthlyRemaining"] { return value.isFinite }; return false }()
        let daily = NativeValidation.dailyBudget(store.summary, month: store.financeMonth)
        return Button { router.financeSection = "Panoramica"; router.tab = .finance } label: {
            VStack(alignment: .leading, spacing: 10) {
                HStack { Text("Budget rimanente").font(.caption).foregroundStyle(NativeDesign.secondary); Spacer(); Image(systemName: "chevron.right").font(.caption).foregroundStyle(NativeDesign.secondary) }
                ViewThatFits(in: .horizontal) {
                    HStack(alignment: .firstTextBaseline) { budgetValue(valid); Spacer(minLength: 12); dailyValue(valid, days: daily.days, amount: daily.low) }
                    VStack(alignment: .leading, spacing: 8) { budgetValue(valid); dailyValue(valid, days: daily.days, amount: daily.low) }
                }
                if valid && !hidden { NativeBudgetAllocation(summary: store.summary, compact: true) }
                if store.financeMonth != CivilDate.month() { Text(CivilDate.monthTitle(store.financeMonth)).font(.caption2).foregroundStyle(NativeDesign.secondary) }
            }.frame(maxWidth: .infinity, alignment: .leading).padding(16).modifier(NativeSurface()).contentShape(RoundedRectangle(cornerRadius: NativeDesign.cardRadius))
        }.buttonStyle(.plain).accessibilityIdentifier("home-budget").accessibilityLabel("Budget rimanente")
            .accessibilityValue(hidden ? "Importo nascosto" : valid ? store.summary.amount("monthlyRemaining").euro : "Da aggiornare")
            .accessibilityHint("Apre la panoramica finanziaria")
    }
    private func budgetValue(_ valid: Bool) -> some View {
        Text(hidden ? "•••• €" : valid ? store.summary.amount("monthlyRemaining").euro : "Da aggiornare")
            .font(.title2.weight(.semibold)).monospacedDigit().lineLimit(1).minimumScaleFactor(0.6)
            .foregroundStyle(!hidden && valid && store.summary.amount("monthlyRemaining") < 0 ? NativeDesign.financialRed : Color.primary)
    }
    @ViewBuilder private func dailyValue(_ valid: Bool, days: Int, amount: Double) -> some View {
        if valid && !hidden && days > 0 { Text(amount.euro + "/giorno").font(.caption).foregroundStyle(NativeDesign.secondary).fixedSize() }
    }
}

private struct HomeGroup<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View { VStack(spacing: 0) { content }.padding(.horizontal, 12).padding(.vertical, 4).background(NativeDesign.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous)) }
}
private extension Dictionary where Key == String, Value == JSONValue { var integerID: Int { integer("id") } }

private struct HomeAgendaScreen: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    private var events: [Record] { NativeHomeSummary(now: Date(), todayShift: nil, tomorrowShift: nil, events: store.dashboardEvents, weather: nil, weatherDate: nil).events }
    var body: some View {
        List {
            if events.isEmpty { ContentUnavailableView("Nessun appuntamento", systemImage: "calendar") }
            ForEach(events.map { DisplayRecord($0) }) { item in
                Button { router.sheet = .event(item.value) } label: {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(item.value.text("title")).font(.subheadline).foregroundStyle(Color.primary)
                        Text(CivilDate.label(item.value.text("day")) + (item.value.text("start_time").isEmpty ? "" : " · " + item.value.text("start_time"))).font(.caption).foregroundStyle(NativeDesign.secondary)
                    }.frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                }.buttonStyle(.plain)
            }
        }.modifier(NativeListAppearance()).navigationTitle("Prossimi appuntamenti").navigationBarTitleDisplayMode(.inline)
    }
}

enum SolarTimes {
    static func calculate(_ day: String) -> [(String, String)] {
        let deg = Double.pi / 180, lat = 43.7179, lon = 10.9478
        var utc = Calendar(identifier: .gregorian); utc.timeZone = TimeZone(secondsFromGMT: 0)!
        let parts = CivilDate.calendar.dateComponents([.year, .month, .day], from: CivilDate.date(day))
        let midnight = utc.date(from: DateComponents(year: parts.year, month: parts.month, day: parts.day))!
        let jd = midnight.timeIntervalSince1970 / 86400 + 2440587.5 - lon / 360
        func norm(_ x: Double, _ n: Double) -> Double { (x.truncatingRemainder(dividingBy: n) + n).truncatingRemainder(dividingBy: n) }
        func sun(_ t: Double) -> (Double, Double) {
            let d = jd + t / 24 - 2451545, g = norm(357.529 + 0.98560028 * d, 360), q = norm(280.459 + 0.98564736 * d, 360)
            let l = norm(q + 1.915 * sin(g * deg) + 0.02 * sin(2 * g * deg), 360), e = (23.439 - 0.00000036 * d) * deg
            let ra = norm(atan2(cos(e) * sin(l * deg), cos(l * deg)) / deg / 15, 24)
            return (asin(sin(e) * sin(l * deg)) / deg, q / 15 - ra)
        }
        func noon(_ t: Double) -> Double { norm(12 - sun(t).1, 24) }
        func angle(_ a: Double, _ t: Double, _ before: Bool) -> Double {
            let dec = sun(t).0 * deg, ratio = (-sin(a * deg) - sin(dec) * sin(lat * deg)) / (cos(dec) * cos(lat * deg))
            if abs(ratio) > 1 || !ratio.isFinite { return .nan }
            let delta = acos(max(-1, min(1, ratio))) / deg / 15
            return noon(t) + (before ? -delta : delta)
        }
        var times: [Double] = [5, 6, 12, 13, 18, 18]
        for _ in 0..<2 {
            let t = times.map { $0 / 24 }
            let altitude = -atan(1 / (1 + tan(abs(lat - sun(t[3]).0) * deg))) / deg
            times = [angle(14.5, t[0], true), angle(0.833, t[1], true), noon(t[2]), angle(altitude, t[3], false), angle(0.833, t[4], false), angle(14.8, t[5], false)]
        }
        let offset = Double(CivilDate.calendar.timeZone.secondsFromGMT(for: midnight.addingTimeInterval(43200))) / 3600
        let labels = ["Prima dell’alba", "Alba", "Mezzogiorno", "Pomeriggio", "Tramonto", "Notte"], adjustments = [0, -2, 1, 1, 2, 0]
        return times.enumerated().map { i, value in
            guard value.isFinite else { return (labels[i], "—") }
            let minutes = Int(norm(((value + offset - lon / 15) * 60 + Double(adjustments[i])).rounded(), 1440))
            return (labels[i], String(format: "%02d:%02d", minutes / 60, minutes % 60))
        }
    }
}
