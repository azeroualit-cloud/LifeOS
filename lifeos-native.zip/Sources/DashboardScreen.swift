import SwiftUI

struct DashboardScreen: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    @AppStorage("native-hide-money") private var hidden = false
    private var week: [String] {
        let day = CivilDate.day(), weekday = CivilDate.calendar.component(.weekday, from: CivilDate.date(day))
        let monday = CivilDate.adding(-((weekday + 5) % 7), to: day)
        return (0..<7).map { CivilDate.adding($0, to: monday) }
    }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: NativeDesign.gap) {
                HStack {
                    Text(CivilDate.monthTitle(CivilDate.month())).font(.subheadline)
                    Spacer()
                    Button { router.tab = .calendar } label: { HStack(spacing: 4) { Text("Questa settimana"); Image(systemName: "chevron.right") }.font(.caption) }.frame(minHeight: 44)
                }
                HStack(spacing: 5) {
                    ForEach(week, id: \.self) { day in
                        let today = day == CivilDate.day(), shift = store.shift(day)
                        Button {
                            store.calendarMonth = String(day.prefix(7)); router.calendarDay = day; router.tab = .calendar
                            Task { await store.sync(scope: .life) }
                        } label: {
                            VStack(spacing: 6) {
                                Text(["D", "L", "M", "M", "G", "V", "S"][CivilDate.calendar.component(.weekday, from: CivilDate.date(day)) - 1]).font(.caption2).foregroundStyle(NativeDesign.secondary)
                                Text(String(Int(day.suffix(2)) ?? 0)).font(.subheadline.weight(today ? .semibold : .regular))
                                NativeShiftBadge(shift: shift)
                                Circle().fill(store.events.contains { $0.text("day") == day } || store.tasks.contains { $0.text("scheduled_date") == day } ? (shift?.color ?? NativeDesign.accent) : Color.clear).frame(width: 4, height: 4)
                            }.frame(maxWidth: .infinity).frame(minHeight: 76)
                            .background(today ? (shift?.color ?? NativeDesign.accent).opacity(0.18) : NativeDesign.surface, in: RoundedRectangle(cornerRadius: NativeDesign.dayRadius, style: .continuous))
                            .overlay(RoundedRectangle(cornerRadius: NativeDesign.dayRadius, style: .continuous).stroke(today ? (shift?.color ?? NativeDesign.accent) : .clear, lineWidth: 1))
                        }.buttonStyle(NativePressStyle()).disabled(store.busy).accessibilityIdentifier("dashboard-day-" + day).accessibilityLabel(CivilDate.label(day))
                    }
                }.dynamicTypeSize(...DynamicTypeSize.xxxLarge).padding(.bottom, 4)
                NativeTodayPanel()
                NativeCard(material: true) {
                    HStack {
                        Text("Attività").font(NativeDesign.heading); Spacer()
                        Button { router.sheet = .task(["list_kind": .string("action")]) } label: { Image(systemName: "plus.circle").font(.title3).frame(width: 44, height: 36) }.accessibilityLabel("Nuova attività dalla Dashboard")
                    }
                    if store.highlights.isEmpty { Text("Tutto in ordine").font(.subheadline).foregroundStyle(NativeDesign.secondary) }
                    ForEach(store.highlights.map { DisplayRecord($0) }) { item in
                        let r = item.value
                        Divider()
                        HStack(spacing: 8) {
                            if r.text("highlightKind") == "task" {
                                Button { Task { await store.run("setTaskStatus", ["id": .int(r.integer("id")), "status": .string("done")]) } } label: { Image(systemName: "circle").font(.system(size: 22, weight: .regular)).foregroundStyle(NativeDesign.secondary).frame(width: 44, height: 44) }.disabled(store.busy).accessibilityLabel("Completa " + r.text("title"))
                            } else { NativeIcon(name: "calendar").frame(width: 44) }
                            Button { router.sheet = r.text("highlightKind") == "task" ? .task(r) : .event(r) } label: {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(r.text("title")).font(.subheadline).foregroundStyle(Color.primary)
                                    if !r.text("notes").isEmpty { Text(r.text("notes")).font(.caption).foregroundStyle(NativeDesign.secondary).lineLimit(1) }
                                    if r.text("highlightKind") == "event" { HStack { NativeDueBadge(day: r.text("day")); Text(r.text("start_time")).font(.caption).foregroundStyle(NativeDesign.secondary) } }
                                    else if !r.text("due_date").isEmpty { NativeDueBadge(day: r.text("due_date")) }
                                }.frame(maxWidth: .infinity, minHeight: 44, alignment: .leading).multilineTextAlignment(.leading)
                            }.buttonStyle(NativePressStyle())
                            Image(systemName: "chevron.right").font(.caption2).foregroundStyle(NativeDesign.secondary)
                        }
                    }
                    Divider()
                    Button { router.tab = .tasks } label: { Label("Vedi tutte", systemImage: "list.bullet").font(.subheadline).frame(maxWidth: .infinity, minHeight: 32, alignment: .leading) }
                }
                NativeCard(material: true) {
                    Button { router.tab = .finance } label: {
                        HStack {
                            NativeIcon(name: "wallet.bifold")
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Budget rimanente").font(.caption).foregroundStyle(NativeDesign.secondary)
                                Text(hidden ? "•••• €" : store.summary.amount("monthlyRemaining").euro).font(.title3.weight(.semibold)).monospacedDigit().foregroundStyle(Color.primary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right").font(.caption).foregroundStyle(NativeDesign.secondary)
                        }.frame(minHeight: 44)
                    }.buttonStyle(NativePressStyle())
                    if store.financeMonth != CivilDate.month() { Text(CivilDate.monthTitle(store.financeMonth)).font(.caption2).foregroundStyle(NativeDesign.secondary) }
                }
                NativeConnectionBadge()
                if let notice = store.notice { Text(notice).font(.caption).foregroundStyle(NativeDesign.secondary) }
            }.padding(.horizontal, 16).padding(.bottom, 84)
        }.background(NativeDesign.canvas).scrollBounceBehavior(.basedOnSize).accessibilityIdentifier("dashboard-scroll")
    }

}

enum SolarTimes {
    static func calculate(_ day: String) -> [(String, String)] {
        let deg = Double.pi / 180, lat = 43.7179, lon = 10.9478
        var utc = Calendar(identifier: .gregorian); utc.timeZone = TimeZone(secondsFromGMT: 0)!
        let parts = CivilDate.calendar.dateComponents([.year, .month, .day], from: CivilDate.date(day))
        let midnight = utc.date(from: DateComponents(year: parts.year, month: parts.month, day: parts.day))!
        let jd = midnight.timeIntervalSince1970 / 86400 + 2440587.5 - lon / 360
        func norm(_ x: Double, _ n: Double) -> Double { (x.truncatingRemainder(dividingBy: n) + n).truncatingRemainder(dividingBy: n) }
        func sun(_ t: Double) -> (Double, Double) {
            let d = jd + t / 24 - 2451545, g = norm(357.529 + 0.98560028 * d, 360), q = norm(280.459 + 0.98564736 * d, 360)
            let l = norm(q + 1.915 * sin(g * deg) + 0.02 * sin(2 * g * deg), 360), e = (23.439 - 0.00000036 * d) * deg
            let ra = norm(atan2(cos(e) * sin(l * deg), cos(l * deg)) / deg / 15, 24)
            return (asin(sin(e) * sin(l * deg)) / deg, q / 15 - ra)
        }
        func noon(_ t: Double) -> Double { norm(12 - sun(t).1, 24) }
        func angle(_ a: Double, _ t: Double, _ before: Bool) -> Double {
            let dec = sun(t).0 * deg, ratio = (-sin(a * deg) - sin(dec) * sin(lat * deg)) / (cos(dec) * cos(lat * deg))
            if abs(ratio) > 1 || !ratio.isFinite { return .nan }
            let delta = acos(max(-1, min(1, ratio))) / deg / 15
            return noon(t) + (before ? -delta : delta)
        }
        var times: [Double] = [5, 6, 12, 13, 18, 18]
        for _ in 0..<2 {
            let t = times.map { $0 / 24 }
            let altitude = -atan(1 / (1 + tan(abs(lat - sun(t[3]).0) * deg))) / deg
            times = [angle(14.5, t[0], true), angle(0.833, t[1], true), noon(t[2]), angle(altitude, t[3], false), angle(0.833, t[4], false), angle(14.8, t[5], false)]
        }
        let offset = Double(CivilDate.calendar.timeZone.secondsFromGMT(for: midnight.addingTimeInterval(43200))) / 3600
        let labels = ["Prima dell’alba", "Alba", "Mezzogiorno", "Pomeriggio", "Tramonto", "Notte"], adjustments = [0, -2, 1, 1, 2, 0]
        return times.enumerated().map { i, value in
            guard value.isFinite else { return (labels[i], "—") }
            let minutes = Int(norm(((value + offset - lon / 15) * 60 + Double(adjustments[i])).rounded(), 1440))
            return (labels[i], String(format: "%02d:%02d", minutes / 60, minutes % 60))
        }
    }
}
