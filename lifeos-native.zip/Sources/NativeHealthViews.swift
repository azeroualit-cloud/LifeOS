import SwiftUI
import Charts

struct NativeHealthCard: View {
    @ObservedObject var health: NativeHealthStore
    let demo: Bool
    private var latest: HealthDay? { health.days.last { $0.weight != nil } }
    var body: some View {
        NativeCard {
            HStack {
                Label("Peso e calorie", systemImage: "chart.xyaxis.line").font(NativeDesign.heading)
                Spacer()
                if health.loading { ProgressView().controlSize(.small) }
            }
            if demo { Text("Dati illustrativi · nessun accesso a Salute").font(.caption).foregroundStyle(NativeDesign.secondary) }
            ViewThatFits(in: .horizontal) {
                HStack(alignment: .top, spacing: NativeDesign.Space.large) { metrics }
                VStack(alignment: .leading, spacing: NativeDesign.Space.small) { metrics }
            }
            if let latest {
                Text("Ultima pesata: " + latest.date.formatted(date: .abbreviated, time: .omitted))
                    .font(.caption).foregroundStyle(NativeDesign.secondary)
            }
            if let estimate = health.estimate { Text("Scenario: media recente di " + estimate.averageIntake.formatted(.number.precision(.fractionLength(0))) + " kcal/giorno").font(.caption).foregroundStyle(NativeDesign.secondary) }
            if !health.days.isEmpty {
                NativeHealthChart(days: health.days, forecast: defaultForecast, target: health.estimate?.averageIntake, compact: true)
                NavigationLink { NativeHealthDetail(health: health, demo: demo) } label: {
                    HStack { Text("Esplora e simula"); Spacer(); NativeDisclosureIndicator() }
                        .frame(minHeight: NativeDesign.Layout.touchTarget)
                }.accessibilityIdentifier("home-health-detail")
            } else {
                Text(health.message ?? "Collega Salute per leggere peso e calorie assunte. I dati restano sul dispositivo.")
                    .font(.subheadline).foregroundStyle(NativeDesign.secondary)
            }
            if !demo {
                Button { Task { await health.connect() } } label: {
                    Label("Collega o gestisci Salute", systemImage: "heart")
                        .frame(minHeight: NativeDesign.Layout.touchTarget)
                }.disabled(health.loading).accessibilityIdentifier("health-connect")
            }
            if !health.days.isEmpty, let message = health.message { Text(message).font(.caption).foregroundStyle(NativeDesign.secondary) }
            if !health.days.isEmpty && health.estimate == nil {
                Text("TDEE in attesa: servono almeno 21 giorni, 10 pesate e calorie registrate ogni giorno fra la prima e l’ultima pesata. Le giornate devono essere complete.")
                    .font(.caption).foregroundStyle(NativeDesign.secondary)
            }
        }.accessibilityIdentifier("home-health")
    }
    @ViewBuilder private var metrics: some View {
        metric("Ultima pesata", latest?.weight.map { $0.formatted(.number.precision(.fractionLength(1))) + " kg" } ?? "—")
        metric("TDEE stimato", health.estimate.map { $0.tdee.formatted(.number.precision(.fractionLength(0))) + " kcal/giorno" } ?? "Dati insufficienti")
    }
    private func metric(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: NativeDesign.Space.xs) {
            Text(title).font(.caption).foregroundStyle(NativeDesign.secondary)
            Text(value).font(.headline).monospacedDigit().fixedSize(horizontal: false, vertical: true)
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
    private var defaultForecast: [HealthPoint] {
        guard let estimate = health.estimate else { return [] }
        return NativeHealthMath.forecast(estimate, intake: estimate.averageIntake)
    }
}

struct NativeHealthChart: View {
    let days: [HealthDay]
    let forecast: [HealthPoint]
    var target: Double? = nil
    var compact = false
    private var trend: [HealthPoint] { NativeHealthMath.trend(days) }
    private var start: Date { Calendar.current.date(byAdding: .day, value: -42, to: Calendar.current.startOfDay(for: Date()))! }
    private var end: Date { max(forecast.last?.date ?? Date(), Date()) }
    private var weightDomain: ClosedRange<Double> {
        let values = days.compactMap(\.weight) + forecast.map(\.value)
        return ((values.min() ?? 70) - 1)...((values.max() ?? 80) + 1)
    }
    private var maxCalories: Double { max(3000, max(target ?? 0, days.compactMap(\.calories).max() ?? 0) * 1.1) }
    var body: some View {
        VStack(alignment: .leading, spacing: NativeDesign.Space.small) {
            Text("Peso · kg").font(.caption).foregroundStyle(NativeDesign.secondary)
            if days.allSatisfy({ $0.weight == nil }) { Text("Nessuna pesata leggibile").font(.caption).foregroundStyle(NativeDesign.secondary) }
            Chart {
                ForEach(days.filter { $0.date >= start && $0.weight != nil }) { day in
                    PointMark(x: .value("Data", day.date), y: .value("Pesata", day.weight!))
                        .foregroundStyle(Color.secondary.opacity(0.45)).symbolSize(12)
                }
                ForEach(trend.filter { $0.date >= start }) { point in
                    LineMark(x: .value("Data", point.date), y: .value("Tendenza", point.value), series: .value("Serie", "Tendenza"))
                        .foregroundStyle(Color.blue)
                }
                ForEach(forecast) { point in
                    LineMark(x: .value("Data", point.date), y: .value("Scenario", point.value), series: .value("Serie", "Scenario"))
                        .foregroundStyle(Color.blue).lineStyle(StrokeStyle(lineWidth: 2, dash: [4, 4]))
                }
                RuleMark(x: .value("Oggi", Date())).foregroundStyle(Color.secondary.opacity(0.5))
            }.chartXScale(domain: start...end).chartYScale(domain: weightDomain)
                .chartXAxis(.hidden).frame(height: compact ? 120 : 190)
                .accessibilityLabel("Pesate, tendenza e scenario futuro tratteggiato, in chilogrammi")
            Text("Calorie assunte · kcal/giorno").font(.caption).foregroundStyle(NativeDesign.secondary)
            Chart {
                ForEach(days.filter { $0.date >= start && $0.calories != nil }) { day in
                    BarMark(x: .value("Data", day.date, unit: .day), y: .value("Calorie", day.calories!))
                        .foregroundStyle(Color.orange.opacity(0.7))
                }
                if let target, let first = forecast.first, let last = forecast.last {
                    LineMark(x: .value("Data", first.date), y: .value("Obiettivo", target)).foregroundStyle(Color.orange)
                    LineMark(x: .value("Data", last.date), y: .value("Obiettivo", target)).foregroundStyle(Color.orange)
                }
                RuleMark(x: .value("Oggi", Date())).foregroundStyle(Color.secondary.opacity(0.5))
            }.chartXScale(domain: start...end).chartYScale(domain: 0...maxCalories)
                .chartXAxis { AxisMarks(values: .stride(by: .weekOfYear, count: compact ? 4 : 2)) { _ in AxisValueLabel(format: .dateTime.day().month(.abbreviated)) } }
                .frame(height: compact ? 80 : 110)
                .accessibilityLabel("Calorie registrate per giorno; i giorni mancanti non sono zero")
            Text("Punti: pesate · blu: tendenza · tratteggio: scenario · arancio: calorie").font(.caption2).foregroundStyle(NativeDesign.secondary)
        }
    }
}

struct NativeHealthDetail: View {
    @ObservedObject var health: NativeHealthStore
    let demo: Bool
    @State private var intakeText = ""
    @FocusState private var editing: Bool
    private var intake: Double? {
        guard let value = Double(intakeText.replacingOccurrences(of: ",", with: ".")), value.isFinite, (800...6000).contains(value) else { return nil }
        return value
    }
    private var forecast: [HealthPoint] {
        guard let estimate = health.estimate, let intake else { return [] }
        return NativeHealthMath.forecast(estimate, intake: intake)
    }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: NativeDesign.Space.section) {
                if demo { Text("Dati illustrativi").font(.caption).foregroundStyle(NativeDesign.secondary) }
                if let estimate = health.estimate {
                    NativeCard {
                        Text("TDEE stimato").font(NativeDesign.heading)
                        Text(estimate.tdee.formatted(.number.precision(.fractionLength(0))) + " kcal/giorno").font(NativeDesign.value).monospacedDigit()
                        Text("Bilancio energetico su \(estimate.days) giorni completi fino al " + estimate.lastDate.formatted(date: .abbreviated, time: .omitted))
                            .font(.caption).foregroundStyle(NativeDesign.secondary)
                    }
                }
                NativeCard { NativeHealthChart(days: health.days, forecast: forecast, target: intake) }
                if let estimate = health.estimate {
                    NativeCard {
                        Text("Simula le calorie future").font(NativeDesign.heading)
                        HStack {
                            TextField("kcal/giorno", text: $intakeText).keyboardType(.decimalPad).focused($editing)
                                .textFieldStyle(.roundedBorder).accessibilityLabel("Calorie dello scenario").accessibilityIdentifier("health-intake")
                            Text("kcal/giorno").font(.subheadline)
                        }
                        Button("Usa media recente: " + estimate.averageIntake.formatted(.number.precision(.fractionLength(0))) + " kcal") {
                            intakeText = String(Int(estimate.averageIntake.rounded())); editing = false
                        }.frame(minHeight: NativeDesign.Layout.touchTarget)
                        if forecast.isEmpty { Text("Inserisci un valore fra 800 e 6.000 kcal/giorno. Questo intervallo è tecnico, non una raccomandazione alimentare.").font(.caption).foregroundStyle(NativeDesign.secondary) }
                        else {
                            ForEach([4, 8], id: \.self) { week in
                                if let point = forecast.dropFirst(week * 7).first {
                                    LabeledContent("Tra \(week) settimane dalla stima", value: point.value.formatted(.number.precision(.fractionLength(1))) + " kg")
                                }
                            }
                        }
                        Text("Scenario indicativo con attività invariata. Parte dal peso di tendenza dell’ultima giornata completa, non dall’ultima oscillazione della bilancia.")
                            .font(.caption).foregroundStyle(NativeDesign.secondary)
                    }
                } else {
                    Text("Per stimare TDEE e peso futuro servono almeno 21 giorni, 10 pesate recenti e calorie complete ogni giorno fra prima e ultima pesata. Oggi è escluso dal calcolo.").font(.subheadline).foregroundStyle(NativeDesign.secondary)
                }
                if !health.sources.isEmpty {
                    NativeCard {
                        Text("Fonte delle calorie").font(NativeDesign.heading)
                        Picker("App alimentare", selection: $health.selectedSource) {
                            ForEach(health.sources, id: \.self) { source in Text(health.sourceNames[source] ?? source).tag(source) }
                        }.pickerStyle(.menu).onChange(of: health.selectedSource) { _, _ in health.rebuild() }
                        Text("Usiamo una sola app per evitare doppioni. Verifica che contenga tutte le calorie assunte; una giornata registrata solo in parte altera la stima.").font(.caption).foregroundStyle(NativeDesign.secondary)
                    }
                }
                DisclosureGroup("Metodo e limiti") {
                    Text("Tendenza: mediana mobile di 7 giorni, senza separare esattamente acqua e tessuti. TDEE: introito medio meno variazione energetica stimata, usando 7.700 kcal/kg. Scenario dinamico: il dispendio cambia di 22 kcal/giorno per kg di variazione. È un’approssimazione ispirata al bilancio energetico e a Hall et al. (Lancet, 2011), non il modello NIH completo né una stima individuale validata. Errori nel diario, acqua e cambi di attività possono spostare il risultato. Non mostriamo intervalli statistici non calibrati. Le calorie di oggi possono essere parziali. I dati Salute sono solo in memoria sul dispositivo e non vengono inviati al server.")
                        .font(.footnote).foregroundStyle(NativeDesign.secondary)
                    Link("Studio di riferimento", destination: URL(string: "https://pmc.ncbi.nlm.nih.gov/articles/PMC3880593/")!)
                }
            }.padding(.horizontal, NativeDesign.Layout.screenInset).padding(.vertical, NativeDesign.Space.large)
        }.background(NativeDesign.canvas).navigationTitle("Peso e calorie").navigationBarTitleDisplayMode(.inline)
            .accessibilityIdentifier("health-detail-scroll")
            .toolbar { ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Fine") { editing = false } } }
            .task { if intakeText.isEmpty, let value = health.estimate?.averageIntake { intakeText = String(Int(value.rounded())) } }
    }
}
