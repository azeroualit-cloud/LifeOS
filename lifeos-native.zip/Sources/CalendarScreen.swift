import SwiftUI

struct CalendarScreen: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    @State private var selected = ""
    @State private var brush = "consult"
    @State private var lastShift: (String, String)?
    @State private var days: [CalendarDayPresentation] = []
    @State private var eventsByDay: [String: [Record]] = [:]
    @State private var tasksByDay: [String: [Record]] = [:]
    @ScaledMetric(relativeTo: .caption) private var brushWidth = 132.0
    @ScaledMetric(relativeTo: .caption) private var brushHeight = 64.0
    var body: some View {
        GeometryReader { geometry in
            let upperHeight = max(0, min(geometry.size.height * NativeDesign.Layout.calendarUpperFraction,
                                         geometry.size.height - NativeDesign.Layout.calendarDetailMinimum))
            VStack(spacing: NativeDesign.Space.none) {
                VStack(alignment: .leading, spacing: NativeDesign.Space.small) {
                    monthHeader
                    brushPanel
                    ScrollViewReader { proxy in
                        ScrollView { monthGrid }
                            .scrollBounceBehavior(.basedOnSize)
                            .accessibilityIdentifier("calendar-month-scroll")
                            .task(id: router.activationID) {
                                proxy.scrollTo(preferredDay(in: store.calendarMonth), anchor: .center)
                            }
                            .onChange(of: days.map(\.day)) { _, _ in
                                proxy.scrollTo(preferredDay(in: store.calendarMonth), anchor: .center)
                            }
                            .onChange(of: router.calendarDay) { _, day in
                                if day == CivilDate.day() { proxy.scrollTo(day, anchor: .center) }
                            }
                    }
                }.padding(.horizontal, NativeDesign.Layout.screenInset).padding(.top, NativeDesign.Space.xs)
                    .frame(height: upperHeight)
                Divider()
                VStack(alignment: .leading, spacing: NativeDesign.Space.none) {
                    dayHeading.padding(.horizontal, NativeDesign.Layout.screenInset).padding(.vertical, NativeDesign.Space.small)
                    ScrollView {
                        dayCard.padding(.horizontal, NativeDesign.Layout.screenInset).padding(.bottom, NativeDesign.Space.large)
                    }.scrollBounceBehavior(.basedOnSize).accessibilityIdentifier("calendar-scroll")
                }.frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)

            }
        }.background(NativeDesign.canvas)
        .onAppear { rebuildMonth(); selected = preferredDay(in: store.calendarMonth); router.calendarDay = selected }
        .onChange(of: selected) { _, day in router.calendarDay = day }
        .onChange(of: router.calendarDay) { _, day in if day.hasPrefix(store.calendarMonth) { selected = day } }
        .onChange(of: store.calendarMonth) { _, month in rebuildMonth(); selected = preferredDay(in: month) }
        .onChange(of: store.life) { _, _ in rebuildMonth() }
    }
    private func preferredDay(in month: String) -> String {
        if router.calendarDay.hasPrefix(month) { return router.calendarDay }
        if CivilDate.day().hasPrefix(month) { return CivilDate.day() }
        return month + "-01"
    }
    private func rebuildMonth() {
        // Build the date labels and indexes only when the month or source data changes.
        // A day selection must not parse and format every date in the grid again.
        eventsByDay = Dictionary(grouping: store.events, by: { $0.text("day") })
        tasksByDay = Dictionary(grouping: store.tasks, by: { $0.text("scheduled_date") })
        let shifts = Dictionary(store.life.records("shifts").map { ($0.text("day"), $0.text("kind")) }, uniquingKeysWith: { first, _ in first })
        let today = CivilDate.day(), month = store.calendarMonth
        days = CivilDate.grid(month).map { day in
            let weekday = CivilDate.calendar.component(.weekday, from: CivilDate.date(day))
            return CalendarDayPresentation(day: day, label: CivilDate.label(day), shift: shifts[day].flatMap(ShiftKind.init(rawValue:)), hasEvents: !(eventsByDay[day] ?? []).isEmpty || !(tasksByDay[day] ?? []).isEmpty, isToday: day == today, isWeekend: weekday == 1 || weekday == 7, isCurrentMonth: day.hasPrefix(month))
        }
    }
    private var monthHeader: some View {
        HStack(alignment: .firstTextBaseline, spacing: NativeDesign.Space.small) {
            ViewThatFits(in: .horizontal) {
                HStack(alignment: .firstTextBaseline, spacing: NativeDesign.Space.small) { monthName; yearLabel }
                VStack(alignment: .leading, spacing: NativeDesign.Space.xs) { monthName; yearLabel }
            }.accessibilityRepresentation { Text(CivilDate.monthTitle(store.calendarMonth)) }
            Spacer(minLength: NativeDesign.Space.small)
            NativeIconButton(symbol: "chevron.left", label: "Mese precedente") { Task { await store.changeMonth(-1, finance: false) } }
            NativeIconButton(symbol: "chevron.right", label: "Mese successivo") { Task { await store.changeMonth(1, finance: false) } }
        }.disabled(store.busy).accessibilityElement(children: .contain)
    }
    private var monthName: some View {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "it_IT"); formatter.timeZone = CivilDate.calendar.timeZone; formatter.dateFormat = "LLLL"
        return Text(formatter.string(from: CivilDate.date(store.calendarMonth + "-01")).capitalized)
            .font(.largeTitle.weight(.bold)).lineLimit(1).minimumScaleFactor(0.7)
    }
    private var yearLabel: some View { Text(String(store.calendarMonth.prefix(4))).font(.title3).foregroundStyle(NativeDesign.secondary) }
    private func goToToday() {
        let today = CivilDate.day(), month = String(today.prefix(7))
        let delta = CivilDate.calendar.dateComponents([.month], from: CivilDate.date(store.calendarMonth + "-01"), to: CivilDate.date(month + "-01")).month ?? 0
        Task {
            if delta != 0 { await store.changeMonth(delta, finance: false) }
            guard store.calendarMonth == month else { return }
            var transaction = Transaction(animation: nil); transaction.disablesAnimations = true
            withTransaction(transaction) { selected = today; router.calendarDay = today }
        }
    }
    private var monthGrid: some View {
        Grid(horizontalSpacing: NativeDesign.Space.xs, verticalSpacing: NativeDesign.Space.none) {
            GridRow {
                ForEach(Array(["L", "M", "M", "G", "V", "S", "D"].enumerated()), id: \.offset) { _, name in
                    Text(name).font(.caption).foregroundStyle(NativeDesign.secondary).frame(maxWidth: .infinity).padding(.vertical, NativeDesign.Space.small)
                }
            }
            GridRow { Divider().gridCellColumns(7).gridCellUnsizedAxes(.horizontal) }
            ForEach(0..<(days.count / 7), id: \.self) { week in
                GridRow {
                    ForEach(0..<7, id: \.self) { index in
                        let item = days[week * 7 + index]
                        let day = item.day
                        Button {
                            var transaction = Transaction(animation: nil); transaction.disablesAnimations = true
                            withTransaction(transaction) { selected = day; router.calendarDay = day }
                            if brush != "consult" {
                                lastShift = (day, store.shift(day)?.rawValue ?? "erase")
                                Task { await store.run("paintShift", ["day": .string(day), "kind": .string(brush)]) }
                            }
                        } label: { CalendarDayCell(item: item, active: selected == day).equatable() }
                        .buttonStyle(.plain).disabled(store.busy && brush != "consult")
                        .id(day).accessibilityIdentifier("calendar-day-" + day)
                        .accessibilityLabel(item.label + ", " + (item.shift?.title ?? "nessun turno"))
                    }
                }
                GridRow { Divider().gridCellColumns(7).gridCellUnsizedAxes(.horizontal) }
            }
        }.dynamicTypeSize(...DynamicTypeSize.xxxLarge)
    }
    @State private var painting = false
    private var brushPanel: some View {
        VStack(alignment: .leading, spacing: NativeDesign.Space.small) {
            HStack(spacing: NativeDesign.Space.large) {
                Button(action: goToToday) {
                    Text("Oggi").frame(minWidth: NativeDesign.Layout.touchTarget, minHeight: NativeDesign.Layout.touchTarget).contentShape(Rectangle())
                }
                    .accessibilityIdentifier("calendar-today").disabled(store.busy)
                Button { painting.toggle(); if !painting { brush = "consult" } else { brush = "morning" } } label: { Label(painting ? "Fine" : "Dipingi turni", systemImage: "paintbrush.pointed").frame(minHeight: NativeDesign.Layout.touchTarget).contentShape(Rectangle()) }.accessibilityIdentifier("toggle-shift-paint")
                Spacer()
                if let lastShift { Button("Annulla") { Task { await store.run("paintShift", ["day": .string(lastShift.0), "kind": .string(lastShift.1)]); self.lastShift = nil } }.disabled(store.busy) }
            }.font(.subheadline).frame(minHeight: NativeDesign.Layout.touchTarget)
            if painting {
                Text("Scegli un turno, poi tocca i giorni da assegnare. Usa Cancella per rimuoverlo.").font(.caption).foregroundStyle(NativeDesign.secondary)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: NativeDesign.Space.small) { ForEach(ShiftKind.allCases) { kind in
                        Button { brush = kind.rawValue } label: {
                            VStack(spacing: NativeDesign.Space.xs) {
                                Label { Text(kind.title).foregroundStyle(Color.primary) } icon: { Image(systemName: kind.symbol).foregroundStyle(kind.color) }.font(.caption.weight(.semibold))
                                if !kind.time.isEmpty { Text(kind.time).font(.caption2).foregroundStyle(NativeDesign.secondary) }
                            }
                                .padding(NativeDesign.Space.medium).frame(width: brushWidth, height: brushHeight)
                                .modifier(NativeSelectionSurface(selected: brush == kind.rawValue, tint: kind.color, outlined: true))
                        }.buttonStyle(NativePressStyle()).foregroundStyle(kind.color).accessibilityIdentifier("shift-brush-" + kind.rawValue).accessibilityAddTraits(brush == kind.rawValue ? .isSelected : [])
                    } }
                }
            }
        }.buttonStyle(NativePressStyle())
    }
    private var dayHeading: some View {
            HStack {
                Text(CivilDate.label(selected)).font(NativeDesign.heading)
                Spacer()
                if painting { Label("Pennello attivo", systemImage: "paintbrush.pointed").font(.caption).foregroundStyle(NativeDesign.accent) }
            }
    }
    private var dayCard: some View {
        VStack(alignment: .leading, spacing: NativeDesign.Space.medium) {
            if let shift = store.shift(selected) {
                HStack(spacing: NativeDesign.Space.small) {
                    RoundedRectangle(cornerRadius: NativeDesign.progressRadius).fill(shift.color)
                        .frame(width: NativeDesign.Layout.calendarMarker, height: NativeDesign.Layout.touchTarget).accessibilityHidden(true)
                    Image(systemName: shift.symbol).font(NativeDesign.symbol).foregroundStyle(shift.color)
                        .frame(width: NativeDesign.Layout.touchTarget).accessibilityHidden(true)
                    ViewThatFits(in: .horizontal) {
                        HStack(alignment: .firstTextBaseline) {
                            VStack(alignment: .leading, spacing: NativeDesign.Space.xs) { Text(shift.title).font(NativeDesign.body); Text("Turno").font(.caption).foregroundStyle(NativeDesign.secondary) }
                            Spacer(minLength: NativeDesign.Space.small)
                            Text(shift.time).font(.subheadline).monospacedDigit().foregroundStyle(NativeDesign.secondary)
                        }
                        VStack(alignment: .leading, spacing: NativeDesign.Space.xs) {
                            Text(shift.title).font(NativeDesign.body)
                            Text(shift.time.isEmpty ? "Turno" : shift.time).font(.subheadline).monospacedDigit().foregroundStyle(NativeDesign.secondary)
                        }
                    }
                }.frame(minHeight: NativeDesign.Layout.touchTarget).accessibilityElement(children: .combine)
                Divider()
            }
            let dayEvents = eventsByDay[selected] ?? []
            let dayTasks = tasksByDay[selected] ?? []
            ForEach(dayEvents.map { DisplayRecord($0) }) { item in eventRow(item.value); Divider() }
            ForEach(dayTasks.map { DisplayRecord($0) }) { item in
                NativeChecklistRow(title: item.value.text("title"), checked: item.value.text("status") == "done", completionLabel: "Cambia completamento " + item.value.text("title"), onComplete: {
                    Task { await store.run("setTaskStatus", ["id": .int(item.value.integer("id")), "status": .string(item.value.text("status") == "done" ? "todo" : "done")]) }
                }, onOpen: { router.sheet = .task(item.value) }).disabled(store.busy)
                Divider()
            }
            Button { router.sheet = .event(["day": .string(selected)]) } label: {
                HStack(spacing: NativeDesign.Space.small) {
                    Image(systemName: "plus.circle").font(NativeDesign.symbol).frame(width: NativeDesign.Layout.touchTarget)
                    Text("Aggiungi evento").font(NativeDesign.body)
                }.frame(maxWidth: .infinity, minHeight: NativeDesign.Layout.touchTarget, alignment: .leading)
            }.buttonStyle(NativePressStyle()).accessibilityIdentifier("calendar-add-event")
        }.padding(.top, NativeDesign.Space.small)
    }
    private func eventRow(_ r: Record) -> some View {
        let time = r.text("start_time"), location = r.text("location")
        return HStack(spacing: NativeDesign.Space.small) {
            RoundedRectangle(cornerRadius: NativeDesign.progressRadius).fill(NativeDesign.accent.opacity(0.65))
                .frame(width: NativeDesign.Layout.calendarMarker, height: NativeDesign.Layout.touchTarget).accessibilityHidden(true)
            NativeCompletionButton(checked: r.text("occurrence_status") == "done", label: "Cambia completamento evento " + r.text("title")) {
                Task { await store.run("setEventOccurrence", ["id": .int(r.integer("id")), "day": .string(r.text("day")), "status": .string(r.text("occurrence_status") == "done" ? "open" : "done")]) }
            }.accessibilityIdentifier("event-check-" + String(r.integer("id")))
            Button { router.sheet = .event(r) } label: {
                ViewThatFits(in: .horizontal) {
                    HStack(alignment: .center, spacing: NativeDesign.Space.small) {
                        NativeRowText(title: r.text("title"), subtitle: location, completed: r.text("occurrence_status") == "done", titleIdentifier: "event-title-" + String(r.integer("id")))
                        Text(time.isEmpty ? "Tutto il giorno" : time).font(.subheadline).monospacedDigit().foregroundStyle(NativeDesign.secondary).fixedSize()
                    }
                    VStack(alignment: .leading, spacing: NativeDesign.Space.xs) {
                        NativeRowText(title: r.text("title"), subtitle: location, completed: r.text("occurrence_status") == "done", titleIdentifier: "event-title-" + String(r.integer("id")))
                        Text(time.isEmpty ? "Tutto il giorno" : time).font(.subheadline).monospacedDigit().foregroundStyle(NativeDesign.secondary)
                    }
                }.frame(maxWidth: .infinity, minHeight: NativeDesign.Layout.touchTarget, alignment: .leading).contentShape(Rectangle())
            }.buttonStyle(.borderless).accessibilityLabel(r.text("title"))
                .accessibilityValue([time.isEmpty ? "Tutto il giorno" : time, location].filter { !$0.isEmpty }.joined(separator: ", "))
        }.disabled(store.busy)
    }

}
struct CalendarDayPresentation: Equatable {
    let day: String
    let label: String
    let shift: ShiftKind?
    let hasEvents: Bool
    let isToday: Bool
    let isWeekend: Bool
    let isCurrentMonth: Bool
}
struct CalendarDayCell: View, Equatable {
    let item: CalendarDayPresentation
    let active: Bool
    @ScaledMetric(relativeTo: .subheadline) private var numberSize = NativeDesign.Layout.calendarDayNumber
    static func == (lhs: Self, rhs: Self) -> Bool { lhs.item == rhs.item && lhs.active == rhs.active }
    var body: some View {
        let color = item.shift?.color ?? NativeDesign.accent
        VStack(spacing: NativeDesign.Space.xxs) {
            Text(String(Int(item.day.suffix(2)) ?? 0)).font(.subheadline.weight(active || item.isToday ? .semibold : .regular)).monospacedDigit()
                .foregroundStyle(active ? NativeDesign.canvas : item.isWeekend ? NativeDesign.secondary : Color.primary)
                .minimumScaleFactor(0.8).lineLimit(1).frame(width: numberSize, height: numberSize)
                .background(active ? NativeDesign.accent : .clear, in: Circle())
                .overlay(Circle().stroke(item.isToday && !active ? NativeDesign.accent : .clear, lineWidth: 1))
            NativeShiftBadge(shift: item.shift)
            Circle().fill(item.hasEvents ? color : Color.clear).frame(width: NativeDesign.Space.xs, height: NativeDesign.Space.xs)
        }.frame(maxWidth: .infinity).frame(minHeight: NativeDesign.Layout.calendarDayHeight)
            .contentShape(Rectangle()).opacity(item.isCurrentMonth ? 1 : 0.38)
            .accessibilityAddTraits(active ? .isSelected : [])
    }
}
struct EventEditor: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    let record: Record
    @State private var title = ""
    @State private var location = ""
    @State private var notes = ""
    @State private var date = Date()
    @State private var start = Date()
    @State private var end = Date()
    @State private var hasTime = false
    @State private var hasEnd = false
    @State private var frequency = "none"
    @State private var until = Date()
    @State private var hasUntil = false
    @State private var fromHere = false
    @State private var saving = false
    @State private var error: String?
    @State private var confirmDelete = false
    var body: some View {
        Form {
            Section { TextField("Titolo", text: $title); DatePicker("Giorno", selection: $date, displayedComponents: .date); TextField("Luogo", text: $location) }
            Section("Orario") {
                Toggle("Ora iniziale", isOn: $hasTime)
                if hasTime {
                    DatePicker("Inizio", selection: $start, displayedComponents: .hourAndMinute)
                    Toggle("Ora finale", isOn: $hasEnd)
                    if hasEnd { DatePicker("Fine", selection: $end, displayedComponents: .hourAndMinute) }
                }
            }
            Section("Ripetizione") {
                Picker("Frequenza", selection: $frequency) { Text("Mai").tag("none"); Text("Ogni settimana").tag("weekly"); Text("Ogni mese").tag("monthly"); Text("Ogni anno").tag("yearly") }
                if frequency != "none" { Toggle("Data finale", isOn: $hasUntil); if hasUntil { DatePicker("Fino al", selection: $until, in: date..., displayedComponents: .date) } }
                if record.integer("id") > 0 && record.text("frequency", fallback: "none") != "none" {
                    Toggle("Modifica da questa occorrenza", isOn: $fromHere)
                    Text("Le occorrenze precedenti restano nello storico.").font(.caption).foregroundStyle(NativeDesign.secondary)
                }
            }
            Section("Note") { TextEditor(text: $notes).frame(minHeight: 90) }
            if record.integer("id") > 0 {
                Section {
                    Button(record.text("occurrence_status") == "done" ? "Riapri questa occorrenza" : "Segna fatta questa occorrenza") {
                        Task { await store.run("setEventOccurrence", ["id": .int(record.integer("id")), "day": .string(record.text("day")), "status": .string(record.text("occurrence_status") == "done" ? "open" : "done")]); if store.error == nil { dismiss() } }
                    }
                    Button("Elimina solo questa occorrenza", role: .destructive) { Task { await store.run("setEventOccurrence", ["id": .int(record.integer("id")), "day": .string(record.text("day")), "status": .string("skipped")]); if store.error == nil { dismiss() } } }
                    Button("Elimina intera serie", role: .destructive) { confirmDelete = true }
                }.disabled(saving || store.busy)
            }
            if let error { NativeInlineMessage(text: error) }
        }.modifier(NativeListAppearance()).navigationTitle(record.integer("id") > 0 ? "Modifica evento" : "Nuovo evento").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() }.disabled(saving) }
            ToolbarItem(placement: .confirmationAction) { Button("Salva") { Task { await save() } }.disabled(saving || store.busy || title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
        }
        .confirmationDialog("Eliminare la serie e tutti gli stati delle occorrenze?", isPresented: $confirmDelete, titleVisibility: .visible) { Button("Elimina serie", role: .destructive) { Task { await store.run("deleteEvent", args: [.int(record.integer("id"))]); if store.error == nil { dismiss() } } } }
        .onChange(of: fromHere) { _, value in date = CivilDate.date(value ? record.text("day") : record.text("series_day", fallback: record.text("day"))) }
        .onAppear {
            title = record.text("title"); location = record.text("location"); notes = record.text("notes")
            date = CivilDate.date(record.text("series_day", fallback: record.text("day", fallback: CivilDate.day())))
            frequency = record.text("frequency", fallback: "none"); hasTime = !record.text("start_time").isEmpty; hasEnd = !record.text("end_time").isEmpty
            start = clockDate(record.text("start_time", fallback: "09:00")); end = clockDate(record.text("end_time", fallback: "10:00"))
            hasUntil = !record.text("until_day").isEmpty; until = CivilDate.date(record.text("until_day", fallback: CivilDate.adding(365, to: CivilDate.day())))
        }
    }
    private func clockDate(_ text: String) -> Date {
        let parts = text.split(separator: ":").compactMap { Int($0) }
        return CivilDate.calendar.date(bySettingHour: parts.first ?? 9, minute: parts.last ?? 0, second: 0, of: Date()) ?? Date()
    }
    private func clock(_ date: Date) -> String {
        let parts = CivilDate.calendar.dateComponents([.hour, .minute], from: date)
        return String(format: "%02d:%02d", parts.hour ?? 0, parts.minute ?? 0)
    }
    private func save() async {
        saving = true; defer { saving = false }
        var payload: Record = ["id": .int(record.integer("id")), "title": .string(title), "day": .string(CivilDate.day(date)), "location": .string(location), "notes": .string(notes),
            "start_time": hasTime ? .string(clock(start)) : .null, "end_time": hasTime && hasEnd ? .string(clock(end)) : .null,
            "frequency": .string(frequency), "until_day": hasUntil && frequency != "none" ? .string(CivilDate.day(until)) : .null]
        if fromHere { payload["split_from"] = record["day"] }
        do { try await store.perform(fromHere ? "splitEventSeries" : "saveEvent", payload); dismiss() }
        catch { self.error = error.localizedDescription }
    }
}
