import SwiftUI

struct CalendarScreen: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    @State private var selected = ""
    @State private var brush = "consult"
    @State private var lastShift: (String, String)?
    @State private var days: [CalendarDayPresentation] = []
    @State private var eventsByDay: [String: [Record]] = [:]
    @State private var tasksByDay: [String: [Record]] = [:]
    @ScaledMetric(relativeTo: .caption) private var brushWidth = 132.0
    @ScaledMetric(relativeTo: .caption) private var brushHeight = 64.0
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                MonthControl(finance: false)
                brushPanel
                monthGrid
                dayCard
            }.padding(.horizontal, 16).padding(.top, 4).padding(.bottom, 84)
        }.background(NativeDesign.canvas).scrollBounceBehavior(.basedOnSize).accessibilityIdentifier("calendar-scroll")
        .onAppear { rebuildMonth(); selected = preferredDay(in: store.calendarMonth); router.calendarDay = selected }
        .onChange(of: selected) { _, day in router.calendarDay = day }
        .onChange(of: router.calendarDay) { _, day in if day.hasPrefix(store.calendarMonth) { selected = day } }
        .onChange(of: store.calendarMonth) { _, month in rebuildMonth(); selected = preferredDay(in: month) }
        .onChange(of: store.life) { _, _ in rebuildMonth() }
    }
    private func preferredDay(in month: String) -> String {
        if router.calendarDay.hasPrefix(month) { return router.calendarDay }
        if CivilDate.day().hasPrefix(month) { return CivilDate.day() }
        return month + "-01"
    }
    private func rebuildMonth() {
        // Build the date labels and indexes only when the month or source data changes.
        // A day selection must not parse and format every date in the grid again.
        eventsByDay = Dictionary(grouping: store.events, by: { $0.text("day") })
        tasksByDay = Dictionary(grouping: store.tasks, by: { $0.text("scheduled_date") })
        let shifts = Dictionary(store.life.records("shifts").map { ($0.text("day"), $0.text("kind")) }, uniquingKeysWith: { first, _ in first })
        let today = CivilDate.day(), month = store.calendarMonth
        days = CivilDate.grid(month).map { day in
            let weekday = CivilDate.calendar.component(.weekday, from: CivilDate.date(day))
            return CalendarDayPresentation(day: day, label: CivilDate.label(day), shift: shifts[day].flatMap(ShiftKind.init(rawValue:)), hasEvents: !(eventsByDay[day] ?? []).isEmpty || !(tasksByDay[day] ?? []).isEmpty, isToday: day == today, isWeekend: weekday == 1 || weekday == 7, isCurrentMonth: day.hasPrefix(month))
        }
    }
    private var monthGrid: some View {
        Grid(horizontalSpacing: 4, verticalSpacing: 6) {
                    GridRow {
                        ForEach(Array(["L", "M", "M", "G", "V", "S", "D"].enumerated()), id: \.offset) { _, name in
                            Text(name).font(.caption).foregroundStyle(NativeDesign.secondary).frame(maxWidth: .infinity)
                        }
                    }
                    ForEach(0..<(days.count / 7), id: \.self) { week in
                        GridRow {
                            ForEach(0..<7, id: \.self) { index in
                                let item = days[week * 7 + index]
                                let day = item.day
                                Button {
                                    var transaction = Transaction(animation: nil)
                                    transaction.disablesAnimations = true
                                    withTransaction(transaction) { selected = day; router.calendarDay = day }
                                    if brush != "consult" {
                                        lastShift = (day, store.shift(day)?.rawValue ?? "erase")
                                        Task { await store.run("paintShift", ["day": .string(day), "kind": .string(brush)]) }
                                    }
                                } label: { CalendarDayCell(item: item, active: selected == day).equatable() }
                                .buttonStyle(.plain).disabled(store.busy && brush != "consult")
                                .accessibilityIdentifier("calendar-day-" + day)
                                .accessibilityLabel(item.label + ", " + (item.shift?.title ?? "nessun turno"))
                            }
                        }
                    }
                }.dynamicTypeSize(...DynamicTypeSize.xxxLarge)
    }
    @State private var painting = false
    private var brushPanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Button { painting.toggle(); if !painting { brush = "consult" } else { brush = "morning" } } label: { Label(painting ? "Fine" : "Dipingi turni", systemImage: "paintbrush.pointed") }.accessibilityIdentifier("toggle-shift-paint")
                Spacer()
                if let lastShift { Button("Annulla") { Task { await store.run("paintShift", ["day": .string(lastShift.0), "kind": .string(lastShift.1)]); self.lastShift = nil } }.disabled(store.busy) }
            }.font(.subheadline).frame(minHeight: 44)
            if painting {
                Text("Scegli un turno, poi tocca i giorni da assegnare. Usa Cancella per rimuoverlo.").font(.caption).foregroundStyle(NativeDesign.secondary)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) { ForEach(ShiftKind.allCases) { kind in
                        Button { brush = kind.rawValue } label: {
                            VStack(spacing: 4) {
                                Label { Text(kind.title).foregroundStyle(Color.primary) } icon: { Image(systemName: kind.symbol).foregroundStyle(kind.color) }.font(.caption.weight(.semibold))
                                if !kind.time.isEmpty { Text(kind.time).font(.caption2).foregroundStyle(NativeDesign.secondary) }
                            }
                                .padding(10).frame(width: brushWidth, height: brushHeight).background(kind.color.opacity(brush == kind.rawValue ? 0.3 : 0.1), in: RoundedRectangle(cornerRadius: NativeDesign.controlRadius, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: NativeDesign.controlRadius, style: .continuous).stroke(brush == kind.rawValue ? kind.color : .clear, lineWidth: 1.5))
                        }.buttonStyle(NativePressStyle()).foregroundStyle(kind.color).accessibilityIdentifier("shift-brush-" + kind.rawValue).accessibilityAddTraits(brush == kind.rawValue ? .isSelected : [])
                    } }
                }
            }
        }.buttonStyle(NativePressStyle())
    }
    private var dayCard: some View {
        return NativeCard {
                    HStack {
                        Text(CivilDate.label(selected)).font(.subheadline.weight(.semibold))
                        Spacer()
                        if painting { Label("Pennello attivo", systemImage: "paintbrush.pointed").font(.caption).foregroundStyle(NativeDesign.accent) }
                    }
                    if let shift = store.shift(selected) {
                        HStack(spacing: 8) {
                            NativeIcon(name: shift.symbol, color: shift.color).frame(width: 44)
                            Text(shift.title + (shift.time.isEmpty ? "" : " · " + shift.time)).font(NativeDesign.body).foregroundStyle(Color.primary)
                            Spacer()
                        }
                    }
                    let dayEvents = eventsByDay[selected] ?? []
                    let dayTasks = tasksByDay[selected] ?? []
                    ForEach(dayEvents.map { DisplayRecord($0) }) { item in eventRow(item.value) }
                    ForEach(dayTasks.map { DisplayRecord($0) }) { item in
                        Button { router.sheet = .task(item.value) } label: {
                            HStack(spacing: 8) {
                                NativeIcon(name: item.value.text("status") == "done" ? "checkmark.circle" : "checklist").frame(width: 44)
                                Text(item.value.text("title")).font(NativeDesign.body).foregroundStyle(Color.primary)
                            }.frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                        }.buttonStyle(NativePressStyle())
                    }
                    Divider()
                    Button { router.sheet = .event(["day": .string(selected)]) } label: {
                        HStack(spacing: 8) {
                            Image(systemName: "plus.circle").font(NativeDesign.symbol).frame(width: 44)
                            Text("Aggiungi evento").font(NativeDesign.body)
                        }.frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                    }.buttonStyle(NativePressStyle()).accessibilityIdentifier("calendar-add-event")
                }
    }
    private func eventRow(_ r: Record) -> some View {
        HStack(spacing: 8) {
            Button { Task { await store.run("setEventOccurrence", ["id": .int(r.integer("id")), "day": .string(r.text("day")), "status": .string(r.text("occurrence_status") == "done" ? "open" : "done")]) } } label: {
                Image(systemName: r.text("occurrence_status") == "done" ? "checkmark.circle" : "circle").font(.system(size: 22, weight: .regular)).frame(width: 44, height: 44)
            }.buttonStyle(NativePressStyle()).accessibilityLabel("Cambia completamento evento").accessibilityIdentifier("event-check-" + String(r.integer("id")))
            Button { router.sheet = .event(r) } label: {
                VStack(alignment: .leading, spacing: 3) {
                    Text(r.text("title")).strikethrough(r.text("occurrence_status") == "done").font(.subheadline).accessibilityIdentifier("event-title-" + String(r.integer("id")))
                    let metadata = [r.text("start_time"), r.text("location")].filter { !$0.isEmpty }.joined(separator: " · ")
                    if !metadata.isEmpty { Text(metadata).font(.caption).foregroundStyle(NativeDesign.secondary) }
                }.frame(maxWidth: .infinity, minHeight: 44, alignment: .leading).multilineTextAlignment(.leading).foregroundStyle(Color.primary)
            }.buttonStyle(NativePressStyle())
        }.disabled(store.busy)
    }
}
private struct CalendarDayPresentation: Equatable {
    let day: String
    let label: String
    let shift: ShiftKind?
    let hasEvents: Bool
    let isToday: Bool
    let isWeekend: Bool
    let isCurrentMonth: Bool
}
private struct CalendarDayCell: View, Equatable {
    let item: CalendarDayPresentation
    let active: Bool
    var body: some View {
        let color = item.shift?.color ?? NativeDesign.accent
        VStack(spacing: 5) {
            Text(String(Int(item.day.suffix(2)) ?? 0)).font(.subheadline.weight(active || item.isToday ? .semibold : .regular)).monospacedDigit()
            NativeShiftBadge(shift: item.shift)
            Circle().fill(item.hasEvents ? color : Color.clear).frame(width: 4, height: 4)
        }.frame(maxWidth: .infinity).frame(height: 66)
            .background(active ? color.opacity(0.18) : item.isWeekend ? Color.secondary.opacity(0.09) : Color.clear, in: RoundedRectangle(cornerRadius: NativeDesign.dayRadius, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: NativeDesign.dayRadius, style: .continuous).stroke(active ? color.opacity(0.9) : item.isToday ? color.opacity(0.45) : .clear, lineWidth: active ? 1.5 : 1))
            .opacity(item.isCurrentMonth ? 1 : 0.38).accessibilityAddTraits(active ? .isSelected : [])
    }
}
extension ShiftKind {
    // Same hues as the original Life OS palette, with a restrained saturation increase.
    var color: Color {
        let light: UInt32, dark: UInt32
        switch self {
        case .morning: light = 0x8FACD9; dark = 0x639BCF
        case .afternoon: light = 0x9BCB83; dark = 0x6CAF7A
        case .night: light = 0x727780; dark = 0xADB2BC
        case .rest: light = 0xE79862; dark = 0xDF986D
        case .holiday: light = 0xA88B18; dark = 0xDEC34E
        case .erase: return .secondary
        }
        return Color(uiColor: UIColor { traits in
            let hex = traits.userInterfaceStyle == .dark ? dark : light
            return UIColor(red: Double((hex >> 16) & 255) / 255, green: Double((hex >> 8) & 255) / 255, blue: Double(hex & 255) / 255, alpha: 1)
        })
    }
    var symbol: String {
        switch self { case .morning: return "sunrise"; case .afternoon: return "sun.max"; case .night: return "moon"; case .rest: return "leaf"; case .holiday: return "sun.horizon"; case .erase: return "eraser" }
    }
}
struct EventEditor: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    let record: Record
    @State private var title = ""
    @State private var location = ""
    @State private var notes = ""
    @State private var date = Date()
    @State private var start = Date()
    @State private var end = Date()
    @State private var hasTime = false
    @State private var hasEnd = false
    @State private var frequency = "none"
    @State private var until = Date()
    @State private var hasUntil = false
    @State private var fromHere = false
    @State private var saving = false
    @State private var error: String?
    @State private var confirmDelete = false
    var body: some View {
        Form {
            Section { TextField("Titolo", text: $title); DatePicker("Giorno", selection: $date, displayedComponents: .date); TextField("Luogo", text: $location) }
            Section("Orario") {
                Toggle("Ora iniziale", isOn: $hasTime)
                if hasTime {
                    DatePicker("Inizio", selection: $start, displayedComponents: .hourAndMinute)
                    Toggle("Ora finale", isOn: $hasEnd)
                    if hasEnd { DatePicker("Fine", selection: $end, displayedComponents: .hourAndMinute) }
                }
            }
            Section("Ripetizione") {
                Picker("Frequenza", selection: $frequency) { Text("Mai").tag("none"); Text("Ogni settimana").tag("weekly"); Text("Ogni mese").tag("monthly"); Text("Ogni anno").tag("yearly") }
                if frequency != "none" { Toggle("Data finale", isOn: $hasUntil); if hasUntil { DatePicker("Fino al", selection: $until, in: date..., displayedComponents: .date) } }
                if record.integer("id") > 0 && record.text("frequency", fallback: "none") != "none" {
                    Toggle("Modifica da questa occorrenza", isOn: $fromHere)
                    Text("Le occorrenze precedenti restano nello storico.").font(.caption).foregroundStyle(NativeDesign.secondary)
                }
            }
            Section("Note") { TextEditor(text: $notes).frame(minHeight: 90) }
            if record.integer("id") > 0 {
                Section {
                    Button(record.text("occurrence_status") == "done" ? "Riapri questa occorrenza" : "Segna fatta questa occorrenza") {
                        Task { await store.run("setEventOccurrence", ["id": .int(record.integer("id")), "day": .string(record.text("day")), "status": .string(record.text("occurrence_status") == "done" ? "open" : "done")]); if store.error == nil { dismiss() } }
                    }
                    Button("Elimina solo questa occorrenza", role: .destructive) { Task { await store.run("setEventOccurrence", ["id": .int(record.integer("id")), "day": .string(record.text("day")), "status": .string("skipped")]); if store.error == nil { dismiss() } } }
                    Button("Elimina intera serie", role: .destructive) { confirmDelete = true }
                }.disabled(saving || store.busy)
            }
            if let error { Text(error).foregroundStyle(.red) }
        }.modifier(NativeListAppearance()).navigationTitle(record.integer("id") > 0 ? "Modifica evento" : "Nuovo evento").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() }.disabled(saving) }
            ToolbarItem(placement: .confirmationAction) { Button("Salva") { Task { await save() } }.disabled(saving || store.busy || title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
        }
        .confirmationDialog("Eliminare la serie e tutti gli stati delle occorrenze?", isPresented: $confirmDelete, titleVisibility: .visible) { Button("Elimina serie", role: .destructive) { Task { await store.run("deleteEvent", args: [.int(record.integer("id"))]); if store.error == nil { dismiss() } } } }
        .onChange(of: fromHere) { _, value in date = CivilDate.date(value ? record.text("day") : record.text("series_day", fallback: record.text("day"))) }
        .onAppear {
            title = record.text("title"); location = record.text("location"); notes = record.text("notes")
            date = CivilDate.date(record.text("series_day", fallback: record.text("day", fallback: CivilDate.day())))
            frequency = record.text("frequency", fallback: "none"); hasTime = !record.text("start_time").isEmpty; hasEnd = !record.text("end_time").isEmpty
            start = clockDate(record.text("start_time", fallback: "09:00")); end = clockDate(record.text("end_time", fallback: "10:00"))
            hasUntil = !record.text("until_day").isEmpty; until = CivilDate.date(record.text("until_day", fallback: CivilDate.adding(365, to: CivilDate.day())))
        }
    }
    private func clockDate(_ text: String) -> Date {
        let parts = text.split(separator: ":").compactMap { Int($0) }
        return CivilDate.calendar.date(bySettingHour: parts.first ?? 9, minute: parts.last ?? 0, second: 0, of: Date()) ?? Date()
    }
    private func clock(_ date: Date) -> String {
        let parts = CivilDate.calendar.dateComponents([.hour, .minute], from: date)
        return String(format: "%02d:%02d", parts.hour ?? 0, parts.minute ?? 0)
    }
    private func save() async {
        saving = true; defer { saving = false }
        var payload: Record = ["id": .int(record.integer("id")), "title": .string(title), "day": .string(CivilDate.day(date)), "location": .string(location), "notes": .string(notes),
            "start_time": hasTime ? .string(clock(start)) : .null, "end_time": hasTime && hasEnd ? .string(clock(end)) : .null,
            "frequency": .string(frequency), "until_day": hasUntil && frequency != "none" ? .string(CivilDate.day(until)) : .null]
        if fromHere { payload["split_from"] = record["day"] }
        do { try await store.perform(fromHere ? "splitEventSeries" : "saveEvent", payload); dismiss() }
        catch { self.error = error.localizedDescription }
    }
}
