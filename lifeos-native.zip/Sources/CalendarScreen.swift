import SwiftUI

struct CalendarScreen: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    @State private var selected = ""
    @State private var brush = "consult"
    @State private var lastShift: (String, String)?
    @ScaledMetric(relativeTo: .body) private var numberHeight = 22
    @ScaledMetric(relativeTo: .caption) private var shiftHeight = 20
    @ScaledMetric(relativeTo: .caption2) private var indicatorHeight = 10
    var body: some View {
        let allEvents = store.events, allTasks = store.tasks
        List {
            Section {
                MonthControl(finance: false)
                Picker("Modalità", selection: $brush) {
                    Text("Consulta").tag("consult")
                    ForEach(ShiftKind.allCases) { shift in Text(shift.title).tag(shift.rawValue) }
                }.pickerStyle(.menu)
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 3), count: 7), spacing: 5) {
                    ForEach(["L", "M", "M", "G", "V", "S", "D"].indices, id: \.self) { i in Text(["L", "M", "M", "G", "V", "S", "D"][i]).font(.caption).foregroundStyle(Color.secondary) }
                    ForEach(CivilDate.grid(store.calendarMonth), id: \.self) { day in
                        Button {
                            selected = day
                            if brush != "consult" {
                                lastShift = (day, store.shift(day)?.rawValue ?? "erase")
                                Task { await store.run("paintShift", ["day": .string(day), "kind": .string(brush)]) }
                            }
                        } label: { cell(day, events: allEvents, tasks: allTasks) }.buttonStyle(.plain).disabled(store.busy)
                            .accessibilityLabel(CivilDate.label(day) + ", " + (store.shift(day)?.title ?? "nessun turno"))
                    }
                }
                .dynamicTypeSize(...DynamicTypeSize.xxxLarge)
                if let lastShift {
                    Button("Annulla ultimo turno") { Task { await store.run("paintShift", ["day": .string(lastShift.0), "kind": .string(lastShift.1)]); self.lastShift = nil } }.disabled(store.busy)
                }
            }
            if !selected.isEmpty {
                Section(CivilDate.label(selected)) {
                    if let shift = store.shift(selected) { Label(shift.title + (shift.time.isEmpty ? "" : " · " + shift.time), systemImage: "clock").foregroundStyle(shift.color) }
                    let events = allEvents.filter { $0.text("day") == selected }
                    let tasks = allTasks.filter { $0.text("scheduled_date") == selected }
                    if events.isEmpty && tasks.isEmpty { Text("Nessun evento o attività").foregroundStyle(Color.secondary) }
                    ForEach(events.map { DisplayRecord($0) }) { item in eventRow(item.value) }
                    ForEach(tasks.map { DisplayRecord($0) }) { item in
                        Button { router.sheet = .task(item.value) } label: { Label(item.value.text("title"), systemImage: item.value.text("status") == "done" ? "checkmark.circle.fill" : "checklist").foregroundStyle(Color.primary) }
                    }
                    Button("Aggiungi evento") { router.sheet = .event(["day": .string(selected)]) }
                }
            } else { Section { Text("Seleziona un giorno per vedere eventi, attività e turno.").foregroundStyle(Color.secondary) } }
        }.modifier(NativeListAppearance()).refreshable { await store.sync(scope: .life) }
        .onAppear { if selected.isEmpty { selected = CivilDate.day() } }
    }
    private func cell(_ day: String, events: [Record], tasks: [Record]) -> some View {
        let shift = store.shift(day), today = day == CivilDate.day(), active = selected == day
        let weekday = CivilDate.calendar.component(.weekday, from: CivilDate.date(day))
        let count = events.filter { $0.text("day") == day }.count + tasks.filter { $0.text("scheduled_date") == day }.count
        return VStack(spacing: 3) {
            Text(String(Int(day.suffix(2)) ?? 0)).font(.subheadline.weight(today ? .bold : .regular)).frame(height: min(numberHeight, 30))
            Text(shift?.letter ?? " ").font(.caption.weight(.semibold)).foregroundStyle(shift?.color ?? .secondary).frame(height: min(shiftHeight, 28))
            HStack(spacing: 0) { if count == 1 { Circle().fill(Color.indigo).frame(width: 5, height: 5) } else if count > 1 { Text(String(count)).font(.caption2.weight(.semibold)).foregroundStyle(.indigo) } }.frame(height: min(indicatorHeight, 12))
        }.frame(maxWidth: .infinity).padding(.vertical, 5)
            .background(active ? Color.indigo.opacity(0.15) : (weekday == 1 || weekday == 7 ? Color.secondary.opacity(0.1) : Color.clear), in: RoundedRectangle(cornerRadius: 14))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(today ? Color.indigo : Color.clear, lineWidth: 1.5))
            .opacity(day.hasPrefix(store.calendarMonth) ? 1 : 0.4)
            .accessibilityAddTraits(active ? .isSelected : [])
    }
    private func eventRow(_ r: Record) -> some View {
        HStack {
            Button { Task { await store.run("setEventOccurrence", ["id": .int(r.integer("id")), "day": .string(r.text("day")), "status": .string(r.text("occurrence_status") == "done" ? "open" : "done")]) } } label: { Image(systemName: r.text("occurrence_status") == "done" ? "checkmark.circle.fill" : "circle").font(.title2) }.buttonStyle(.borderless)
            Button { router.sheet = .event(r) } label: {
                VStack(alignment: .leading) { Text(r.text("title")).strikethrough(r.text("occurrence_status") == "done"); Text([r.text("start_time"), r.text("location")].filter { !$0.isEmpty }.joined(separator: " · ")).font(.caption).foregroundStyle(Color.secondary) }.foregroundStyle(Color.primary)
            }.buttonStyle(.borderless)
        }.disabled(store.busy)
    }
}
extension ShiftKind {
    var color: Color { switch self { case .morning: return .orange; case .afternoon: return .blue; case .night: return .purple; case .rest: return .green; case .holiday: return .pink; case .erase: return .secondary } }
}
struct EventEditor: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    let record: Record
    @State private var title = ""
    @State private var location = ""
    @State private var notes = ""
    @State private var date = Date()
    @State private var start = Date()
    @State private var end = Date()
    @State private var hasTime = false
    @State private var hasEnd = false
    @State private var frequency = "none"
    @State private var until = Date()
    @State private var hasUntil = false
    @State private var fromHere = false
    @State private var saving = false
    @State private var error: String?
    @State private var confirmDelete = false
    var body: some View {
        Form {
            Section { TextField("Titolo", text: $title); DatePicker("Giorno", selection: $date, displayedComponents: .date); TextField("Luogo", text: $location) }
            Section("Orario") {
                Toggle("Ora iniziale", isOn: $hasTime)
                if hasTime {
                    DatePicker("Inizio", selection: $start, displayedComponents: .hourAndMinute)
                    Toggle("Ora finale", isOn: $hasEnd)
                    if hasEnd { DatePicker("Fine", selection: $end, displayedComponents: .hourAndMinute) }
                }
            }
            Section("Ripetizione") {
                Picker("Frequenza", selection: $frequency) { Text("Mai").tag("none"); Text("Ogni settimana").tag("weekly"); Text("Ogni mese").tag("monthly"); Text("Ogni anno").tag("yearly") }
                if frequency != "none" { Toggle("Data finale", isOn: $hasUntil); if hasUntil { DatePicker("Fino al", selection: $until, in: date..., displayedComponents: .date) } }
                if record.integer("id") > 0 && record.text("frequency", fallback: "none") != "none" {
                    Toggle("Modifica da questa occorrenza", isOn: $fromHere)
                    Text("Le occorrenze precedenti restano nello storico.").font(.caption).foregroundStyle(Color.secondary)
                }
            }
            Section("Note") { TextEditor(text: $notes).frame(minHeight: 90) }
            if record.integer("id") > 0 {
                Section {
                    Button(record.text("occurrence_status") == "done" ? "Riapri questa occorrenza" : "Segna fatta questa occorrenza") {
                        Task { await store.run("setEventOccurrence", ["id": .int(record.integer("id")), "day": .string(record.text("day")), "status": .string(record.text("occurrence_status") == "done" ? "open" : "done")]); if store.error == nil { dismiss() } }
                    }
                    Button("Elimina solo questa occorrenza", role: .destructive) { Task { await store.run("setEventOccurrence", ["id": .int(record.integer("id")), "day": .string(record.text("day")), "status": .string("skipped")]); if store.error == nil { dismiss() } } }
                    Button("Elimina intera serie", role: .destructive) { confirmDelete = true }
                }.disabled(saving || store.busy)
            }
            if let error { Text(error).foregroundStyle(.red) }
        }.navigationTitle(record.integer("id") > 0 ? "Modifica evento" : "Nuovo evento").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() }.disabled(saving) }
            ToolbarItem(placement: .confirmationAction) { Button("Salva") { Task { await save() } }.disabled(saving || store.busy || title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
        }
        .confirmationDialog("Eliminare la serie e tutti gli stati delle occorrenze?", isPresented: $confirmDelete, titleVisibility: .visible) { Button("Elimina serie", role: .destructive) { Task { await store.run("deleteEvent", args: [.int(record.integer("id"))]); if store.error == nil { dismiss() } } } }
        .onChange(of: fromHere) { _, value in date = CivilDate.date(value ? record.text("day") : record.text("series_day", fallback: record.text("day"))) }
        .onAppear {
            title = record.text("title"); location = record.text("location"); notes = record.text("notes")
            date = CivilDate.date(record.text("series_day", fallback: record.text("day", fallback: CivilDate.day())))
            frequency = record.text("frequency", fallback: "none"); hasTime = !record.text("start_time").isEmpty; hasEnd = !record.text("end_time").isEmpty
            start = clockDate(record.text("start_time", fallback: "09:00")); end = clockDate(record.text("end_time", fallback: "10:00"))
            hasUntil = !record.text("until_day").isEmpty; until = CivilDate.date(record.text("until_day", fallback: CivilDate.adding(365, to: CivilDate.day())))
        }
    }
    private func clockDate(_ text: String) -> Date {
        let parts = text.split(separator: ":").compactMap { Int($0) }
        return CivilDate.calendar.date(bySettingHour: parts.first ?? 9, minute: parts.last ?? 0, second: 0, of: Date()) ?? Date()
    }
    private func clock(_ date: Date) -> String {
        let parts = CivilDate.calendar.dateComponents([.hour, .minute], from: date)
        return String(format: "%02d:%02d", parts.hour ?? 0, parts.minute ?? 0)
    }
    private func save() async {
        saving = true; defer { saving = false }
        var payload: Record = ["id": .int(record.integer("id")), "title": .string(title), "day": .string(CivilDate.day(date)), "location": .string(location), "notes": .string(notes),
            "start_time": hasTime ? .string(clock(start)) : .null, "end_time": hasTime && hasEnd ? .string(clock(end)) : .null,
            "frequency": .string(frequency), "until_day": hasUntil && frequency != "none" ? .string(CivilDate.day(until)) : .null]
        if fromHere { payload["split_from"] = record["day"] }
        do { try await store.perform(fromHere ? "splitEventSeries" : "saveEvent", payload); dismiss() }
        catch { self.error = error.localizedDescription }
    }
}
