import Foundation

struct NativeRoutineSchedule: Equatable {
    static let weekdays = ["Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"]
    let mode: String
    let intervalDays: Int
    let days: [Int]
    let startDate: String
    init(_ value: JSONValue?) throws {
        guard let value else { mode = "daily"; intervalDays = 1; days = []; startDate = ""; return }
        guard case .object(let r) = value, ["daily", "interval", "weekdays"].contains(r.text("mode")) else { throw Message(text: "Ripetizione non valida.") }
        if let start = r["startDate"], case .string = start {} else if r["startDate"] != nil { throw Message(text: "Scegli una data di inizio valida.") }
        mode = r.text("mode"); startDate = r.text("startDate")
        guard (startDate.isEmpty || Self.validDay(startDate)), mode == "daily" || Self.validDay(startDate) else { throw Message(text: "Scegli una data di inizio valida.") }
        let interval = r["intervalDays"] ?? .int(1)
        guard mode != "interval" || { if case .number(let n) = interval { return n >= 1 && n <= 365 && n.rounded() == n }; return false }() else { throw Message(text: "Scegli un intervallo da 1 a 365 giorni.") }
        intervalDays = mode == "interval" ? Int(interval.number) : 1
        let values = r["weekdays"]?.array ?? []
        guard mode != "weekdays" || (!values.isEmpty && values.allSatisfy { if case .number(let n) = $0 { return n >= 1 && n <= 7 && n.rounded() == n }; return false }) else { throw Message(text: "Scegli almeno un giorno della settimana.") }
        days = mode == "weekdays" ? Array(Set(values.map { Int($0.number) })).sorted() : []
    }
    var value: JSONValue { .object(["mode": .string(mode), "intervalDays": .int(intervalDays), "weekdays": .array(days.map(JSONValue.int)), "startDate": .string(startDate)]) }
    var summary: String { mode == "daily" ? "Ogni giorno" : mode == "interval" ? "Ogni \(intervalDays) \(intervalDays == 1 ? "giorno" : "giorni")" : days.map { Self.weekdays[$0 - 1] }.joined(separator: ", ") }
    func isDue(on day: String) -> Bool {
        guard Self.validDay(day), startDate.isEmpty || day >= startDate else { return false }
        if mode == "daily" { return true }
        if mode == "weekdays" { return days.contains((CivilDate.calendar.component(.weekday, from: CivilDate.date(day)) + 5) % 7 + 1) }
        let distance = CivilDate.calendar.dateComponents([.day], from: CivilDate.date(startDate), to: CivilDate.date(day)).day ?? -1
        return distance >= 0 && distance % intervalDays == 0
    }
    static func due(_ routine: Record, day: String = CivilDate.day()) -> Bool { (try? NativeRoutineSchedule(routine["schedule"]).isDue(on: day)) ?? false }
    static func validDay(_ day: String) -> Bool {
        guard day.range(of: #"^\d{4}-\d{2}-\d{2}$"#, options: .regularExpression) != nil else { return false }
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.timeZone = CivilDate.calendar.timeZone; f.dateFormat = "yyyy-MM-dd"; f.isLenient = false
        return f.date(from: day).map { f.string(from: $0) == day } ?? false
    }
}
