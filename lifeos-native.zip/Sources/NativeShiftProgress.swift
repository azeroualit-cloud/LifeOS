import SwiftUI

struct NativeShiftSpan {
    let kind: ShiftKind
    let start: Date
    let end: Date
    static func active(now: Date, today: ShiftKind?, previous: ShiftKind?) -> Self? {
        let calendar = CivilDate.calendar
        let day = CivilDate.day(now)
        func clock(_ day: String, _ hour: Int) -> Date {
            calendar.date(bySettingHour: hour, minute: 0, second: 0, of: CivilDate.date(day))!
        }
        let candidate: Self?
        if calendar.component(.hour, from: now) < 6, previous == .night {
            candidate = Self(kind: .night, start: clock(CivilDate.adding(-1, to: day), 22), end: clock(day, 6))
        } else {
            switch today {
            case .morning: candidate = Self(kind: .morning, start: clock(day, 6), end: clock(day, 14))
            case .afternoon: candidate = Self(kind: .afternoon, start: clock(day, 14), end: clock(day, 22))
            case .night: candidate = Self(kind: .night, start: clock(day, 22), end: clock(CivilDate.adding(1, to: day), 6))
            default: candidate = nil
            }
        }
        guard let candidate, now >= candidate.start, now < candidate.end else { return nil }
        return candidate
    }
    var duration: Double { end.timeIntervalSince(start) }
    var count: Int { Int(ceil(duration / 7200)) }
    func fraction(_ index: Int, now: Date) -> Double {
        let length = min(7200, duration - Double(index) * 7200)
        return min(1, max(0, (now.timeIntervalSince(start) - Double(index) * 7200) / length))
    }
    func celebration(now: Date, defaults: UserDefaults = .standard) -> Int? {
        let latest = min(count - 1, Int(now.timeIntervalSince(start) / 7200) - 1)
        guard latest >= 0 else { return nil }
        let prefix = CivilDate.day(start) + ":" + kind.rawValue + ":"
        var seen = defaults.stringArray(forKey: "native-shift-celebrations") ?? []
        let unseen = !seen.contains(prefix + String(latest))
        for i in 0...latest where !seen.contains(prefix + String(i)) { seen.append(prefix + String(i)) }
        defaults.set(Array(seen.suffix(64)), forKey: "native-shift-celebrations")
        return unseen ? latest : nil
    }
}

struct NativeShiftProgress: View {
    @EnvironmentObject private var store: NativeStore
    @EnvironmentObject private var router: NativeRouter
    @Environment(\.nativeReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var highlighted: Int?
    @State private var phase = 0
    let now: Date
    private enum Metrics {
        static let height: CGFloat = 8
        static let particle: CGFloat = 2
        static let lift: CGFloat = 9
        static let spread: CGFloat = 12
        static let scale: CGFloat = 1.08
    }
    private var span: NativeShiftSpan? {
        NativeShiftSpan.active(now: now, today: store.shift(CivilDate.day(now)), previous: store.shift(CivilDate.adding(-1, to: CivilDate.day(now))))
    }
    var body: some View {
        let active = span
        VStack(alignment: .leading, spacing: NativeDesign.Space.small) {
            if let active {
                Text("\(Int(ceil(active.end.timeIntervalSince(now) / 3600))) ore alla fine")
                    .font(.caption).foregroundStyle(NativeDesign.secondary)
            }
            GeometryReader { geometry in
                HStack(spacing: NativeDesign.Space.xs) {
                    ForEach(0..<(active?.count ?? 4), id: \.self) { index in
                        let length = active.map { min(7200, $0.duration - Double(index) * 7200) / $0.duration } ?? 0.25
                        let gaps = NativeDesign.Space.xs * CGFloat((active?.count ?? 4) - 1)
                        let width = max(0, (geometry.size.width - gaps) * length)
                        Capsule().fill(active?.kind.color.opacity(0.14) ?? Color.gray.opacity(0.08))
                            .overlay(alignment: .leading) {
                                Capsule().fill(active?.kind.color ?? .clear)
                                    .frame(width: width * (active?.fraction(index, now: now) ?? 0))
                            }
                            .frame(width: width)
                            .brightness(highlighted == index && phase == 1 ? 0.08 : 0)
                            .scaleEffect(highlighted == index && phase == 1 ? Metrics.scale : 1)
                            .overlay {
                                if highlighted == index, phase > 0 {
                                    ForEach(0..<4, id: \.self) { particle in
                                        Circle().fill(active?.kind.color.opacity(0.45) ?? .clear)
                                            .frame(width: Metrics.particle, height: Metrics.particle)
                                            .offset(x: phase == 2 ? CGFloat(particle - 2) * Metrics.spread : 0, y: phase == 2 ? -Metrics.lift : 0)
                                            .opacity(phase == 2 ? 0 : 0.6)
                                    }
                                }
                            }
                    }
                }
            }.frame(height: Metrics.height).accessibilityHidden(true)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(active.map { "\($0.kind.title), \(Int(now.timeIntervalSince($0.start) / 60)) minuti trascorsi su \(Int($0.duration / 60))" } ?? "Nessun turno in corso")
        .accessibilityIdentifier("home-shift-progress")
        .task(id: router.activationID) {
            highlighted = nil; phase = 0
            guard scenePhase == .active, Date().timeIntervalSince(router.activatedAt) < 3, let active, let index = active.celebration(now: now), !reduceMotion else { return }
            highlighted = index
            withAnimation(.easeOut(duration: 0.18)) { phase = 1 }
            do {
                try await Task.sleep(for: .milliseconds(180))
                withAnimation(.easeOut(duration: 0.32)) { phase = 2 }
                try await Task.sleep(for: .milliseconds(320))
            } catch { }
            highlighted = nil; phase = 0
        }
    }
}
