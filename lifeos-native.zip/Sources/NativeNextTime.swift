import Foundation

/// Neutral presentation of the existing local timetable; no network or personal data.
struct NativeNextTime {
    let day: String
    let label: String
    let time: String
    let tomorrow: Bool
    var displayTime: String { (tomorrow ? "Domani · " : "") + time }
    var symbol: String {
        switch label {
        case "Prima dell’alba": return "sun.horizon"
        case "Mezzogiorno": return "sun.max"
        case "Pomeriggio": return "sun.haze"
        case "Tramonto": return "sunset"
        default: return "moon"
        }
    }
    static func schedule(day: String) -> [(label: String, time: String)] {
        SolarTimes.calculate(day).enumerated().filter { $0.offset != 1 && $0.element.1 != "—" }
            .map { (label: $0.element.0, time: $0.element.1) }.sorted { $0.time < $1.time }
    }
    static func next(now: Date) -> NativeNextTime? {
        let day = CivilDate.day(now)
        let parts = CivilDate.calendar.dateComponents([.hour, .minute], from: now)
        let clock = String(format: "%02d:%02d", parts.hour ?? 0, parts.minute ?? 0)
        if let time = schedule(day: day).first(where: { $0.time > clock }) {
            return NativeNextTime(day: day, label: time.label, time: time.time, tomorrow: false)
        }
        let tomorrow = CivilDate.adding(1, to: day)
        guard let time = schedule(day: tomorrow).first else { return nil }
        return NativeNextTime(day: tomorrow, label: time.label, time: time.time, tomorrow: true)
    }
}

enum SolarTimes {
    static func calculate(_ day: String) -> [(String, String)] {
        let deg = Double.pi / 180, lat = 43.7179, lon = 10.9478
        var utc = Calendar(identifier: .gregorian); utc.timeZone = TimeZone(secondsFromGMT: 0)!
        let parts = CivilDate.calendar.dateComponents([.year, .month, .day], from: CivilDate.date(day))
        let midnight = utc.date(from: DateComponents(year: parts.year, month: parts.month, day: parts.day))!
        let jd = midnight.timeIntervalSince1970 / 86400 + 2440587.5 - lon / 360
        func norm(_ x: Double, _ n: Double) -> Double { (x.truncatingRemainder(dividingBy: n) + n).truncatingRemainder(dividingBy: n) }
        func sun(_ t: Double) -> (Double, Double) {
            let d = jd + t / 24 - 2451545, g = norm(357.529 + 0.98560028 * d, 360), q = norm(280.459 + 0.98564736 * d, 360)
            let l = norm(q + 1.915 * sin(g * deg) + 0.02 * sin(2 * g * deg), 360), e = (23.439 - 0.00000036 * d) * deg
            let ra = norm(atan2(cos(e) * sin(l * deg), cos(l * deg)) / deg / 15, 24)
            return (asin(sin(e) * sin(l * deg)) / deg, q / 15 - ra)
        }
        func noon(_ t: Double) -> Double { norm(12 - sun(t).1, 24) }
        func angle(_ a: Double, _ t: Double, _ before: Bool) -> Double {
            let dec = sun(t).0 * deg, ratio = (-sin(a * deg) - sin(dec) * sin(lat * deg)) / (cos(dec) * cos(lat * deg))
            if abs(ratio) > 1 || !ratio.isFinite { return .nan }
            let delta = acos(max(-1, min(1, ratio))) / deg / 15
            return noon(t) + (before ? -delta : delta)
        }
        var times: [Double] = [5, 6, 12, 13, 18, 18]
        for _ in 0..<2 {
            let t = times.map { $0 / 24 }
            let altitude = -atan(1 / (1 + tan(abs(lat - sun(t[3]).0) * deg))) / deg
            times = [angle(14.5, t[0], true), angle(0.833, t[1], true), noon(t[2]), angle(altitude, t[3], false), angle(0.833, t[4], false), angle(14.8, t[5], false)]
        }
        let offset = Double(CivilDate.calendar.timeZone.secondsFromGMT(for: midnight.addingTimeInterval(43200))) / 3600
        let labels = ["Prima dell’alba", "Alba", "Mezzogiorno", "Pomeriggio", "Tramonto", "Notte"], adjustments = [0, -2, 1, 1, 2, 0]
        return times.enumerated().map { i, value in
            guard value.isFinite else { return (labels[i], "—") }
            let minutes = Int(norm(((value + offset - lon / 15) * 60 + Double(adjustments[i])).rounded(), 1440))
            return (labels[i], String(format: "%02d:%02d", minutes / 60, minutes % 60))
        }
    }
}
