import SwiftUI
import Combine

@main struct LifeOSProbe: App {
    @StateObject private var store: NativeStore
    init() {
        var directory: URL?
        #if DEBUG
        let args = ProcessInfo.processInfo.arguments
        if args.contains("--visual-test") {
            directory = FileManager.default.temporaryDirectory.appendingPathComponent("visual-" + UUID().uuidString)
            UserDefaults.standard.set(args.contains("--dark") ? "dark" : "light", forKey: "native-theme")
            UserDefaults.standard.set(false, forKey: "native-hide-money")
        }
        #endif
        let value = NativeStore(directory: directory, migrateLegacy: directory == nil)
        #if DEBUG
        if args.contains("--stress-content") { value.seedVisualTasks() }
        if args.contains("--stress-money") { value.seedVisualMoney() }
        if args.contains("--six-weeks") { value.calendarMonth = "2026-03" }
        #endif
        _store = StateObject(wrappedValue: value)
    }
    @StateObject private var router = NativeRouter()
    var body: some Scene {
        WindowGroup {
            rootContent.environmentObject(store).environmentObject(router).tint(NativeDesign.accent)
                .environment(\.calendar, CivilDate.calendar)
                .environment(\.timeZone, CivilDate.calendar.timeZone)
                .modifier(NativeVisualTestSize())
        }
    }
    @ViewBuilder private var rootContent: some View {
        #if DEBUG
        if ProcessInfo.processInfo.arguments.contains("--signin-preview") { NavigationStack { NativeSignInScreen {} } }
        else { NativeRoot() }
        #else
        NativeRoot()
        #endif
    }
}
enum NativeTab: Hashable { case dashboard, tasks, calendar, finance }
enum NativeSheet: Identifiable {
    case settings, task(Record), event(Record), movement(Record), extra(Record), routines, categories, budget, recurring(Record), planning
    var id: String {
        switch self {
        case .settings: return "settings"; case .task: return "task"; case .event: return "event"
        case .movement: return "movement"; case .extra: return "extra"; case .routines: return "routines"
        case .categories: return "categories"; case .budget: return "budget"; case .recurring: return "recurring"; case .planning: return "planning"
        }
    }
}
@MainActor final class NativeRouter: ObservableObject {
    @Published var tab: NativeTab = .dashboard
    @Published var sheet: NativeSheet?
    @Published var taskCategory = "action"
    @Published var financeSection = "Panoramica"
    @Published var calendarDay = CivilDate.day()
}
struct NativeRoot: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("native-theme") private var theme = "system"
    @State private var currentDay = CivilDate.day()
    var body: some View {
        TabView(selection: $router.tab) {
            NavigationStack { DashboardScreen().toolbar { tools }.navigationTitle("Dashboard").navigationBarTitleDisplayMode(.inline) }
                .tabItem { Label { Text("Dashboard") } icon: { Image(systemName: "square.grid.2x2").environment(\.symbolVariants, .none) } }.tag(NativeTab.dashboard)
            NavigationStack { TasksScreen().toolbar { tools }.navigationTitle("Attività").navigationBarTitleDisplayMode(.inline) }
                .tabItem { Label { Text("Attività") } icon: { Image(systemName: "checklist").environment(\.symbolVariants, .none) } }.tag(NativeTab.tasks)
            NavigationStack { CalendarScreen().toolbar { tools }.navigationTitle("Calendario").navigationBarTitleDisplayMode(.inline) }
                .tabItem { Label { Text("Calendario") } icon: { Image(systemName: "calendar").environment(\.symbolVariants, .none) } }.tag(NativeTab.calendar)
            NavigationStack { FinanceScreen().toolbar { tools }.navigationTitle("Finanza").navigationBarTitleDisplayMode(.inline) }
                .tabItem { Label { Text("Finanza") } icon: { Image(systemName: "chart.bar").environment(\.symbolVariants, .none) } }.tag(NativeTab.finance)
        }
        .modifier(NativeTabAppearance())
        .symbolVariant(.none).symbolRenderingMode(.monochrome)
        .font(NativeDesign.body)
        .environment(\.defaultMinListRowHeight, 44)
        .preferredColorScheme(theme == "dark" ? .dark : theme == "light" ? .light : nil)
        .sheet(item: $router.sheet) { sheet in
            NavigationStack {
                switch sheet {
                case .settings: NativeSettings()
                case .task(let record): TaskEditor(record: record)
                case .event(let record): EventEditor(record: record)
                case .movement(let record): MovementEditor(record: record)
                case .extra(let record): ExtraEditor(record: record)
                case .routines: RoutinesEditor()
                case .categories: CategoriesEditor()
                case .budget: BudgetDetail()
                case .recurring(let record): RecurringEditor(record: record)
                case .planning: PlanningEditor()
                }
            }.presentationDragIndicator(.visible)
        }
        .alert("Operazione non riuscita", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
            Button("OK") { store.error = nil }
        } message: { Text(store.error ?? "") }
        .task { await store.sync(automatic: true); await store.loadWeather() }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { currentDay = CivilDate.day(); store.rollover(); Task { await store.sync(automatic: true); await store.loadWeather() } }
        }
        .onReceive(Timer.publish(every: 30, on: .main, in: .common).autoconnect()) { _ in
            let day = CivilDate.day()
            if day != currentDay {
                currentDay = day; store.rollover()
                Task { await store.sync(automatic: true); await store.loadWeather() }
            } else if scenePhase == .active { Task { await store.sync(automatic: true); await store.loadWeather() } }
        }
    }
    @ToolbarContentBuilder private var tools: some ToolbarContent {
        
        ToolbarItem(placement: .topBarLeading) {
            Button { router.sheet = .settings } label: { Image(systemName: "gearshape").font(NativeDesign.symbol) }
                .accessibilityLabel("Impostazioni")
                .contextMenu { Button("Sincronizza", systemImage: "arrow.triangle.2.circlepath") { Task { await store.sync() } }.disabled(store.busy) }
        }
        ToolbarItemGroup(placement: .topBarTrailing) {
            Button {
                switch router.tab {
                case .dashboard: router.sheet = .movement([:])
                case .finance: router.sheet = router.financeSection == "Extra" ? .extra([:]) : .movement([:])
                case .tasks: router.sheet = .task(["list_kind": .string(router.taskCategory)])
                case .calendar: router.sheet = .event(["day": .string(router.calendarDay)])
                }
            } label: { Image(systemName: "plus").font(NativeDesign.symbol) }.accessibilityLabel(addLabel)
        }
    }
    private var addLabel: String {
        switch router.tab {
        case .dashboard: return "Aggiungi spesa"
        case .finance: return router.financeSection == "Extra" ? "Aggiungi straordinaria" : "Aggiungi spesa"
        case .tasks: return "Aggiungi attività"
        case .calendar: return "Aggiungi evento"
        }
    }
}
struct MoneyText: View {
    let amount: Double
    var large = false
    var body: some View {
        Text(amount.euro).font(large ? .system(.largeTitle, weight: .bold) : .body)
            .monospacedDigit().minimumScaleFactor(0.6).lineLimit(1)
    }
}
struct MonthControl: View {
    @EnvironmentObject var store: NativeStore
    let finance: Bool
    var body: some View {
        HStack {
            Button { Task { await store.changeMonth(-1, finance: finance) } } label: { Image(systemName: "chevron.left").frame(minWidth: 44, minHeight: 44) }.accessibilityLabel("Mese precedente")
            Spacer(); Text(CivilDate.monthTitle(finance ? store.financeMonth : store.calendarMonth)).font(.headline)
            Spacer(); Button { Task { await store.changeMonth(1, finance: finance) } } label: { Image(systemName: "chevron.right").frame(minWidth: 44, minHeight: 44) }.accessibilityLabel("Mese successivo")
        }.buttonStyle(.plain).disabled(store.busy)
    }
}
struct DoneButton: ToolbarContent {
    @Environment(\.dismiss) private var dismiss
    var body: some ToolbarContent { ToolbarItem(placement: .confirmationAction) { Button("Fine") { dismiss() } } }
}

struct NativeVisualTestSize: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        #if DEBUG
        if ProcessInfo.processInfo.arguments.contains("--large-text") { content.dynamicTypeSize(.accessibility2) }
        else { content }
        #else
        content
        #endif
    }
}
