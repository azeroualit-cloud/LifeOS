import SwiftUI
import Combine

@main struct LifeOSProbe: App {
    @StateObject private var store: NativeStore
    init() {
        var directory: URL?
        #if DEBUG
        let args = ProcessInfo.processInfo.arguments
        if args.contains("--visual-test") {
            directory = FileManager.default.temporaryDirectory.appendingPathComponent("visual-" + UUID().uuidString)
            UserDefaults.standard.set(args.contains("--dark") ? "dark" : "light", forKey: "native-theme")
            UserDefaults.standard.set(false, forKey: "native-hide-money")
        }
        #endif
        let value = directory == nil ? NativeServices.store : NativeStore(directory: directory, migrateLegacy: false)
        #if DEBUG
        if args.contains("--stress-content") { value.seedVisualTasks() }
        if args.contains("--stress-money") { value.seedVisualMoney() }
        if args.contains("--six-weeks") { value.calendarMonth = "2026-03" }
        if args.contains("--empty-home") { value.seedVisualHome(empty: true) }
        if args.contains("--busy-home") { value.seedVisualHome(empty: false) }
        #endif
        NativeNotifications.shared.start()
        _store = StateObject(wrappedValue: value)
    }
    @StateObject private var router = NativeRouter()
    var body: some Scene {
        WindowGroup {
            rootContent.environmentObject(store).environmentObject(router).tint(NativeDesign.accent)
                .environment(\.calendar, CivilDate.calendar)
                .environment(\.timeZone, CivilDate.calendar.timeZone)
                .modifier(NativeVisualTestSize()).modifier(NativeVisualTestMotion())
        }
    }
    @ViewBuilder private var rootContent: some View {
        #if DEBUG
        if ProcessInfo.processInfo.arguments.contains("--signin-preview") { NavigationStack { NativeSignInScreen {} } }
        else { NativeRoot() }
        #else
        NativeRoot()
        #endif
    }
}
enum NativeTab: Hashable { case dashboard, tasks, finance }
enum NativeSheet: Identifiable {
    case weight, settings, task(Record), event(Record), movement(Record), extra(Record), routines, categories, budget, recurring(Record), planning
    var id: String {
        switch self {
        case .weight: return "weight"; case .settings: return "settings"; case .task: return "task"; case .event: return "event"
        case .movement: return "movement"; case .extra: return "extra"; case .routines: return "routines"
        case .categories: return "categories"; case .budget: return "budget"; case .recurring: return "recurring"; case .planning: return "planning"
        }
    }
}
@MainActor final class NativeRouter: ObservableObject {
    @Published var tab: NativeTab = .dashboard
    @Published var sheet: NativeSheet?
    @Published var taskCategory = "action"
    @Published var financeSection = "Panoramica"
    @Published var showCalendar = false
    @Published var calendarDay = CivilDate.day()
    // Session-only: switching tabs or refreshing data never replays the intro.
    var homeIntroConsumed = false
}
struct NativeRoot: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("native-theme") private var theme = "system"
    @AppStorage("native-reminders-enabled") private var remindersEnabled = false
    @State private var currentDay = CivilDate.day()
    var body: some View {
        nativeTabs
        .modifier(NativeTabBarAppearance())
        .symbolVariant(.none).symbolRenderingMode(.monochrome)
        .font(NativeDesign.body)
        .environment(\.defaultMinListRowHeight, NativeDesign.Layout.touchTarget)
        .preferredColorScheme(theme == "dark" ? .dark : theme == "light" ? .light : nil)
        .sheet(item: $router.sheet) { sheet in
            NavigationStack {
                switch sheet {
                case .weight: WeightEditor()
                case .settings: NativeSettings()
                case .task(let record): TaskEditor(record: record)
                case .event(let record): EventEditor(record: record)
                case .movement(let record): MovementEditor(record: record)
                case .extra(let record): ExtraEditor(record: record)
                case .routines: RoutinesEditor()
                case .categories: CategoriesEditor()
                case .budget: BudgetDetail()
                case .recurring(let record): RecurringEditor(record: record)
                case .planning: PlanningEditor()
                }
            }.presentationDragIndicator(.visible)
        }
        .alert("Operazione non riuscita", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
            Button("OK") { store.error = nil }
        } message: { Text(store.error ?? "") }
        .task {
            if let url = NativeIntentDraft.pendingURL { route(url) }
            if NativeIntentDraft.taskTitle != nil { route(URL(string: "lifeos://task")!) }
            await store.sync(automatic: true); await store.loadWeather()
        }
        .onChange(of: store.life, initial: true) { _, _ in updateReminders() }
        .onChange(of: remindersEnabled) { _, _ in updateReminders() }
        .onChange(of: store.isDemo) { _, _ in updateReminders() }
        .onOpenURL { url in route(url) }
        .onReceive(NotificationCenter.default.publisher(for: .lifeOSRoute)) { note in
            if let url = note.object as? URL { route(url) }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { currentDay = CivilDate.day(); store.rollover(); Task { await store.sync(automatic: true); await store.loadWeather() } }
        }
        .onReceive(Timer.publish(every: 30, on: .main, in: .common).autoconnect()) { _ in
            let day = CivilDate.day()
            if day != currentDay {
                currentDay = day; store.rollover()
                Task { await store.sync(automatic: true); await store.loadWeather() }
            } else if scenePhase == .active { Task { await store.sync(automatic: true); await store.loadWeather() } }
        }
    }
    private func updateReminders() { NativeNotifications.shared.update(life: store.life, enabled: remindersEnabled && !store.isDemo) }
    private func route(_ url: URL) {
        guard let route = LifeOSRoute(url) else { return }
        NativeIntentDraft.pendingURL = nil
        switch route {
        case .activities: router.tab = .tasks
        case .task:
            var draft: Record = ["list_kind": .string(router.taskCategory)]
            if let title = NativeIntentDraft.taskTitle { draft["title"] = .string(title); NativeIntentDraft.taskTitle = nil }
            router.tab = .tasks; router.sheet = .task(draft)
        case .weight: router.tab = .dashboard; router.sheet = .weight
        case .calendar: router.tab = .dashboard; router.calendarDay = CivilDate.day(); router.showCalendar = true
        case .dashboard: router.tab = .dashboard
        }
    }
    // Native destinations only: no custom capsule, animation or action disguised as a tab.
    private var nativeTabs: some View {
        TabView(selection: $router.tab) {
            dashboard.tabItem { Label("Dashboard", systemImage: "square.grid.2x2") }.tag(NativeTab.dashboard)
            tasks.tabItem { Label("Attività", systemImage: "checklist") }.tag(NativeTab.tasks)
            finance.tabItem { Label("Finanza", systemImage: "chart.bar") }.tag(NativeTab.finance)
        }
    }
    private var dashboard: some View { NavigationStack { DashboardScreen().toolbar { tools }.navigationTitle("Dashboard").navigationBarTitleDisplayMode(.inline) } }
    private var tasks: some View { NavigationStack { TasksScreen().toolbar { tools }.navigationTitle("Attività").navigationBarTitleDisplayMode(.inline) } }
    private var finance: some View { NavigationStack { FinanceScreen().toolbar { tools }.navigationTitle("Finanza").navigationBarTitleDisplayMode(.inline) } }
    @ToolbarContentBuilder private var tools: some ToolbarContent {
        if #available(iOS 26.0, *) {
            ToolbarItem(placement: .topBarTrailing) { if router.tab != .dashboard { addControl } }
                .sharedBackgroundVisibility(.hidden)
            ToolbarItem(placement: .topBarLeading) { settingsControl }
                .sharedBackgroundVisibility(.hidden)
        } else {
            ToolbarItem(placement: .topBarTrailing) { if router.tab != .dashboard { addControl } }
            ToolbarItem(placement: .topBarLeading) { settingsControl }
        }
    }
    private var addControl: some View {
        NativeToolbarButton(symbol: "plus", label: addLabel, action: addItem)
            .accessibilityIdentifier("primary-add")
    }
    private var settingsControl: some View {
        NativeToolbarButton(symbol: "gearshape", label: "Impostazioni") { router.sheet = .settings }
            .contextMenu { Button("Sincronizza", systemImage: "arrow.triangle.2.circlepath") { Task { await store.sync() } }.disabled(store.busy) }
    }
    private func addItem() {
        switch router.tab {
        case .tasks: router.sheet = .task(["list_kind": .string(router.taskCategory)])
        case .dashboard: router.sheet = .weight
        case .finance: router.sheet = router.financeSection == "Extra" ? .extra([:]) : .movement([:])
        }
    }
    private var addLabel: String {
        switch router.tab {
        case .tasks: return "Aggiungi attività"
        case .dashboard: return "Aggiungi peso"
        case .finance: return router.financeSection == "Extra" ? "Aggiungi straordinaria" : "Aggiungi spesa"
        }
    }
}
struct MoneyText: View {
    let amount: Double
    var large = false
    var body: some View {
        Text(amount.euro).font(large ? .system(.largeTitle, weight: .bold) : .body)
            .modifier(NativeNumericFeedback(value: amount))
            .monospacedDigit().minimumScaleFactor(0.6).lineLimit(1)
    }
}
struct MonthControl: View {
    @EnvironmentObject var store: NativeStore
    let finance: Bool
    var body: some View {
        HStack {
            Button { Task { await store.changeMonth(-1, finance: finance) } } label: { Image(systemName: "chevron.left").frame(minWidth: NativeDesign.Layout.touchTarget, minHeight: NativeDesign.Layout.touchTarget) }.accessibilityLabel("Mese precedente")
            Spacer(); Text(CivilDate.monthTitle(finance ? store.financeMonth : store.calendarMonth)).font(.headline)
            Spacer(); Button { Task { await store.changeMonth(1, finance: finance) } } label: { Image(systemName: "chevron.right").frame(minWidth: NativeDesign.Layout.touchTarget, minHeight: NativeDesign.Layout.touchTarget) }.accessibilityLabel("Mese successivo")
        }.buttonStyle(NativePressStyle()).disabled(store.busy || store.syncing)
    }
}
struct DoneButton: ToolbarContent {
    @Environment(\.dismiss) private var dismiss
    var body: some ToolbarContent { ToolbarItem(placement: .confirmationAction) { Button("Fine") { dismiss() } } }
}

struct NativeVisualTestSize: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        #if DEBUG
        if ProcessInfo.processInfo.arguments.contains("--large-text") { content.dynamicTypeSize(.accessibility2) }
        else { content }
        #else
        content
        #endif
    }
}

/// A local test override; normal launches retain the user's system preference.
struct NativeVisualTestMotion: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        #if DEBUG
        if ProcessInfo.processInfo.arguments.contains("--reduce-motion") {
            content.environment(\.nativeForceReduceMotion, true)
        } else { content }
        #else
        content
        #endif
    }
}
