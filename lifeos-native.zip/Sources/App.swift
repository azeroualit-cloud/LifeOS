import SwiftUI
import UniformTypeIdentifiers

@main struct LifeOSProbe: App {
    @StateObject private var store = Store()
    var body: some Scene { WindowGroup { Root().environmentObject(store).tint(Color(uiColor: UIColor { $0.userInterfaceStyle == .dark ? UIColor(red: 165/255, green: 174/255, blue: 237/255, alpha: 1) : UIColor(red: 86/255, green: 95/255, blue: 156/255, alpha: 1) })) } }
}
struct Root: View {
    @EnvironmentObject var store: Store
    @State private var add = false
    @State private var settings = false
    var body: some View {
        TabView {
            NavigationStack { Overview().navigationTitle("Panoramica").toolbar { tools } }
                .tabItem { Label("Panoramica", systemImage: "square.grid.2x2") }
            NavigationStack { Movements().navigationTitle("Movimenti").toolbar { tools } }
                .tabItem { Label("Movimenti", systemImage: "list.bullet") }
        }
        .safeAreaInset(edge: .bottom, alignment: .trailing) {
            Button { add = true } label: { Image(systemName: "plus").font(.title2).frame(width: 56, height: 56) }
                .buttonStyle(.borderedProminent).buttonBorderShape(.circle).padding(.trailing, 20).padding(.bottom, 12)
                .accessibilityLabel("Aggiungi spesa")
        }
        .sheet(isPresented: $add) { ExpenseForm() }
        .sheet(isPresented: $settings) { Settings() }
        .alert("Operazione non riuscita", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
            Button("OK") { store.error = nil }
        } message: { Text(store.error ?? "") }
    }
    @ToolbarContentBuilder var tools: some ToolbarContent {
        ToolbarItem(placement: .topBarTrailing) {
            Button { Task { await store.sync() } } label: {
                if store.busy { ProgressView() } else { Image(systemName: "arrow.triangle.2.circlepath") }
            }.disabled(store.busy || store.server == nil).accessibilityLabel("Sincronizza")
        }
        ToolbarItem(placement: .topBarLeading) { Button { settings = true } label: { Image(systemName: "gearshape") }.accessibilityLabel("Impostazioni") }
    }
}
struct Overview: View {
    @EnvironmentObject var store: Store
    var body: some View {
        List {
            Section {
                Text("PROTOTIPO - COPIA DI TEST").font(.caption).foregroundStyle(.secondary)
                if let s = store.archive.finance?.summary {
                    Text(s.remainingFree.euro).font(.system(size: 38, weight: .semibold)).monospacedDigit().minimumScaleFactor(0.6)
                    Text("\(s.budget.euro) - \(s.committedCurrent.euro) = \(s.remainingFree.euro)")
                        .font(.subheadline).foregroundStyle(.secondary).monospacedDigit()
                    LabeledContent("Conto", value: s.account ?? "Trade Republic")
                    if let date = store.archive.refreshedAt { Text("Aggiornato \(date.formatted(date: .abbreviated, time: .shortened))").font(.caption).foregroundStyle(.secondary) }
                } else {
                    Text("Nessun saldo caricato").font(.title2)
                    Text("Importa uno snapshot o collega la copia di test nelle impostazioni.").foregroundStyle(.secondary)
                }
            }
            if !store.archive.queue.isEmpty || !store.archive.confirmed.isEmpty {
                Section("Spese locali") {
                    LabeledContent("Da sincronizzare", value: "\(store.archive.queue.count)")
                    LabeledContent("Totale in coda", value: store.archive.queue.reduce(0) { $0 + $1.amount }.euro)
                    if !store.archive.confirmed.isEmpty { Text("\(store.archive.confirmed.count) inviate. Aggiornamento saldo da completare.") }
                    Text("Il saldo sopra è quello dell'ultimo snapshot. Gli impegni vengono ricalcolati dal server dopo la sincronizzazione.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
        }.refreshable { await store.sync() }
    }
}
struct Movements: View {
    @EnvironmentObject var store: Store
    var body: some View {
        List {
            if !store.archive.queue.isEmpty {
                Section("Da sincronizzare") { ForEach(store.archive.queue.reversed()) { expense in
                    row(expense.name, expense.category, expense.date, -expense.amount)
                } }
            }
            if !store.archive.confirmed.isEmpty {
                Section("Inviate - saldo da aggiornare") { ForEach(store.archive.confirmed) { expense in
                    Text(expense.name).foregroundStyle(.secondary)
                } }
            }
            Section("Movimenti del mese") {
                if let movements = store.archive.finance?.transactions, !movements.isEmpty {
                    ForEach(movements) { m in row(m.name, m.category, m.date, m.amount) }
                } else { Text("Nessun movimento caricato").foregroundStyle(.secondary) }
            }
        }.refreshable { await store.sync() }
    }
    func row(_ name: String, _ category: String, _ date: String, _ amount: Double) -> some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 4) { Text(name); Text("\(category) · \(date)").font(.caption).foregroundStyle(.secondary) }
            Spacer(); Text(amount.euro).monospacedDigit().fixedSize(horizontal: true, vertical: false)
        }.padding(.vertical, 4)
    }
}
struct ExpenseForm: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) private var dismiss
    @State private var amount = ""
    @State private var name = ""
    @State private var category = "Altro"
    @State private var date = Date()
    @State private var months = 1
    @State private var treatment = "auto"
    @State private var error: String?
    @FocusState private var amountFocused: Bool
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Importo €", text: $amount).keyboardType(.decimalPad).focused($amountFocused)
                    TextField("Descrizione", text: $name)
                    Picker("Categoria", selection: $category) { ForEach(Input.categories, id: \.self) { Text($0) } }
                    DatePicker("Data", selection: $date, in: ...Date(), displayedComponents: .date)
                    LabeledContent("Conto", value: "Trade Republic")
                }
                Section("Budget") {
                    Stepper("Mesi coperti: \(months)", value: $months, in: 1...12)
                    Picker("Trattamento", selection: $treatment) {
                        Text("Automatico dalla categoria").tag("auto")
                        Text("Spesa ordinaria").tag("ordinary")
                        Text("Già pianificata").tag("planned")
                        Text("Da risparmi").tag("savings")
                    }
                }
                if let error { Text(error).foregroundStyle(.red) }
                Text("Salvataggio locale immediato. Sincronizza per aggiornare il saldo della copia di test.").font(.caption).foregroundStyle(.secondary)
            }
            .navigationTitle("Nuova spesa").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Salva") {
                        do {
                            let expense = try Input.expense(amount: amount, name: name, category: category, date: date, months: months, treatment: treatment)
                            try store.add(expense); dismiss()
                        } catch { self.error = error.localizedDescription }
                    }.disabled(Input.cents(amount) == nil || name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }.onAppear { amountFocused = true }
        }
    }
}
struct Settings: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) private var dismiss
    @State private var endpoint = ""
    @State private var login = false
    @State private var importing = false
    @State private var error: String?
    var body: some View {
        NavigationStack {
            Form {
                Section("Copia di test") {
                    TextField("https://lifeos-test.example.com", text: $endpoint).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                    Button("Collega") { do { try store.configure(endpoint) } catch { self.error = error.localizedDescription } }
                        .disabled(store.busy)
                    if store.server != nil { Button("Accedi") { login = true } }
                    Text("Usa un Worker separato collegato a una copia di D1. Le spese inviate modificano il database del server indicato.").font(.caption).foregroundStyle(.secondary)
                }
                if store.server == nil {
                    Section("Prova offline") {
                        Button("Importa snapshot JSON") { importing = true }
                        Text("Formato: risposta originale di getFinanceOverview. Puoi usare sample-snapshot.json per una prova con dati simulati.").font(.caption).foregroundStyle(.secondary)
                    }
                }
                if let error { Text(error).foregroundStyle(.red) }
                Section { Text("Sessione temporanea: dopo la chiusura può essere necessario accedere di nuovo. Il login Google in questa schermata va verificato sul dispositivo.").font(.caption).foregroundStyle(.secondary) }
            }
            .navigationTitle("Impostazioni").toolbar { ToolbarItem(placement: .confirmationAction) { Button("Fine") { dismiss() } } }
            .onAppear { endpoint = store.server?.absoluteString ?? "" }
            .sheet(isPresented: $login) {
                if let server = store.server {
                    NavigationStack {
                        Login(url: server, onCookies: store.acceptCookies)
                            .navigationTitle("Accesso copia di test")
                            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Fine") { login = false } } }
                    }
                }
            }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
                do {
                    let url = try result.get(); let access = url.startAccessingSecurityScopedResource()
                    defer { if access { url.stopAccessingSecurityScopedResource() } }
                    try store.importSnapshot(Data(contentsOf: url))
                } catch { self.error = error.localizedDescription }
            }
        }
    }
}
