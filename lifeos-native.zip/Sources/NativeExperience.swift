import SwiftUI

struct NativeShiftBadge: View {
    let shift: ShiftKind?
    var body: some View {
        Text(shift?.letter ?? " ").font(.caption2.weight(.bold))
            .foregroundStyle(shift == .night ? Color.black : Color.black.opacity(0.85))
            .frame(maxWidth: .infinity).frame(height: 20)
            .background(shift?.color ?? Color.clear, in: RoundedRectangle(cornerRadius: 4))
            .padding(.horizontal, 3).accessibilityLabel(shift?.title ?? "Nessun turno")
    }
}
struct NativeDueBadge: View {
    let day: String
    private var title: String {
        if day == CivilDate.day() { return "Oggi" }
        if day == CivilDate.adding(1, to: CivilDate.day()) { return "Domani" }
        if day < CivilDate.day() { return "Scaduta · " + CivilDate.label(day) }
        return CivilDate.label(day)
    }
    private var urgent: Bool { day <= CivilDate.adding(1, to: CivilDate.day()) }
    var body: some View {
        Label(title, systemImage: urgent ? "exclamationmark.circle.fill" : "calendar")
            .font(.caption2.weight(urgent ? .semibold : .regular))
            .foregroundStyle(urgent ? Color.orange : Color.secondary)
            .padding(.horizontal, 7).padding(.vertical, 3)
            .background(urgent ? Color.orange.opacity(0.12) : Color.clear, in: Capsule())
    }
}
struct NativeSavingsRing: View {
    let progress: NativeSavingsProgress
    var hidden = false
    @State private var expanded = false
    var body: some View {
        Button { expanded = true } label: {
            ZStack {
                Circle().stroke(Color.secondary.opacity(0.13), lineWidth: 8)
                Circle().trim(from: 0, to: min(1, progress.reserved / progress.target)).stroke(Color.teal, style: StrokeStyle(lineWidth: 8, lineCap: .butt)).rotationEffect(.degrees(-90))
                Circle().trim(from: min(1, progress.reserved / progress.target), to: max(0, min(1, progress.assets / progress.target))).stroke(NativeDesign.accent, style: StrokeStyle(lineWidth: 8, lineCap: .butt)).rotationEffect(.degrees(-90))
                Text(hidden ? "•••• €" : progress.assets.euro).font(.subheadline.weight(.semibold)).monospacedDigit().minimumScaleFactor(0.5).lineLimit(1).padding(12)
            }.frame(width: 116, height: 116)
        }.buttonStyle(.plain).accessibilityLabel("Patrimonio e obiettivo di risparmio").accessibilityIdentifier("savings-ring").accessibilityValue(hidden ? "Importo nascosto" : progress.assets.euro)
        .sheet(isPresented: $expanded) {
            NavigationStack {
                List {
                    LabeledContent("Patrimonio totale", value: hidden ? "••••" : progress.assets.euro)
                    LabeledContent("Fondo emergenza coperto", value: hidden ? "••••" : progress.reserved.euro).foregroundStyle(.teal)
                    LabeledContent("Altri risparmi", value: hidden ? "••••" : progress.other.euro).foregroundStyle(NativeDesign.accent)
                    LabeledContent("Prossimo traguardo", value: hidden ? "••••" : progress.target.euro)
                    LabeledContent("Da risparmiare", value: hidden ? "••••" : progress.missing.euro)
                    LabeledContent("Al mese fino a dicembre", value: hidden ? "••••" : progress.monthly.euro)
                    Text("Il fondo emergenza è una parte del patrimonio. Il traguardo successivo avanza automaticamente a scatti di 5.000 €. Il risparmio mensile divide la cifra mancante per i mesi fino a dicembre, incluso quello corrente.").font(.caption).foregroundStyle(Color.secondary)
                }.navigationTitle("Risparmi").navigationBarTitleDisplayMode(.inline).toolbar { DoneButton() }
            }.presentationDetents([.medium, .large])
        }
    }
}
struct NativeTodayPanel: View {
    @EnvironmentObject var store: NativeStore
    var body: some View {
        TimelineView(.periodic(from: .now, by: 60)) { context in
            NativeCard {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text(CivilDate.label(CivilDate.day(context.date))).font(.headline)
                        Text("Empoli").font(.caption).foregroundStyle(Color.secondary)
                        if let next = nextTime(context.date) { Text(next).font(.title3.weight(.medium)).monospacedDigit().accessibilityLabel(next) }
                    }
                    Spacer()
                    if let weather = store.weatherDetails {
                        VStack(spacing: 5) {
                            Gauge(value: min(weather.high, max(weather.low, weather.temperature)), in: weather.low...max(weather.low + 0.1, weather.high)) {
                                Image(systemName: "thermometer.medium")
                            } currentValueLabel: { Text("\(Int(weather.temperature.rounded()))°").font(.title3.weight(.semibold)) }
                            .gaugeStyle(.accessoryCircular).tint(Gradient(colors: [.cyan, NativeDesign.accent, .orange]))
                            HStack(spacing: 12) {
                                Text("min \(Int(weather.low.rounded()))°")
                                Text("max \(Int(weather.high.rounded()))°")
                            }.font(.system(size: 10)).monospacedDigit().fixedSize()
                        }.frame(width: 110, height: 88).dynamicTypeSize(...DynamicTypeSize.xxxLarge)
                        .accessibilityElement(children: .ignore).accessibilityLabel("Temperatura attuale \(Int(weather.temperature.rounded())) gradi, minima \(Int(weather.low.rounded())) e massima \(Int(weather.high.rounded()))")
                    } else { Image(systemName: "cloud.sun").font(.largeTitle).foregroundStyle(Color.secondary).frame(width: 88, height: 88) }
                }
                Text(store.weather == "Meteo non disponibile" ? "Meteo non disponibile" : store.weatherDetails?.change ?? "Carico il meteo…").font(.subheadline).foregroundStyle(Color.secondary)
                if let date = store.weatherDate, context.date.timeIntervalSince(date) > 1800 { Text("Meteo aggiornato alle " + date.formatted(date: .omitted, time: .shortened)).font(.caption2).foregroundStyle(Color.secondary) }
                if let active = activeShift(context.date) {
                    Divider()
                    HStack(spacing: 12) {
                        ZStack {
                            Circle().stroke(active.0.color.opacity(0.16), lineWidth: 5)
                            Circle().trim(from: 0, to: active.1).stroke(active.0.color, style: StrokeStyle(lineWidth: 5, lineCap: .round)).rotationEffect(.degrees(-90))
                            Image(systemName: active.0.symbol).foregroundStyle(active.0.color)
                        }.frame(width: 42, height: 42)
                        VStack(alignment: .leading, spacing: 3) { Text(active.0.title + " in corso").font(.subheadline); Text("\(Int(active.1 * 100))% · " + active.0.time).font(.caption).foregroundStyle(Color.secondary) }
                    }
                }
            }
        }.task { await store.loadWeather() }
    }
    private func nextTime(_ now: Date) -> String? {
        let parts = CivilDate.calendar.dateComponents([.hour, .minute], from: now)
        let clock = String(format: "%02d:%02d", parts.hour ?? 0, parts.minute ?? 0)
        // Sunrise is an astronomical marker, not one of the five daily times.
        let today = SolarTimes.calculate(CivilDate.day(now)).enumerated().filter { $0.offset != 1 }.map { $0.element.1 }
        return today.first { $0 != "—" && $0 > clock } ?? SolarTimes.calculate(CivilDate.adding(1, to: CivilDate.day(now))).first?.1
    }
    private func activeShift(_ now: Date) -> (ShiftKind, Double)? {
        let day = CivilDate.day(now), minutes = CivilDate.calendar.component(.hour, from: now) * 60 + CivilDate.calendar.component(.minute, from: now)
        if minutes < 360, store.shift(CivilDate.adding(-1, to: day)) == .night { return (.night, Double(minutes + 120) / 480) }
        guard let shift = store.shift(day) else { return nil }
        let start: Int
        switch shift { case .morning: start = 360; case .afternoon: start = 840; case .night: start = 1320; default: return nil }
        guard minutes >= start, minutes < start + 480 else { return nil }
        return (shift, Double(minutes - start) / 480)
    }
}

enum NativeCategoryIcon {
    static func name(_ category: String) -> String {
        let key = category.lowercased()
        if key.contains("aliment") || key.contains("spesa") || key.contains("supermerc") { return "cart" }
        if key.contains("benz") || key.contains("carbur") { return "fuelpump" }
        if key.contains("auto") || key.contains("bollo") || key.contains("trasport") { return "car" }
        if key.contains("affitto") || key.contains("casa") || key.contains("condomin") { return "house" }
        if key.contains("elettr") || key.contains("utenze") { return "bolt" }
        if key.contains("gas") { return "flame" }; if key.contains("acqua") { return "drop" }
        if key.contains("salute") || key.contains("farmac") { return "cross.case" }
        if key.contains("palestr") || key.contains("sport") { return "dumbbell" }
        if key.contains("ristor") || key.contains("pasti") { return "fork.knife" }
        if key.contains("bar") || key.contains("caff") { return "cup.and.saucer" }
        if key.contains("stipend") || key.contains("entrata") { return "banknote" }
        if key.contains("abbon") { return "repeat" }; if key.contains("shopping") { return "bag" }
        if key.contains("svago") || key.contains("intratten") { return "ticket" }
        if key.contains("viagg") { return "airplane" }; return "tag"
    }
}

struct NativeCategoryChart: View {
    let rows: [Record]
    private let colors: [Color] = [NativeDesign.accent, .teal, .orange, .pink, .blue, .gray]
    private var compact: [Record] {
        if rows.count <= 6 { return rows }
        return Array(rows.prefix(5)) + [["name": .string("Altre categorie"), "amount": .number(rows.dropFirst(5).reduce(0) { $0 + $1.amount("amount") })]]
    }
    var body: some View {
        let total = rows.reduce(0) { $0 + $1.amount("amount") }
        HStack(spacing: 18) {
            ZStack {
                ForEach(Array(compact.enumerated()), id: \.offset) { index, row in
                    let start = compact.prefix(index).reduce(0) { $0 + $1.amount("amount") } / max(Double.leastNonzeroMagnitude, total)
                    Circle().trim(from: start, to: min(1, start + row.amount("amount") / max(Double.leastNonzeroMagnitude, total)))
                        .stroke(colors[index], style: StrokeStyle(lineWidth: 18, lineCap: .butt)).rotationEffect(.degrees(-90))
                }
                Text(total.euro).font(.caption.weight(.semibold)).minimumScaleFactor(0.5).lineLimit(1).padding(10)
            }.frame(width: 108, height: 108).padding(9).accessibilityLabel("Spese totali " + total.euro)
            VStack(alignment: .leading, spacing: 8) {
                ForEach(Array(compact.enumerated()), id: \.offset) { index, row in
                    HStack(alignment: .firstTextBaseline, spacing: 5) {
                        Circle().fill(colors[index]).frame(width: 6, height: 6)
                        Text(row.text("name")).lineLimit(2)
                        Spacer(minLength: 2)
                        Text("\(Int((row.amount("amount") / max(Double.leastNonzeroMagnitude, total) * 100).rounded()))%").monospacedDigit()
                    }.font(.caption2)
                }
            }.frame(maxWidth: .infinity)
        }.padding(.vertical, 8)
        DisclosureGroup("Tutte le categorie") {
            ForEach(Array(rows.enumerated()), id: \.offset) { _, row in
                LabeledContent(row.text("name"), value: row.amount("amount").euro).font(.subheadline)
            }
        }.font(.subheadline)
    }
}
