import Foundation

/// Presentation-only aggregation of server category totals, one snapshot per month.
enum NativeCategoryPeriod {
    static func months(ending month: String, count: Int) -> [String] {
        guard [3, 6, 12].contains(count), month.range(of: #"^20\d\d-(0[1-9]|1[0-2])$"#, options: .regularExpression) != nil else { return [] }
        return (0..<count).reversed().map { String(CivilDate.adding(-$0, to: month + "-01", component: .month).prefix(7)) }
    }
    static func aggregate(_ snapshots: [String: [Record]], months: [String]) throws -> [Record] {
        guard !months.isEmpty, Set(months).count == months.count, months.allSatisfy({ snapshots[$0] != nil }) else {
            throw Message(text: "Dati incompleti per il periodo selezionato.")
        }
        var totals: [String: Int64] = [:]
        for month in months {
            for row in snapshots[month] ?? [] {
                let name = row.text("name").trimmingCharacters(in: .whitespacesAndNewlines)
                guard !name.isEmpty, case .number(let amount)? = row["amount"], amount.isFinite else {
                    throw Message(text: "Dati categoria non validi.")
                }
                let cents = (amount * 100).rounded()
                guard cents.isFinite, cents > Double(Int64.min), cents < Double(Int64.max) else { throw Message(text: "Importo categoria non valido.") }
                let (sum, overflow) = (totals[name] ?? 0).addingReportingOverflow(Int64(cents))
                guard !overflow else { throw Message(text: "Totale categoria non valido.") }
                totals[name] = sum
            }
        }
        return totals.filter { $0.value > 0 }.sorted { $0.value == $1.value ? $0.key < $1.key : $0.value > $1.value }
            .map { ["name": .string($0.key), "amount": .number(Double($0.value) / 100)] }
    }
}

/// Category loading validates only the data it consumes, not unrelated movements
/// and multi-year histories from the legacy full-finance endpoint.
struct NativeCategoryPeriodCache {
    private(set) var scope = ""
    private(set) var snapshots: [String: [Record]] = [:]
    mutating func prepare(scope: String) {
        if self.scope != scope { snapshots = [:]; self.scope = scope }
    }
    mutating func clear() { snapshots = [:] }
    mutating func store(_ rows: [Record], month: String) throws {
        // Validate signed totals without dropping refunds before period aggregation.
        _ = try NativeCategoryPeriod.aggregate([month: rows], months: [month])
        snapshots[month] = rows
    }
    mutating func store(response: JSONValue, month: String) throws {
        guard case .array(let values)? = response.object["categories"] else {
            throw Message(text: "Categorie mancanti per un mese del periodo.")
        }
        try store(values.map(\.object), month: month)
    }
    func missing(in months: [String]) -> [String] { months.filter { snapshots[$0] == nil } }
    func aggregate(months: [String]) throws -> [Record] { try NativeCategoryPeriod.aggregate(snapshots, months: months) }
}

/// Keep month keys as categorical identities but give charts short, unambiguous labels.
enum NativeFinanceMonthAxis {
    static func ticks(_ months: [String]) -> [String] {
        let unique = Array(Set(months)).sorted()
        guard unique.count > 6 else { return unique }
        let step = Int(ceil(Double(unique.count) / 6))
        return unique.enumerated().compactMap { index, month in
            index % step == 0 || index == unique.count - 1 || month.hasSuffix("-01") ? month : nil
        }
    }
    static func label(_ month: String) -> String {
        guard month.range(of: #"^20\d\d-(0[1-9]|1[0-2])$"#, options: .regularExpression) != nil,
              let number = Int(month.suffix(2)) else { return "—" }
        let names = ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"]
        return names[number - 1] + "\n" + String(month.prefix(4).suffix(2))
    }
}
