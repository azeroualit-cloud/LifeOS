import Foundation

/// Presentation-only aggregation of server category totals, one snapshot per month.
enum NativeCategoryPeriod {
    static func months(ending month: String, count: Int) -> [String] {
        guard [3, 6, 12].contains(count), month.range(of: #"^20\d\d-(0[1-9]|1[0-2])$"#, options: .regularExpression) != nil else { return [] }
        return (0..<count).reversed().map { String(CivilDate.adding(-$0, to: month + "-01", component: .month).prefix(7)) }
    }
    static func aggregate(_ snapshots: [String: [Record]], months: [String]) throws -> [Record] {
        guard !months.isEmpty, Set(months).count == months.count, months.allSatisfy({ snapshots[$0] != nil }) else {
            throw Message(text: "Dati incompleti per il periodo selezionato.")
        }
        var totals: [String: Int64] = [:]
        for month in months {
            for row in snapshots[month] ?? [] {
                let name = row.text("name").trimmingCharacters(in: .whitespacesAndNewlines)
                guard !name.isEmpty, case .number(let amount)? = row["amount"], amount.isFinite else {
                    throw Message(text: "Dati categoria non validi.")
                }
                let cents = (amount * 100).rounded()
                guard cents.isFinite, cents > Double(Int64.min), cents < Double(Int64.max) else { throw Message(text: "Importo categoria non valido.") }
                let (sum, overflow) = (totals[name] ?? 0).addingReportingOverflow(Int64(cents))
                guard !overflow else { throw Message(text: "Totale categoria non valido.") }
                totals[name] = sum
            }
        }
        return totals.filter { $0.value > 0 }.sorted { $0.value == $1.value ? $0.key < $1.key : $0.value > $1.value }
            .map { ["name": .string($0.key), "amount": .number(Double($0.value) / 100)] }
    }
}
