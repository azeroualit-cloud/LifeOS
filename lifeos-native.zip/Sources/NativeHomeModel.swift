import Foundation

/// Deterministic presentation only: never invent shifts, appointments or weather.
struct NativeHomeSummary {
    struct Phrase: Equatable {
        let lead: String
        let detail: String
        let tail: String
        var text: String { lead + detail + tail }
    }
    let greeting: String
    let phrases: [Phrase]
    let events: [Record]
    var text: String { phrases.map(\.text).joined(separator: " ") }

    static func rollingDays(_ today: String) -> [String] {
        (-3...3).map { CivilDate.adding($0, to: today) }
    }
    static func hasCalendarData(life: Record, demo: Bool) -> Bool {
        if demo, case .array? = life["events"] { return true }
        if case .array? = life["upcomingEvents"] { return true }
        return false
    }
    static func todos(_ rows: [Record]) -> [Record] {
        rows.filter { $0.text("list_kind") == "action" && $0.text("status") == "todo" }
            .sorted {
                let a = $0.text("due_date", fallback: "9999"), b = $1.text("due_date", fallback: "9999")
                return a == b ? ($0.amount("sort_order"), $0.integer("id")) < ($1.amount("sort_order"), $1.integer("id")) : a < b
            }
    }
    init(now: Date, todayShift: ShiftKind?, tomorrowShift: ShiftKind?, previousShift: ShiftKind? = nil, events source: [Record], weather: NativeWeather?, weatherDate: Date?, calendarAvailable: Bool = true) {
        let today = CivilDate.day(now), tomorrow = CivilDate.adding(1, to: today)
        let end = CivilDate.adding(7, to: today)
        let hour = CivilDate.calendar.component(.hour, from: now)
        let clock = String(format: "%02d:%02d", hour, CivilDate.calendar.component(.minute, from: now))
        greeting = (hour < 12 ? "Buongiorno" : hour < 18 ? "Buon pomeriggio" : "Buonasera") + ", Anass."
        var seen = Set<String>()
        events = source.filter {
            let day = $0.text("day"), time = $0.text("start_time")
            let key = "\($0.integer("id")):\(day)"
            return day >= today && day < end && $0.text("occurrence_status", fallback: "open") == "open"
                && (day > today || time.isEmpty || time >= clock) && seen.insert(key).inserted
        }.sorted { ($0.text("day"), $0.text("start_time"), $0.integer("id")) < ($1.text("day"), $1.text("start_time"), $1.integer("id")) }

        var parts: [Phrase] = []
        if let weather, weather.temperature.isFinite, (-100...100).contains(weather.temperature), let updated = weatherDate, (-300...3600).contains(now.timeIntervalSince(updated)) {
            let conditions: String
            switch weather.code {
            case 0: conditions = "sereno"
            case 1...3: conditions = "cielo nuvoloso"
            case 4...49: conditions = "nebbia"
            case 50...69: conditions = "pioggia"
            case 70...79: conditions = "neve"
            case 80...94: conditions = "rovesci"
            default: conditions = "temporali"
            }
            parts.append(Phrase(lead: "A Empoli, ", detail: "\(Int(weather.temperature.rounded()))° e \(conditions)", tail: "."))
        }
        func shiftPhrase(_ kind: ShiftKind, when: String) -> Phrase {
            switch kind {
            case .morning: return Phrase(lead: when + " lavori ", detail: "dalle 6 alle 14", tail: ".")
            case .afternoon: return Phrase(lead: when + " lavori ", detail: "dalle 14 alle 22", tail: ".")
            case .night: return Phrase(lead: when + " lavori di notte, ", detail: "dalle 22 alle 6", tail: ".")
            case .rest: return Phrase(lead: when + " sei ", detail: "di riposo", tail: ".")
            case .holiday: return Phrase(lead: when + " sei ", detail: "in ferie", tail: ".")
            case .erase: return Phrase(lead: "", detail: "", tail: "")
            }
        }
        let current = todayShift == .erase ? nil : todayShift
        let next = tomorrowShift == .erase ? nil : tomorrowShift
        if previousShift == .night && hour < 6 { parts.append(Phrase(lead: "Termini la notte ", detail: "alle 6", tail: ".")) }
        if let current { parts.append(shiftPhrase(current, when: "Oggi")) }
        if let next, next != current { parts.append(shiftPhrase(next, when: "Domani")) }
        else if let next, next == current, !parts.isEmpty {
            parts[parts.count - 1] = shiftPhrase(next, when: "Oggi e domani")
        }
        if current == nil && next == nil { parts.append(Phrase(lead: "", detail: "Turni non disponibili", tail: ".")) }

        if let first = events.first {
            let day = first.text("day")
            let when = day == today ? "Oggi" : day == tomorrow ? "Domani" : CivilDate.label(day).capitalized
            let rawTitle = first.text("title", fallback: "Appuntamento").split(whereSeparator: \.isWhitespace).joined(separator: " ")
            let title = rawTitle.count > 70 ? String(rawTitle.prefix(69)) + "…" : rawTitle
            let time = first.text("start_time")
            parts.append(Phrase(lead: when + ": ", detail: title + (time.isEmpty ? "" : " alle " + time), tail: "."))
        } else {
            parts.append(Phrase(lead: "", detail: calendarAvailable ? "Nessun appuntamento nei prossimi 7 giorni" : "Calendario da aggiornare", tail: "."))
        }
        phrases = parts
    }
}
