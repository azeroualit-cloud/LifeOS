import SwiftUI

struct DailyLifePanel: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    var body: some View {
        VStack(alignment: .leading, spacing: NativeDesign.Space.medium) {
            HStack {
                Text("Attività").font(.headline)
                Spacer()
                Button("Vedi tutte") { router.tab = .tasks }.frame(minHeight: NativeDesign.Layout.touchTarget)
            }
            ForEach(store.tasks.filter { $0.text("status") == "todo" }.sorted { $0.text("due_date", fallback: "9999") < $1.text("due_date", fallback: "9999") }.prefix(3).map { DisplayRecord($0) }) { item in
                NativeChecklistRow(title: item.value.text("title"), subtitle: item.value.text("notes"), checked: false, dueDay: item.value.text("due_date"), completionLabel: "Completa " + item.value.text("title"), onComplete: {
                    Task { await store.run("setTaskStatus", ["id": item.value["id"]!, "status": .string("done")]) }
                }, onOpen: { router.sheet = .task(item.value) })
            }
            HStack {
                Text("Abitudini").font(.headline)
                Spacer()
                Button("Gestisci") { router.sheet = .routines }.frame(minHeight: NativeDesign.Layout.touchTarget)
            }
            if store.routines.isEmpty { Text("Aggiungi la tua prima abitudine.").foregroundStyle(NativeDesign.secondary) }
            ForEach(store.routines.map { DisplayRecord($0) }) { item in
                NativeChecklistRow(title: item.value.text("title"), subtitle: "", checked: item.value.flag("checked"), dueDay: "", completionLabel: "Cambia completamento " + item.value.text("title"), onComplete: {
                    Task { await store.run("setRoutineCheck", ["id": item.value["id"]!, "day": .string(CivilDate.day()), "checked": .bool(!item.value.flag("checked"))]) }
                }, onOpen: { router.sheet = .routines })
            }
        }.accessibilityIdentifier("daily-life-panel")
    }
}
