import Foundation

/// Reconciles the server's budget equation; paid fixed bills move from reserved
/// to spent rather than being counted a second time.
struct NativeBudgetSegments {
    let salary: Double
    let spent: Double
    let reserved: Double
    let remaining: Double
    let adjustment: Double
    init(_ summary: Record) {
        salary = summary.amount("monthlySalary")
        let committed = summary.amount("monthlyCommitted")
        let consumed = summary.records("monthlyFixedSettlements").reduce(0.0) { $0 + min(max(0, $1.amount("paid")), max(0, $1.amount("estimate"))) }
        spent = summary.amount("monthlySpent") + consumed
        reserved = committed - consumed
        remaining = summary.amount("monthlyRemaining")
        adjustment = salary - spent - reserved - remaining
    }
    var scale: Double { max(0.01, max(0, spent) + max(0, reserved) + max(0, remaining)) }
}

struct NativeForecastPoint: Identifiable {
    let day: String
    let value: Double
    let lower: Double
    let upper: Double
    var id: String { day }
}
struct NativeWealthForecast {
    let history: [NativeForecastPoint]
    let prediction: [NativeForecastPoint]
    let samples: Int
    let normalizedNet: Double
    let knownExtra: Double
    /// Reproducible bootstrap of complete-month cash flows. The band is conditional
    /// on known plans and observed variability, not a calibrated guarantee.
    init(finance: Record, plan: Record, day: String = CivilDate.day()) {
        let month = String(day.prefix(7)), earliest = String(CivilDate.adding(-6, to: month + "-01", component: .month).prefix(7))
        let source = finance.records("forecastHistory").filter { $0.text("month") >= earliest && $0.text("month") < month && $0.flag("observed") }
            .sorted { $0.text("month") < $1.text("month") }
        samples = source.count
        let nets = source.map { $0.amount("ordinaryNet") }.filter(\.isFinite).sorted()
        func median(_ x: [Double]) -> Double { guard !x.isEmpty else { return 0 }; return x.count % 2 == 0 ? (x[x.count / 2 - 1] + x[x.count / 2]) / 2 : x[x.count / 2] }
        let center = median(nets), mad = median(nets.map { abs($0 - center) }.sorted())
        // If most months are identical, use the central 80% range to retain a
        // genuinely recurring variable month; cap isolated extremes via MAD.
        let spread = mad > 0 ? 3 * 1.4826 * mad : max(0, (nets.count >= 4 ? nets[nets.count - 2] - nets[1] : 0))
        let robust = nets.map { min(center + spread, max(center - spread, $0)) }
        normalizedNet = robust.isEmpty ? 0 : robust.reduce(0, +) / Double(robust.count)
        let assets = finance.record("summary").amount("budget")
        var actual: [NativeForecastPoint] = finance.record("lifetime").records("series").filter { $0.text("month") >= earliest && $0.text("month") < month }.compactMap { row in
            guard case .number(let value)? = row["wealth"], value.isFinite else { return nil }
            let next = CivilDate.adding(1, to: row.text("month") + "-01", component: .month)
            let end = CivilDate.adding(-1, to: next)
            return NativeForecastPoint(day: end, value: value, lower: value, upper: value)
        }.sorted { $0.day < $1.day }
        actual.append(NativeForecastPoint(day: day, value: assets, lower: assets, upper: assets)); history = actual
        let planned = plan.records("allocations")
        let cycles = Dictionary(grouping: planned.filter { $0.text("kind") == "expense" && $0.text("payment_account", fallback: "Trade Republic") == "Trade Republic" && !["Pagato", "Annullato", "Previsto"].contains($0.text("status")) }, by: { $0.integer("cycle_id") })
        let payments: [(String, Double)] = cycles.values.compactMap { rows in
            guard let row = rows.first, !row.text("end_month").isEmpty else { return nil }
            let endMonth = String(row.text("end_month").prefix(7))
            let due = CivilDate.adding(-1, to: CivilDate.adding(1, to: endMonth + "-01", component: .month))
            let linked = plan.records("links").filter { $0.integer("cycle_id") == row.integer("cycle_id") && $0.text("role") == "payment" }.reduce(0.0) { $0 + $1.amount("attributed_cents") }
            return (max(day, due), max(0, row.amount("total_cents") - linked) / 100)
        }
        let horizon = CivilDate.adding(6, to: day, component: .month)
        knownExtra = payments.filter { $0.0 <= horizon }.reduce(0) { $0 + $1.1 }
        guard robust.count >= 4 else { prediction = []; return }
        var state: UInt64 = 0x4C6966654F53
        func draw() -> Double { state = state &* 6364136223846793005 &+ 1442695040888963407; return robust[Int((state >> 32) % UInt64(robust.count))] }
        var paths = Array(repeating: assets, count: 2000)
        var points = [NativeForecastPoint(day: day, value: assets, lower: assets, upper: assets)]
        var previous = day
        for step in 1...6 {
            let date = CivilDate.adding(step, to: day, component: .month)
            let payment = payments.filter { $0.0 <= date && ($0.0 > previous || step == 1 && $0.0 == day) }.reduce(0.0) { $0 + $1.1 }
            for i in paths.indices { paths[i] += draw() - payment }
            let sorted = paths.sorted()
            let expected = assets + Double(step) * normalizedNet - payments.filter { $0.0 <= date }.reduce(0.0) { $0 + $1.1 }
            points.append(NativeForecastPoint(day: date, value: expected, lower: min(expected, sorted[199]), upper: max(expected, sorted[1799])))
            previous = date
        }
        prediction = points
    }
}
