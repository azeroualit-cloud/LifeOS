import Foundation

/// Reconciles the server's budget equation; paid fixed bills move from reserved
/// to spent rather than being counted a second time.
struct NativeBudgetSegments {
    let salary: Double
    let spent: Double
    let reserved: Double
    let remaining: Double
    let adjustment: Double
    init(_ summary: Record) {
        salary = summary.amount("monthlySalary")
        let committed = summary.amount("monthlyCommitted")
        let consumed = summary.records("monthlyFixedSettlements").reduce(0.0) { $0 + min(max(0, $1.amount("paid")), max(0, $1.amount("estimate"))) }
        spent = summary.amount("monthlySpent") + consumed
        reserved = committed - consumed
        remaining = summary.amount("monthlyRemaining")
        adjustment = salary - spent - reserved - remaining
    }
    var scale: Double { max(0.01, max(0, spent) + max(0, reserved) + max(0, remaining)) }
}

struct NativeForecastPoint: Identifiable {
    let day: String
    let value: Double
    let lower: Double
    let upper: Double
    var id: String { day }
}
struct NativeWealthForecast {
    let history: [NativeForecastPoint]
    let prediction: [NativeForecastPoint]
    let samples: Int
    let normalizedNet: Double
    let knownExtra: Double
    /// Reproducible bootstrap of complete-month cash flows. The band is conditional
    /// on known plans and observed variability, not a calibrated guarantee.
    init(finance: Record, plan: Record, day: String = CivilDate.day()) {
        let month = String(day.prefix(7)), earliest = String(CivilDate.adding(-6, to: month + "-01", component: .month).prefix(7))
        let source = finance.records("forecastHistory").filter { $0.text("month") >= earliest && $0.text("month") < month && $0.flag("observed") }
            .sorted { $0.text("month") < $1.text("month") }
        samples = source.count
        // Older gateways separate only the planned attribution from an Extra.
        // Reconcile actual settlements locally; comparing with extraPaid also
        // supports gateways that already separate the full actual payment.
        let paymentLinks = plan.records("links").filter { $0.text("role") == "payment" && $0.text("account") == "Trade Republic" }
        let grouped = Dictionary(grouping: paymentLinks, by: { $0.integer("movement_source_row") })
        var actualExtras: [String: Double] = [:]
        for links in grouped.values {
            guard let first = links.first else { continue }
            let attributed = links.reduce(0.0) { sum, link in
                let settled = plan.records("settlements").first { $0.integer("cycle_id") == link.integer("cycle_id") && $0.integer("movement_source_row") == link.integer("movement_source_row") }
                return sum + (settled?.amount("actual_cents") ?? link.amount("attributed_cents")) / 100
            }
            let month = String(first.text("actual_date").prefix(7))
            actualExtras[month, default: 0] += min(max(0, -first.amount("amount")), attributed)
        }
        let newPlans = finance.record("plansV2").records("plans")
        for payment in finance.record("plansV2").records("payments") where payment.text("status") == "posted" && !payment.flag("legacy") {
            guard let linkedPlan = newPlans.first(where: { $0.text("id") == payment.text("planId") }),
                  (["goal", "fund", "recovery"].contains(linkedPlan.text("kind")) || linkedPlan.text("kind") == "fixed" && linkedPlan.integer("intervalMonths") > 1) else { continue }
            actualExtras[String(payment.text("date").prefix(7)), default: 0] += Double(payment.integer("amountCents")) / 100
        }
        let nets = source.map { row in row.amount("ordinaryNet") + max(0, (actualExtras[row.text("month")] ?? 0) - row.amount("extraPaid")) }.filter(\.isFinite).sorted()
        func median(_ x: [Double]) -> Double { guard !x.isEmpty else { return 0 }; return x.count % 2 == 0 ? (x[x.count / 2 - 1] + x[x.count / 2]) / 2 : x[x.count / 2] }
        let center = median(nets), mad = median(nets.map { abs($0 - center) }.sorted())
        // If most months are identical, use the central 80% range to retain a
        // genuinely recurring variable month; cap isolated extremes via MAD.
        let spread = mad > 0 ? 3 * 1.4826 * mad : max(0, (nets.count >= 4 ? nets[nets.count - 2] - nets[1] : 0))
        let robust = nets.map { min(center + spread, max(center - spread, $0)) }
        normalizedNet = robust.isEmpty ? 0 : robust.reduce(0, +) / Double(robust.count)
        let assets = finance.record("summary").amount("budget")
        var actual: [NativeForecastPoint] = finance.record("lifetime").records("series").filter { $0.text("month") >= earliest && $0.text("month") < month }.compactMap { row in
            guard case .number(let value)? = row["wealth"], value.isFinite else { return nil }
            let next = CivilDate.adding(1, to: row.text("month") + "-01", component: .month)
            let end = CivilDate.adding(-1, to: next)
            return NativeForecastPoint(day: end, value: value, lower: value, upper: value)
        }.sorted { $0.day < $1.day }
        actual.append(NativeForecastPoint(day: day, value: assets, lower: assets, upper: assets)); history = actual
        let planned = plan.records("allocations")
        let cycles = Dictionary(grouping: planned.filter { $0.text("kind") == "expense" && $0.text("payment_account", fallback: "Trade Republic") == "Trade Republic" && !["Pagato", "Annullato", "Previsto"].contains($0.text("status")) }, by: { $0.integer("cycle_id") })
        let legacyPayments: [(String, Double)] = cycles.values.compactMap { rows in
            guard let row = rows.first, !row.text("end_month").isEmpty else { return nil }
            let endMonth = String(row.text("end_month").prefix(7))
            let due = CivilDate.adding(-1, to: CivilDate.adding(1, to: endMonth + "-01", component: .month))
            let linked = plan.records("links").filter { $0.integer("cycle_id") == row.integer("cycle_id") && $0.text("role") == "payment" }.reduce(0.0) { $0 + $1.amount("attributed_cents") }
            return (max(day, due), max(0, row.amount("total_cents") - linked) / 100)
        }
        let newPayments: [(String, Double)] = newPlans.compactMap { row in
            guard row.text("kind") == "goal", row.text("status") == "active", NativePlanRules.validMonth(row.text("endMonth")) else { return nil }
            let due = CivilDate.adding(-1, to: CivilDate.adding(1, to: row.text("endMonth") + "-01", component: .month))
            return (max(day, due), Double(row["outstandingCents"] == nil ? row.integer("amountCents") : row.integer("outstandingCents")) / 100)
        }
        let recurringPayments: [(String, Double)] = newPlans.flatMap { row -> [(String, Double)] in
            guard row.text("kind") == "fixed", row.text("status") == "active", row.integer("intervalMonths") > 1, NativePlanRules.validMonth(row.text("startMonth")) else { return [] }
            let interval = row.integer("intervalMonths")
            return (0...6).compactMap { offset -> (String, Double)? in
                let month = NativePlanRules.adding(offset, to: String(day.prefix(7)))
                guard month >= row.text("startMonth") else { return nil }
                let cycle = NativePlanRules.cycleKey(row, month: month)
                guard NativePlanRules.adding(interval - 1, to: cycle) == month else { return nil }
                var amount = row.integer("amountCents")
                for change in row.records("rateChanges").sorted(by: { $0.text("fromMonth") < $1.text("fromMonth") }) where change.text("fromMonth") <= month { amount = change.integer("amountCents") }
                let paid = finance.record("plansV2").records("payments").filter { $0.text("planId") == row.text("id") && $0.text("status") == "posted" && $0.text("settlementKey") == cycle }.reduce(0) { $0 + $1.integer("amountCents") }
                let due = CivilDate.adding(-1, to: CivilDate.adding(1, to: month + "-01", component: .month))
                return (max(day, due), Double(max(0, amount - paid)) / 100)
            }
        }
        let payments = legacyPayments + newPayments + recurringPayments
        let horizon = CivilDate.adding(6, to: day, component: .month)
        knownExtra = payments.filter { $0.0 <= horizon }.reduce(0) { $0 + $1.1 }
        guard robust.count >= 4 else { prediction = []; return }
        var state: UInt64 = 0x4C6966654F53
        func draw() -> Double { state = state &* 6364136223846793005 &+ 1442695040888963407; return robust[Int((state >> 32) % UInt64(robust.count))] }
        var paths = Array(repeating: assets, count: 2000)
        var points = [NativeForecastPoint(day: day, value: assets, lower: assets, upper: assets)]
        var previous = day
        for step in 1...6 {
            let date = CivilDate.adding(step, to: day, component: .month)
            let payment = payments.filter { $0.0 <= date && ($0.0 > previous || step == 1 && $0.0 == day) }.reduce(0.0) { $0 + $1.1 }
            for i in paths.indices { paths[i] += draw() - payment }
            let sorted = paths.sorted()
            let expected = assets + Double(step) * normalizedNet - payments.filter { $0.0 <= date }.reduce(0.0) { $0 + $1.1 }
            points.append(NativeForecastPoint(day: date, value: expected, lower: min(expected, sorted[199]), upper: max(expected, sorted[1799])))
            previous = date
        }
        prediction = points
    }
}

/// Month budgets and the current account balance are deliberately separate.
struct NativeFinanceOverview {
    let remaining: Double?
    let balance: Double?
    let days: Int
    let daily: Double
    let periodLabel: String
    init(summary: Record, month: String, day: String = CivilDate.day()) {
        func finite(_ key: String) -> Double? {
            guard case .number(let value)? = summary[key], value.isFinite else { return nil }
            return value
        }
        remaining = finite("monthlyRemaining")
        balance = finite("budget")
        let budget = NativeValidation.dailyBudget(summary, day: day, month: month)
        days = budget.days
        daily = remaining == nil ? 0 : budget.low
        let current = String(day.prefix(7))
        periodLabel = month < current ? "Mese concluso · riepilogo del budget" : month > current ? "\(days) giorni del mese selezionato" : "\(days) giorni · incluso oggi"
    }
}
