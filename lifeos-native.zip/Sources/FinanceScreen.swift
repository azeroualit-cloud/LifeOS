import SwiftUI
import Charts

struct FinanceScreen: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    @State private var section = "Panoramica"
    @State private var search = ""
    @State private var account = "Tutti"
    @State private var range = 6
    @Environment(\.dynamicTypeSize) private var typeSize
    @AppStorage("native-hide-money") private var hidden = false
    private var chartRows: [Record] {
        let rows = range == 0 ? store.finance.record("lifetime").records("series") : store.finance.records("yearly")
        let selected = rows.filter { $0.text("month") <= store.financeMonth }
        return range == 0 ? selected : Array(selected.suffix(range))
    }
    var body: some View {
        List {
            Section {
                Picker("Sezione", selection: $section) { ForEach(["Panoramica", "Movimenti", "Extra"], id: \.self) { Text($0) } }.pickerStyle(.segmented)

            }
            if section == "Panoramica" { overview }
            else if section == "Movimenti" { movements }
            else { extras }
        }.modifier(NativeListAppearance()).accessibilityIdentifier("finance-scroll")
        .task(id: store.financeGeneration) { await store.loadAnalysis() }
        .onAppear { router.financeSection = section }
        .onChange(of: section) { _, value in router.financeSection = value }
    }
    @ViewBuilder private var overview: some View {
        Section { MonthControl(finance: true) }
        Section {
            NativeBudgetHero().listRowInsets(EdgeInsets()).listRowBackground(Color.clear)
        }
        Section {
            HStack(spacing: 18) {
                NativeSavingsRing(progress: NativeSavingsProgress(summary: store.summary, planning: store.finance.record("planning")), hidden: hidden)
                VStack(alignment: .leading, spacing: 6) {
                    Text("Patrimonio totale").font(.subheadline.weight(.medium))
                    Text("Il denaro che possiedi. Il fondo emergenza ne fa parte.").font(.caption).foregroundStyle(Color.secondary)
                    Button("Obiettivo e fondo emergenza") { router.sheet = .planning }.font(.caption).frame(minHeight: 44)
                }
            }.padding(.vertical, 4)
        }
        Section {
            HStack(spacing: 8) {
                Text("Andamento del mese").font(.subheadline.weight(.medium))
                Spacer(minLength: 4)
                Menu {
                    Button("Mese precedente", systemImage: "chevron.left") { Task { await store.changeMonth(-1, finance: true) } }
                    Button("Mese successivo", systemImage: "chevron.right") { Task { await store.changeMonth(1, finance: true) } }
                } label: { HStack(spacing: 3) { Text(CivilDate.monthTitle(store.financeMonth)); Image(systemName: "chevron.down") }.font(.caption).frame(minHeight: 44) }.disabled(store.busy).accessibilityLabel("Mese dell’analisi")
            }
            let series = dailySpending
            if series.isEmpty {
                if store.analysisBusy { HStack { ProgressView(); Text("Aggiorno analisi…").font(.caption).foregroundStyle(Color.secondary) } }
                else { Text("Nessun dato giornaliero per questo mese").font(.caption).foregroundStyle(Color.secondary) }
            } else {
                NativeDailySpendingChart(rows: series)
            }
            if !store.analysisIsCurrent && !store.analysisBusy { Button("Aggiorna analisi") { Task { await store.loadAnalysis() } }.font(.caption) }
        }
        Section {
            Group {
                if typeSize.isAccessibilitySize { VStack(alignment: .leading, spacing: 16) { forecast; Divider(); extraTotal } }
                else { HStack(alignment: .top, spacing: 20) { forecast; Divider().frame(height: 64); extraTotal } }
            }.padding(.vertical, 5)
        }
        Section {
            HStack { Text("Ultimi movimenti").font(.subheadline.weight(.medium)); Spacer(); Button("Vedi tutti") { section = "Movimenti" }.font(.caption) }
            ForEach(store.transactions.prefix(4).map { DisplayRecord($0, key: "row") }) { item in
                Button { router.sheet = .movement(item.value) } label: {
                    HStack(spacing: 10) {
                        Image(systemName: NativeCategoryIcon.name(item.value.text("displayCategory", fallback: item.value.text("category")))).foregroundStyle(NativeDesign.accent).frame(width: 28)
                        VStack(alignment: .leading, spacing: 3) { Text(item.value.text("name")).font(.subheadline).lineLimit(2).foregroundStyle(Color.primary); Text(CivilDate.label(item.value.text("date"))).font(.caption2).foregroundStyle(Color.secondary) }
                        Spacer(); Text(hidden ? "••••" : item.value.amount("amount").euro).font(.subheadline).monospacedDigit().foregroundStyle(Color.primary)
                    }.frame(minHeight: 44).multilineTextAlignment(.leading)
                }.buttonStyle(.plain)
            }
            if store.transactions.isEmpty { Text("Nessun movimento nel mese").font(.caption).foregroundStyle(Color.secondary) }
        }
        if !store.state.pending.isEmpty {
            Section { Label("\(store.state.pending.count) movimenti salvati sul dispositivo", systemImage: "icloud.and.arrow.up").font(.subheadline); Text("In attesa di sincronizzazione. Il saldo mostra l’ultimo dato del server.").font(.caption).foregroundStyle(Color.secondary) }
        }
        Section {
            NavigationLink { List { detailedOverview }.modifier(NativeListAppearance()).navigationTitle("Dettagli finanza").navigationBarTitleDisplayMode(.inline) } label: { Label("Budget, ricorrenti e analisi", systemImage: "chart.xyaxis.line").font(.subheadline) }
            NativeConnectionBadge()
        }
    }
    private var dailySpending: [Record] {
        let rows = store.transactions.filter { $0.text("date").hasPrefix(store.financeMonth) && $0.text("type") == "Spesa" && $0.amount("amount") < 0 }
        let grouped = Dictionary(grouping: rows, by: { $0.text("date") })
        let count = CivilDate.calendar.range(of: .day, in: .month, for: CivilDate.date(store.financeMonth + "-01"))?.count ?? 30
        guard !rows.isEmpty else { return [] }
        return (1...count).map { day in
            let key = store.financeMonth + String(format: "-%02d", day)
            return ["day": .string(String(day)), "spent": .number((grouped[key] ?? []).reduce(0) { $0 - $1.amount("amount") })]
        }
    }
    private var forecast: some View {
        VStack(alignment: .leading, spacing: 7) {
            Label("Riservato alle prossime spese", systemImage: "lock").font(.caption).foregroundStyle(Color.secondary)
            Text(hidden ? "•••• €" : store.summary.amount("committedCurrent").euro).font(.title3.weight(.semibold)).monospacedDigit()
            Text("Già compreso nel patrimonio, non sottratto di nuovo.").font(.caption2).foregroundStyle(Color.secondary)
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
    private var extraTotal: some View {
        VStack(alignment: .leading, spacing: 7) {
            Label("Da accantonare questo mese", systemImage: "tray.and.arrow.down").font(.caption).foregroundStyle(Color.secondary)
            let amount = store.allocations.filter { $0.text("month") == store.financeMonth }.reduce(0.0) { $0 + $1.amount("amount_cents") / 100 }
            Text(hidden ? "•••• €" : amount.euro).font(.title3.weight(.semibold)).monospacedDigit()
            Text("Per le spese extra pianificate").font(.caption2).foregroundStyle(Color.secondary)
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
    @ViewBuilder private var detailedOverview: some View {
        Section {
            NativeBudgetHero().listRowInsets(EdgeInsets()).listRowBackground(Color.clear)
        }
        if store.analysisBusy { Section { HStack(spacing: 10) { ProgressView(); Text("Aggiorno grafici e storico…").font(.caption).foregroundStyle(Color.secondary) } }.listRowBackground(Color.clear) }
        else if !store.analysisIsCurrent { Section { Button("Aggiorna grafici e storico") { Task { await store.loadAnalysis() } }.font(.caption) }.listRowBackground(Color.clear) }
        Section {
            if store.summary.isEmpty { ContentUnavailableView("Nessun dato caricato", systemImage: "chart.bar", description: Text("Apri Impostazioni per collegare Life OS o esplorare la demo.")) }
            else {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Patrimonio totale").font(.subheadline).foregroundStyle(Color.secondary)
                    HStack {
                        if hidden { Text("•••• €").font(.largeTitle.bold()) } else { Text(store.summary.amount("budget").euro).font(.system(.title2, weight: .semibold)).monospacedDigit() }
                        Spacer()
                    }
                    if !hidden { Text("Di cui " + store.summary.amount("committedCurrent").euro + " riservati alle prossime spese. Restano " + store.summary.amount("remainingFree").euro + " non riservati.").font(.caption).foregroundStyle(Color.secondary).monospacedDigit() }
                }.padding(.vertical, 8)
                LabeledContent("Conto", value: store.summary.text("account", fallback: "Trade Republic"))
                if let date = store.state.financeRefreshedAt { LabeledContent("Aggiornato", value: date.formatted(date: .abbreviated, time: .shortened)).font(.caption).foregroundStyle(Color.secondary) }
            }
        }
        if !store.state.pending.isEmpty {
            Section("Movimenti sul dispositivo") {
                LabeledContent("Da sincronizzare", value: String(store.state.pending.filter { !$0.accepted }.count))
                LabeledContent("Inviati, da aggiornare", value: String(store.state.pending.filter(\.accepted).count))
                Text("Il saldo resta quello dell’ultimo aggiornamento del server.").font(.caption).foregroundStyle(Color.secondary)
            }
        }
        if store.summary["monthlyRemaining"] != nil { Section("Dettagli del budget") {
            LabeledContent("Impegni del mese", value: store.summary.amount("monthlyCommitted").euro)
            Button("Dettaglio del calcolo") { router.sheet = .budget }
        } }
        if !chartRows.isEmpty {
            Section("Entrate e uscite") {
                Picker("Periodo", selection: $range) { Text("3 mesi").tag(3); Text("6 mesi").tag(6); Text("12 mesi").tag(12); Text("Tutto").tag(0) }.pickerStyle(.segmented)
                Chart {
                    ForEach(chartRows.map { DisplayRecord(["day": .string($0.text("month")), "income": $0["income"] ?? .number(0), "spent": $0["spent"] ?? .number(0)], key: "day") }) { item in
                        BarMark(x: .value("Mese", item.value.text("day")), y: .value("Euro", item.value.amount("income"))).foregroundStyle(by: .value("Flusso", "Entrate")).position(by: .value("Flusso", "Entrate"))
                        BarMark(x: .value("Mese", item.value.text("day")), y: .value("Euro", item.value.amount("spent"))).foregroundStyle(by: .value("Flusso", "Uscite")).position(by: .value("Flusso", "Uscite"))
                    }
                }.chartForegroundStyleScale(["Entrate": NativeDesign.accent, "Uscite": Color.orange]).chartXAxis { AxisMarks { value in AxisValueLabel { if let month = value.as(String.self) { Text(String(month.suffix(2))).font(.caption2) } } } }.frame(height: 160)
            }
        }
        let categories = store.finance.records("categories").filter { $0.amount("amount") > 0 && $0.amount("amount").isFinite }.sorted { $0.amount("amount") > $1.amount("amount") }
        if !categories.isEmpty {
            Section("Spese per categoria") {
                NativeCategoryChart(rows: categories)
            }
        }
        Section("Ricorrenti") {
            ForEach(store.finance.records("recurring").indices, id: \.self) { i in
                let record = store.finance.records("recurring")[i]
                Button { router.sheet = .recurring(record) } label: { HStack { Text(record.text("name")).foregroundStyle(Color.primary); Spacer(); MoneyText(amount: record.amount("estimate")).foregroundStyle(Color.secondary) } }
            }
        }
        Section("Obiettivo di risparmio") {
            let progress = NativeSavingsProgress(summary: store.summary, planning: store.finance.record("planning"))
            LabeledContent("Fondo emergenza", value: progress.emergency.euro)
            LabeledContent("Prossimo traguardo", value: progress.target.euro)
            LabeledContent("Manca", value: progress.missing.euro)
            LabeledContent("Da risparmiare al mese", value: progress.monthly.euro)
            Text("Cifra mancante divisa per \(progress.months) mesi fino a dicembre, incluso quello corrente.").font(.caption).foregroundStyle(Color.secondary)
            Button("Modifica fondo emergenza") { router.sheet = .planning }
        }
        Section { NavigationLink("Analisi e storico") { FinanceAnalysisScreen() } }
        Section("Storico pagamenti") {
            ForEach(store.finance.records("history").prefix(30).enumerated().map { IndexedRecord(index: $0.offset, value: $0.element) }) { item in
                HStack { VStack(alignment: .leading) { Text(item.value.text("name")); Text(CivilDate.label(item.value.text("date"))).font(.caption).foregroundStyle(Color.secondary) }; Spacer(); MoneyText(amount: item.value.amount("paid")) }
            }
            if store.finance.records("history").isEmpty { Text("Nessun pagamento ricorrente").foregroundStyle(Color.secondary) }
            else { NavigationLink("Tutto lo storico pagamenti") { BillsHistoryScreen() } }
        }
    }
    @ViewBuilder private var movements: some View {
        Section { MonthControl(finance: true) }
        Section {
            TextField("Cerca movimento", text: $search)
            Picker("Conto", selection: $account) { ForEach(["Tutti", "Trade Republic", "Revolut", "IsyBank"], id: \.self) { Text($0) } }
        }
        if !store.state.pending.isEmpty {
            Section("Salvati sul dispositivo") {
                ForEach(store.state.pending) { pending in
                    HStack { VStack(alignment: .leading) { Text(pending.payload.text("name")); Text(pending.accepted ? "Inviato · aggiornamento da completare" : "Da sincronizzare").font(.caption).foregroundStyle(Color.secondary) }; Spacer(); MoneyText(amount: pending.payload.amount("amount")) }
                }
            }
        }
        let rows = store.transactions.filter { (account == "Tutti" || $0.text("account") == account) && (search.isEmpty || ($0.text("name") + $0.text("category")).localizedCaseInsensitiveContains(search)) }
        Section("Movimenti del mese") {
            if rows.isEmpty { Text("Nessun movimento").foregroundStyle(Color.secondary) }
            ForEach(rows.map { DisplayRecord($0, key: "row") }) { item in
                Button { router.sheet = .movement(item.value) } label: {
                    HStack(alignment: .top, spacing: 12) {
                        NativeIcon(name: NativeCategoryIcon.name(item.value.text("displayCategory", fallback: item.value.text("category"))), color: item.value.amount("amount") < 0 ? NativeDesign.accent : .green)
                        VStack(alignment: .leading, spacing: 5) { Text(item.value.text("name")).font(.body.weight(.medium)).foregroundStyle(Color.primary); Text(item.value.text("displayCategory", fallback: item.value.text("category")) + " · " + CivilDate.label(item.value.text("date"))).font(.caption).foregroundStyle(Color.secondary) }
                        Spacer(); MoneyText(amount: item.value.amount("amount")).foregroundStyle(item.value.amount("amount") < 0 ? Color.primary : Color.green)
                    }.padding(.vertical, 3)
                }
            }
        }
    }
    @ViewBuilder private var extras: some View {
        Section { MonthControl(finance: true) }
        let selected = store.allocations.filter { $0.text("month") == store.financeMonth }
        Section("Spese extra · " + CivilDate.monthTitle(store.financeMonth)) {
            if selected.isEmpty { Text("Nessun accantonamento in questo mese").foregroundStyle(Color.secondary) }
            ForEach(selected.map { DisplayRecord($0, key: "cycle_id") }) { item in
                Button { router.sheet = .extra(item.value) } label: {
                    HStack { VStack(alignment: .leading) { Text(item.value.text("name")).foregroundStyle(Color.primary); Text(NativeExtraState.title(item.value.text("status"))).font(.caption).foregroundStyle(Color.secondary) }; Spacer(); MoneyText(amount: Double(NativeExtraState.displayedCents(item.value, plan: store.state.plan)) / 100).foregroundStyle(Color.primary) }
                }
            }
        }
        Section {
            Button { router.sheet = .extra([:]) } label: { Label("Pianifica una spesa extra", systemImage: "plus.circle") }.buttonStyle(.plain)
            Text("Pianifica il totale e i mesi di accantonamento. Quando paghi, apri la voce e registra l’importo effettivo: il pagamento usa i risparmi, senza addebitare di nuovo il budget del mese.").font(.caption).foregroundStyle(Color.secondary)
        }
    }
}
struct NativeDailySpendingChart: View {
    let rows: [Record]
    var body: some View {
        Chart {
            ForEach(Array(rows.enumerated()), id: \.offset) { index, row in
                BarMark(x: .value("Giorno", Int(row.text("day")) ?? index + 1), y: .value("Spese", row.amount("spent")))
                    .foregroundStyle(NativeDesign.accent.opacity(index % 7 == 0 ? 1 : 0.35)).cornerRadius(2)
            }
        }
        .chartXScale(domain: 0...(rows.count + 1))
        .chartLegend(.hidden)
        .chartXAxis { AxisMarks(values: [1, 5, 10, 15, 20, 25]) }
        .chartYAxis {
            AxisMarks(position: .trailing) { value in
                AxisGridLine()
                AxisValueLabel {
                    if let amount = value.as(Double.self) {
                        Text(amount.formatted(.number.precision(.fractionLength(0)).locale(Locale(identifier: "it_IT"))) + " €").font(.caption2).foregroundStyle(Color.secondary)
                    }
                }
            }
        }
        .frame(height: 112).accessibilityLabel("Spese giornaliere del mese")
    }
}
struct IndexedRecord: Identifiable { let index: Int; let value: Record; var id: Int { index } }
struct BudgetDetail: View {
    @EnvironmentObject var store: NativeStore
    var body: some View {
        List {
            Section(CivilDate.monthTitle(store.financeMonth)) {
                LabeledContent("Stipendio di riferimento", value: store.summary.amount("monthlySalary").euro)
                ForEach(store.summary.records("monthlyBudgetBreakdown").enumerated().map { IndexedRecord(index: $0.offset, value: $0.element) }) { item in LabeledContent(item.value.text("name"), value: item.value.amount("amount").euro) }
                LabeledContent("Spese libere", value: store.summary.amount("monthlySpent").euro)
                LabeledContent("Residuo", value: store.summary.amount("monthlyRemaining").euro)
            }
            Section("Impegni sul saldo attuale") {
                ForEach(store.summary.records("recurringCommitments").enumerated().map { IndexedRecord(index: $0.offset, value: $0.element) }) { item in LabeledContent(item.value.text("name"), value: item.value.amount("remaining").euro) }
                LabeledContent("Totale impegnato", value: store.summary.amount("committedCurrent").euro)
            }
            Section("Range giornaliero attuale") {
                let daily = NativeValidation.dailyBudget(store.summary)
                LabeledContent("Da", value: daily.low.euro)
                LabeledContent("A", value: daily.high.euro)
                Text("\(daily.days) giorni, oggi incluso. Usa il residuo mensile e lo stipendio meno le spese, come la PWA 11.63.").font(.caption).foregroundStyle(Color.secondary)
            }
        }.navigationTitle("Budget").toolbar { DoneButton() }
    }
}

struct MovementEditor: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    let record: Record
    @State private var detail: Record = [:]
    @State private var name = ""
    @State private var amount = ""
    @State private var type = "Spesa"
    @State private var account = "Trade Republic"
    @State private var category = "Altro"
    @State private var date = Date()
    @State private var note = ""
    @State private var counterpart = "Trade Republic"
    @State private var months = 1
    @State private var treatment = "auto"
    @State private var recovery = ""
    @State private var recoveryAmount = ""
    @State private var included = false
    @State private var saving = false
    @State private var loaded = false
    @State private var error: String?
    @State private var confirmDelete = false
    @State private var requestID = UUID().uuidString
    private var editing: Bool { record.integer("row") > 0 }
    private var options: [String] {
        var rows = type == "Entrata" ? ["Stipendio", "Interessi", "Rimborsi", "Altro"] : Input.categories
        if !rows.contains(category) { rows.append(category) }; return rows
    }
    var body: some View {
        Form {
            Section {
                Picker("Tipo", selection: $type) {
                    ForEach(editing ? ["Spesa", "Entrata", "Rimborso", "Trasferimento", "Investimento", "Da verificare"] : ["Spesa", "Entrata", "Rimborso", "Trasferimento"], id: \.self) { Text($0) }
                }
                TextField("Importo €", text: $amount).keyboardType(.decimalPad)
                TextField("Descrizione", text: $name)
                DatePicker("Data", selection: $date, in: ...Date(), displayedComponents: .date)
                if editing { Picker("Conto", selection: $account) { ForEach(["Trade Republic", "Revolut", "IsyBank"], id: \.self) { Text($0) } } }
                else { LabeledContent("Conto", value: type == "Trasferimento" ? "Revolut" : "Trade Republic") }
                if type == "Trasferimento" { Picker("Destinazione", selection: $counterpart) { ForEach(editing ? ["Trade Republic", "Revolut", "IsyBank"] : ["Trade Republic"], id: \.self) { Text($0) } } }
                else { Picker("Categoria", selection: $category) { ForEach(options, id: \.self) { Text($0) } } }
            }
            Section("Budget") {
                Stepper("Mesi coperti: \(months)", value: $months, in: 1...12)
                if type == "Spesa" {
                    Picker("Trattamento", selection: $treatment) {
                        Text("Automatico").tag("auto"); Text("Ordinaria").tag("ordinary"); Text("Già pianificata").tag("planned"); Text("Da risparmi").tag("savings"); Text("Recupero nei mesi scelti").tag("recovery")
                    }
                    if treatment == "recovery" { TextField("Mesi AAAA-MM, separati da virgole", text: $recovery).textInputAutocapitalization(.never); TextField("Importo da recuperare €", text: $recoveryAmount).keyboardType(.decimalPad) }
                }
                if !editing && type != "Trasferimento" { Toggle("Già inclusa nel saldo rilevato", isOn: $included); Text("Usa questa opzione solo se la banca aveva già contabilizzato il movimento nella rilevazione. Il server verifica la data.").font(.caption).foregroundStyle(Color.secondary) }
            }
            Section("Note") { TextField("Note", text: $note, axis: .vertical) }
            if let error { Text(error).foregroundStyle(.red) }
            if editing { Section { Button("Elimina movimento", role: .destructive) { confirmDelete = true }.disabled(saving || store.busy || !loaded) } }
        }.navigationTitle(editing ? "Modifica movimento" : "Nuovo movimento").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() }.disabled(saving) }
            ToolbarItem(placement: .confirmationAction) { Button("Salva") { Task { await save() } }.disabled(saving || store.busy || !loaded || Input.cents(amount) == nil || name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
        }
        .confirmationDialog("Eliminare il movimento? Eventuali collegamenti finanziari saranno aggiornati dal server.", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Elimina", role: .destructive) { Task { do { try await store.perform("deleteMovement", args: [.int(record.integer("row"))]); dismiss() } catch { self.error = error.localizedDescription } } }
        }
        .task {
            if editing && !store.isDemo {
                do { let r = try await store.read("getMovement", args: [.int(record.integer("row"))]); populate(r.object); loaded = true }
                catch { self.error = error.localizedDescription }
            } else { populate(record); loaded = true }
        }
    }
    private func populate(_ r: Record) {
        detail = r; name = r.text("description", fallback: r.text("name")); amount = r.isEmpty ? "" : String(format: "%.2f", abs(r.amount("amount"))).replacingOccurrences(of: ".", with: ",")
        type = r.text("movement_type", fallback: r.text("type", fallback: "Spesa"))
        if r.text("notes").hasPrefix("Rimborso / restituzione:") { type = "Rimborso" }
        account = r.text("account", fallback: "Trade Republic"); category = r.text("category", fallback: "Altro")
        date = CivilDate.date(r.text("actual_date", fallback: r.text("date", fallback: CivilDate.day())))
        note = r.text("notes", fallback: r.text("note")); months = max(1, r.integer("competence_months") == 0 ? r.integer("months") : r.integer("competence_months"))
        treatment = r.text("budgetTreatment", fallback: "auto"); recovery = r.text("recoveryMonths"); recoveryAmount = String(r.amount("recoveryAmount")); counterpart = r.text("counterparty_account", fallback: r.text("counterpart", fallback: "Trade Republic"))
    }
    private func save() async {
        guard let cents = Input.cents(amount) else { return }
        saving = true; defer { saving = false }
        var payload: Record = ["requestId": .string(requestID), "row": .int(record.integer("row")), "name": .string(name), "amount": .number(Double(cents) / 100), "type": .string(type),
            "account": .string(editing ? account : type == "Trasferimento" ? "Revolut" : "Trade Republic"), "category": .string(category), "date": .string(CivilDate.day(date)), "months": .int(months), "note": .string(note),
            "counterpart": .string(counterpart), "includedInSnapshot": .bool(included), "budgetTreatment": .string(type == "Spesa" ? treatment : "auto")]
        if treatment == "recovery" && type == "Spesa" {
            payload["recoveryMonths"] = .string(recovery)
            if !recoveryAmount.isEmpty { guard let recoverCents = Input.cents(recoveryAmount) else { error = "Importo di recupero non valido."; return }; payload["recoveryAmount"] = .number(Double(recoverCents) / 100) }
        }
        do { try await store.perform(editing ? "editMovement" : "saveTransaction", payload); dismiss() }
        catch { self.error = error.localizedDescription }
    }
}
