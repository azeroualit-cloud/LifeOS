import SwiftUI
import Charts

struct FinanceScreen: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    @ScaledMetric(relativeTo: .largeTitle) private var budgetAmountSize = NativeDesign.Layout.budgetAmount
    @State private var showingExtras = false
    @State private var search = ""
    @State private var account = "Tutti"
    @AppStorage("native-hide-money") private var hidden = false
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: NativeDesign.Space.bottom) {
                MonthControl(finance: true)
                balance
                actions
                recentMovements
                if !store.state.pending.isEmpty {
                    VStack(alignment: .leading, spacing: NativeDesign.Space.xs) {
                        Label("\(store.state.pending.count) movimenti salvati sul dispositivo", systemImage: "icloud.and.arrow.up").font(.subheadline)
                        Text("In attesa di sincronizzazione. Il saldo mostra l’ultimo dato del server.").font(.caption).foregroundStyle(NativeDesign.secondary)
                    }
                }
                NativeConnectionBadge()
            }.padding(.horizontal, NativeDesign.Layout.screenInset)
                .padding(.top, NativeDesign.Space.small).padding(.bottom, NativeDesign.Layout.scrollClearance)
        }.background(NativeDesign.canvas).scrollBounceBehavior(.basedOnSize).accessibilityIdentifier("finance-scroll")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                NavigationLink { FinanceAnalysisScreen() } label: { Image(systemName: "chart.xyaxis.line").font(NativeDesign.symbol) }
                    .accessibilityLabel("Analisi").accessibilityIdentifier("finance-analysis")
            }
        }
        .navigationDestination(isPresented: $showingExtras) { NativePlansScreen() }
        .onAppear { router.financeSection = "Panoramica" }
    }
    private var balance: some View {
        VStack(spacing: NativeDesign.Space.section) {
            VStack(spacing: NativeDesign.Space.small) {
                HStack(spacing: NativeDesign.Space.xs) {
                    Text("Budget rimanente").font(.subheadline).foregroundStyle(NativeDesign.secondary)
                    NativeIconButton(symbol: hidden ? "eye.slash" : "eye", label: hidden ? "Mostra importi" : "Nascondi importi") { hidden.toggle() }
                }
                Group {
                    if hidden { Text("•••• €") }
                    else if let remaining = presentation.remaining { Text(remaining.euro).modifier(NativeNumericFeedback(value: remaining)) }
                    else { Text("Da aggiornare") }
                }.font(NativeDesign.budgetValue(size: budgetAmountSize)).monospacedDigit()
                    .minimumScaleFactor(0.7).lineLimit(1).accessibilityIdentifier("finance-budget-value")
                if !hidden, presentation.remaining != nil {
                    if presentation.days > 0 {
                        Text(presentation.daily.euro + " al giorno").font(.subheadline.weight(.medium)).monospacedDigit()
                        Text(presentation.periodLabel).font(.caption).foregroundStyle(NativeDesign.secondary)
                    } else {
                        Text(presentation.periodLabel).font(.caption).foregroundStyle(NativeDesign.secondary)
                    }
                }
            }.accessibilityElement(children: .contain).accessibilityIdentifier("budget-hero")
            VStack(spacing: NativeDesign.Space.xs) {
                Text("Conto principale · " + store.summary.text("account", fallback: "Trade Republic")).font(.subheadline).foregroundStyle(NativeDesign.secondary)
                Text("Saldo attuale · " + (hidden ? "•••• €" : presentation.balance.map(\.euro) ?? "Da aggiornare"))
                    .font(.subheadline.weight(.medium)).monospacedDigit().fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("finance-current-balance")
                if store.financeMonth != CivilDate.month() {
                    Text("Saldo dell’ultima sincronizzazione, distinto dal mese selezionato.").font(.caption).foregroundStyle(NativeDesign.secondary)
                }
            }
        }.frame(maxWidth: .infinity).multilineTextAlignment(.center).padding(.vertical, NativeDesign.Space.large)
    }
    private var presentation: NativeFinanceOverview { NativeFinanceOverview(summary: store.summary, month: store.financeMonth) }
    private var actions: some View {
        HStack(alignment: .top, spacing: NativeDesign.Space.medium) {
            NavigationLink {
                List { detailedOverview }.modifier(NativeListAppearance()).navigationTitle("Budget").navigationBarTitleDisplayMode(.inline)
                    .task(id: store.financeGeneration) { await store.loadAnalysis() }
            } label: { actionLabel("Budget", symbol: "slider.horizontal.3") }.accessibilityIdentifier("finance-budget")
            Button { showingExtras = true } label: { actionLabel("Piani", symbol: "ellipsis") }.accessibilityIdentifier("finance-extra")
            Button { router.sheet = .movement([:]) } label: { actionLabel("Spesa", symbol: "minus") }.accessibilityIdentifier("finance-expense")
        }.buttonStyle(NativePressStyle()).foregroundStyle(NativeDesign.accent)
    }
    private func actionLabel(_ title: String, symbol: String) -> some View {
        VStack(spacing: NativeDesign.Space.small) {
            Image(systemName: symbol).font(.title2.weight(.regular))
                .frame(width: NativeDesign.Layout.primaryAction, height: NativeDesign.Layout.primaryAction)
                .background(NativeDesign.inset, in: Circle()).accessibilityHidden(true)
            Text(title).font(.subheadline).fixedSize(horizontal: false, vertical: true)
        }.frame(maxWidth: .infinity).contentShape(Rectangle())
    }
    private var recentMovements: some View {
        VStack(alignment: .leading, spacing: NativeDesign.Space.large) {
            NativeSectionHeader("Ultimi movimenti") {
                NavigationLink {
                    List { movements }.modifier(NativeListAppearance()).navigationTitle("Movimenti").navigationBarTitleDisplayMode(.inline)
                } label: { Text("Vedi tutti").font(.subheadline).frame(minHeight: NativeDesign.Layout.touchTarget) }
                    .accessibilityLabel("Mostra tutti i movimenti").accessibilityIdentifier("all-movements")
            }
            ForEach(store.transactions.prefix(3).map { DisplayRecord($0, key: "row") }) { item in
                Button { router.sheet = .movement(item.value) } label: {
                    ViewThatFits(in: .horizontal) {
                        HStack(spacing: NativeDesign.Space.medium) {
                            movementDescription(item.value)
                            Spacer(minLength: NativeDesign.Space.small)
                            movementAmount(item.value).fixedSize()
                        }
                        VStack(alignment: .leading, spacing: NativeDesign.Space.small) {
                            movementDescription(item.value)
                            movementAmount(item.value)
                        }
                    }.frame(maxWidth: .infinity, minHeight: NativeDesign.Layout.touchTarget, alignment: .leading)
                        .padding(.vertical, NativeDesign.Space.small).contentShape(Rectangle()).multilineTextAlignment(.leading)
                }.buttonStyle(NativePressStyle())
            }
            if store.transactions.isEmpty { Text("Nessun movimento nel mese").font(.subheadline).foregroundStyle(NativeDesign.secondary) }
        }
    }
    private func movementDescription(_ record: Record) -> some View {
        HStack(spacing: NativeDesign.Space.medium) {
            NativeIcon(name: NativeCategoryCatalog.symbol(for: record.text("displayCategory", fallback: record.text("category"))))
            NativeRowText(title: record.text("name"), subtitle: CivilDate.label(record.text("date")), titleLineLimit: 2)
        }
    }
    private func movementAmount(_ record: Record) -> some View {
        Text(hidden ? "••••" : record.amount("amount").euro).font(NativeDesign.body).monospacedDigit()
            .foregroundStyle(record.amount("amount") > 0 ? NativeDesign.financialGreen : Color.primary)
    }
    @ViewBuilder private var detailedOverview: some View {
        Section("Budget del mese") {
            if !hidden { NativeBudgetAllocation(summary: store.summary) }
            NavigationLink { BudgetDetail() } label: { NativeNavigationLabel(title: "Come si calcola il budget", symbol: "equal.circle") }
        }
        Section("Ricorrenti") {
            ForEach(store.finance.records("recurring").indices, id: \.self) { i in
                let record = store.finance.records("recurring")[i]
                Button { router.sheet = .recurring(record) } label: { HStack { Text(record.text("name")).foregroundStyle(Color.primary); Spacer(); MoneyText(amount: record.amount("estimate")).foregroundStyle(NativeDesign.secondary) } }
            }
        }
        Section("Obiettivo di risparmio") {
            let progress = NativeSavingsProgress(summary: store.summary, planning: store.finance.record("planning"))
            LabeledContent("Patrimonio totale", value: hidden ? "••••" : progress.assets.euro).accessibilityIdentifier("finance-total-assets")
            LabeledContent("Fondo emergenza", value: hidden ? "••••" : progress.emergency.euro)
            LabeledContent("Fondo emergenza coperto", value: hidden ? "••••" : progress.reserved.euro)
            LabeledContent("Altri risparmi", value: hidden ? "••••" : progress.other.euro)
            LabeledContent("Prossimo traguardo", value: hidden ? "••••" : progress.target.euro)
            LabeledContent("Manca", value: hidden ? "••••" : progress.missing.euro)
            LabeledContent("Da risparmiare al mese", value: hidden ? "••••" : progress.monthly.euro)
            Text("Cifra mancante divisa per \(progress.months) mesi fino a dicembre, incluso quello corrente.").font(.caption).foregroundStyle(NativeDesign.secondary)
            Button("Obiettivo e fondo emergenza") { router.sheet = .planning }
        }
    }
    @ViewBuilder private var movements: some View {
        Section {
            TextField("Cerca movimento", text: $search)
            Picker("Conto", selection: $account) { ForEach(["Tutti", "Trade Republic", "Revolut", "IsyBank"], id: \.self) { Text($0) } }
        }
        if !store.state.pending.isEmpty {
            Section("Salvati sul dispositivo") {
                ForEach(store.state.pending) { pending in
                    HStack { VStack(alignment: .leading) { Text(pending.payload.text("name")); Text(pending.accepted ? "Inviato · aggiornamento da completare" : "Da sincronizzare").font(.caption).foregroundStyle(NativeDesign.secondary) }; Spacer(); MoneyText(amount: pending.payload.amount("amount")) }
                }
            }
        }
        let rows = store.transactions.filter { (account == "Tutti" || $0.text("account") == account) && (search.isEmpty || ($0.text("name") + $0.text("category")).localizedCaseInsensitiveContains(search)) }
        Section("Movimenti del mese") {
            if rows.isEmpty { Text("Nessun movimento").foregroundStyle(NativeDesign.secondary) }
            ForEach(rows.map { DisplayRecord($0, key: "row") }) { item in
                Button { router.sheet = .movement(item.value) } label: {
                    HStack(alignment: .top, spacing: NativeDesign.Space.medium) {
                        NativeIcon(name: NativeCategoryCatalog.symbol(for: item.value.text("displayCategory", fallback: item.value.text("category"))), color: NativeDesign.accent)
                        NativeRowText(title: item.value.text("name"), subtitle: item.value.text("displayCategory", fallback: item.value.text("category")) + " · " + CivilDate.label(item.value.text("date")))
                        Spacer(); MoneyText(amount: item.value.amount("amount")).foregroundStyle(Color.primary)
                    }.padding(.vertical, NativeDesign.Space.xs)
                }
            }
        }
    }

}
struct IndexedRecord: Identifiable { let index: Int; let value: Record; var id: Int { index } }
struct BudgetDetail: View {
    @EnvironmentObject var store: NativeStore
    var body: some View {
        List {
            Section(CivilDate.monthTitle(store.financeMonth)) {
                LabeledContent("Stipendio di riferimento", value: store.summary.amount("monthlySalary").euro)
                ForEach(store.summary.records("monthlyBudgetBreakdown").enumerated().map { IndexedRecord(index: $0.offset, value: $0.element) }) { item in LabeledContent(item.value.text("name"), value: item.value.amount("amount").euro) }
                LabeledContent("Spese libere", value: store.summary.amount("monthlySpent").euro)
                LabeledContent("Residuo", value: store.summary.amount("monthlyRemaining").euro)
            }
            Section("Impegni sul saldo attuale") {
                ForEach(store.summary.records("recurringCommitments").enumerated().map { IndexedRecord(index: $0.offset, value: $0.element) }) { item in LabeledContent(item.value.text("name"), value: item.value.amount("remaining").euro) }
                LabeledContent("Totale impegnato", value: store.summary.amount("committedCurrent").euro)
            }
            Section("Budget giornaliero") {
                let daily = NativeValidation.dailyBudget(store.summary, month: store.financeMonth)
                if daily.days > 0 {
                    LabeledContent("Dopo gli accantonamenti", value: daily.low.euro)
                    LabeledContent("Prima degli accantonamenti", value: daily.high.euro)
                    Text("Calcolo su \(daily.days) giorni" + (store.financeMonth == CivilDate.month() ? ", incluso oggi." : " del mese selezionato.")).font(.caption).foregroundStyle(NativeDesign.secondary)
                } else { Text("Mese concluso: il riepilogo riguarda l’intero mese.").font(.caption).foregroundStyle(NativeDesign.secondary) }
            }
        }.modifier(NativeListAppearance()).navigationTitle("Budget").toolbar { DoneButton() }
    }
}

struct MovementEditor: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    let record: Record
    @State private var detail: Record = [:]
    @State private var name = ""
    @State private var amount = ""
    @State private var type = "Spesa"
    @State private var account = "Trade Republic"
    @State private var category = "Altro"
    @State private var date = Date()
    @State private var note = ""
    @State private var counterpart = "Trade Republic"
    @State private var months = 1
    @State private var treatment = "auto"
    @State private var recovery = ""
    @State private var recoveryAmount = ""
    @State private var included = false
    @State private var saving = false
    @State private var loaded = false
    @State private var error: String?
    @State private var confirmDelete = false
    @State private var requestID = UUID().uuidString
    private var editing: Bool { record.integer("row") > 0 }
    private var options: [String] {
        NativeCategoryCatalog.choices(type: type, current: category)
    }
    var body: some View {
        Form {
            Section {
                Picker("Tipo", selection: Binding(get: { type }, set: { value in
                    type = value
                    let choices = value == "Entrata" ? NativeCategoryCatalog.incomeChoices : Input.categories
                    if !choices.contains(category) { category = "Altro" }
                })) {
                    ForEach(editing ? ["Spesa", "Entrata", "Rimborso", "Trasferimento", "Investimento", "Da verificare"] : ["Spesa", "Entrata", "Rimborso", "Trasferimento"], id: \.self) { Text($0) }
                }
                TextField("Importo €", text: $amount).keyboardType(.decimalPad)
                TextField("Descrizione", text: $name)
                DatePicker("Data", selection: $date, in: ...Date(), displayedComponents: .date)
                if editing { Picker("Conto", selection: $account) { ForEach(["Trade Republic", "Revolut", "IsyBank"], id: \.self) { Text($0) } } }
                else { LabeledContent("Conto", value: type == "Trasferimento" ? "Revolut" : "Trade Republic") }
                if type == "Trasferimento" { Picker("Destinazione", selection: $counterpart) { ForEach(editing ? ["Trade Republic", "Revolut", "IsyBank"] : ["Trade Republic"], id: \.self) { Text($0) } } }
                else { Picker("Categoria", selection: $category) { ForEach(options, id: \.self) { Text($0) } } }
            }
            Section("Budget") {
                Stepper("Mesi coperti: \(months)", value: $months, in: 1...12)
                if type == "Spesa" {
                    if editing && !["auto", "savings"].contains(treatment) {
                        LabeledContent("Trattamento", value: "Gestito dal piano esistente")
                        Text("Il collegamento e il trattamento storico sono conservati. Gestisci il piano dalla sezione Piani.").font(.caption).foregroundStyle(NativeDesign.secondary)
                    } else {
                        Picker("Trattamento", selection: $treatment) { Text("Automatico").tag("auto"); Text("Da risparmi").tag("savings") }
                    }
                }
                if !editing && type != "Trasferimento" { Toggle("Già inclusa nel saldo rilevato", isOn: $included); Text("Usa questa opzione solo se la banca aveva già contabilizzato il movimento nella rilevazione. Il server verifica la data.").font(.caption).foregroundStyle(NativeDesign.secondary) }
            }
            Section("Note") { TextField("Note", text: $note, axis: .vertical) }
            if let error { NativeInlineMessage(text: error) }
            if editing { Section { Button("Elimina movimento", role: .destructive) { confirmDelete = true }.disabled(saving || store.busy || !loaded) } }
        }.modifier(NativeListAppearance()).navigationTitle(editing ? "Modifica movimento" : "Nuovo movimento").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() }.disabled(saving) }
            ToolbarItem(placement: .confirmationAction) { Button("Salva") { Task { await save() } }.disabled(saving || store.busy || !loaded || Input.cents(amount) == nil || name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
        }
        .confirmationDialog("Eliminare il movimento? Eventuali collegamenti finanziari saranno aggiornati dal server.", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Elimina", role: .destructive) { Task { do { try await store.perform("deleteMovement", args: [.int(record.integer("row"))]); dismiss() } catch { self.error = error.localizedDescription } } }
        }
        .task {
            if editing && !store.isDemo {
                do { let r = try await store.read("getMovement", args: [.int(record.integer("row"))]); populate(r.object); loaded = true }
                catch { self.error = error.localizedDescription }
            } else { populate(record); loaded = true }
        }
    }
    private func populate(_ r: Record) {
        detail = r; name = r.text("description", fallback: r.text("name")); amount = r.isEmpty ? "" : String(format: "%.2f", abs(r.amount("amount"))).replacingOccurrences(of: ".", with: ",")
        type = r.text("movement_type", fallback: r.text("type", fallback: "Spesa"))
        if r.text("notes").hasPrefix("Rimborso / restituzione:") { type = "Rimborso" }
        account = r.text("account", fallback: "Trade Republic"); category = r.text("category", fallback: "Altro")
        date = CivilDate.date(r.text("actual_date", fallback: r.text("date", fallback: CivilDate.day())))
        note = r.text("notes", fallback: r.text("note")); months = max(1, r.integer("competence_months") == 0 ? r.integer("months") : r.integer("competence_months"))
        treatment = r.text("budgetTreatment", fallback: "auto"); recovery = r.text("recoveryMonths"); recoveryAmount = String(r.amount("recoveryAmount")); counterpart = r.text("counterparty_account", fallback: r.text("counterpart", fallback: "Trade Republic"))
    }
    private func save() async {
        guard let cents = Input.cents(amount) else { return }
        saving = true; defer { saving = false }
        var payload: Record = ["requestId": .string(requestID), "row": .int(record.integer("row")), "name": .string(name), "amount": .number(Double(cents) / 100), "type": .string(type),
            "account": .string(editing ? account : type == "Trasferimento" ? "Revolut" : "Trade Republic"), "category": .string(category), "date": .string(CivilDate.day(date)), "months": .int(months), "note": .string(note),
            "counterpart": .string(counterpart), "includedInSnapshot": .bool(included), "budgetTreatment": .string(type == "Spesa" ? treatment : "auto")]
        if treatment == "recovery" && type == "Spesa" {
            payload["recoveryMonths"] = .string(recovery)
            if !recoveryAmount.isEmpty { guard let recoverCents = Input.cents(recoveryAmount) else { error = "Importo di recupero non valido."; return }; payload["recoveryAmount"] = .number(Double(recoverCents) / 100) }
        }
        do { try await store.perform(editing ? "editMovement" : "saveTransaction", payload); dismiss() }
        catch { self.error = error.localizedDescription }
    }
}
