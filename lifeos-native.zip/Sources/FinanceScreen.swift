import SwiftUI
import Charts

struct FinanceScreen: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    @State private var section = "Panoramica"
    @State private var search = ""
    @State private var account = "Tutti"
    @AppStorage("native-hide-money") private var hidden = false
    var body: some View {
        List {
            Section {
                Picker("Sezione", selection: $section) { ForEach(["Panoramica", "Extra"], id: \.self) { Text($0) } }.pickerStyle(.segmented)
                    .listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 4, trailing: 0)).listRowBackground(Color.clear).listRowSeparator(.hidden)
                MonthControl(finance: true).listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0)).listRowBackground(Color.clear).listRowSeparator(.hidden)
            }
            if section == "Panoramica" { overview }
            else { extras }
        }.modifier(NativeListAppearance()).accessibilityIdentifier("finance-scroll")
        .task(id: store.financeGeneration) { await store.loadAnalysis() }
        .onAppear { router.financeSection = section }
        .onChange(of: section) { _, value in router.financeSection = value }
    }
    @ViewBuilder private var overview: some View {
        Section {
            NativeBudgetHero().listRowInsets(EdgeInsets()).listRowBackground(Color.clear)
        }
        Section {
            HStack(spacing: 18) {
                NativeSavingsRing(progress: NativeSavingsProgress(summary: store.summary, planning: store.finance.record("planning")), hidden: hidden)
                VStack(alignment: .leading, spacing: 6) {
                    Text("Patrimonio totale").font(NativeDesign.heading)
                    Text("Il denaro che possiedi. Il fondo emergenza ne fa parte.").font(.caption).foregroundStyle(NativeDesign.secondary)
                    NavigationLink("Obiettivo e fondo emergenza") { PlanningEditor() }.font(.caption).frame(minHeight: 44)
                }
            }.padding(.vertical, 4)
        }
        Section { NativeForecastCard() }
        Section {
            Text("Ultimi movimenti").font(NativeDesign.heading)
            ForEach(store.transactions.prefix(3).map { DisplayRecord($0, key: "row") }) { item in
                Button { router.sheet = .movement(item.value) } label: {
                    HStack(spacing: 10) {
                        NativeIcon(name: NativeCategoryIcon.name(item.value.text("displayCategory", fallback: item.value.text("category"))))
                        VStack(alignment: .leading, spacing: 3) { Text(item.value.text("name")).font(.subheadline).lineLimit(2).foregroundStyle(Color.primary); Text(CivilDate.label(item.value.text("date"))).font(.caption2).foregroundStyle(NativeDesign.secondary) }
                        Spacer(); Text(hidden ? "••••" : item.value.amount("amount").euro).font(.subheadline).monospacedDigit().foregroundStyle(Color.primary)
                    }.frame(minHeight: 44).multilineTextAlignment(.leading)
                }.buttonStyle(NativePressStyle())
            }
            if store.transactions.isEmpty { Text("Nessun movimento nel mese").font(.caption).foregroundStyle(NativeDesign.secondary) }
            NavigationLink { List { movements }.modifier(NativeListAppearance()).navigationTitle("Movimenti").navigationBarTitleDisplayMode(.inline) } label: { NativeNavigationLabel(title: "Mostra tutti i movimenti", symbol: "list.bullet.rectangle") }.accessibilityIdentifier("all-movements")
        }
        if !store.state.pending.isEmpty {
            Section { Label("\(store.state.pending.count) movimenti salvati sul dispositivo", systemImage: "icloud.and.arrow.up").font(.subheadline); Text("In attesa di sincronizzazione. Il saldo mostra l’ultimo dato del server.").font(.caption).foregroundStyle(NativeDesign.secondary) }
        }
        Section {
            NavigationLink { List { detailedOverview }.modifier(NativeListAppearance()).navigationTitle("Dettagli finanza").navigationBarTitleDisplayMode(.inline) } label: { NativeNavigationLabel(title: "Budget e ricorrenti", symbol: "slider.horizontal.3").font(.subheadline) }
            NavigationLink { FinanceAnalysisScreen() } label: { NativeNavigationLabel(title: "Analisi e storico", symbol: "chart.xyaxis.line") }
            NativeConnectionBadge()
        }
    }
    @ViewBuilder private var detailedOverview: some View {
        Section("Budget del mese") {
            NavigationLink { BudgetDetail() } label: { NativeNavigationLabel(title: "Come si calcola il budget", symbol: "equal.circle") }
        }
        Section("Ricorrenti") {
            ForEach(store.finance.records("recurring").indices, id: \.self) { i in
                let record = store.finance.records("recurring")[i]
                Button { router.sheet = .recurring(record) } label: { HStack { Text(record.text("name")).foregroundStyle(Color.primary); Spacer(); MoneyText(amount: record.amount("estimate")).foregroundStyle(NativeDesign.secondary) } }
            }
        }
        Section("Obiettivo di risparmio") {
            let progress = NativeSavingsProgress(summary: store.summary, planning: store.finance.record("planning"))
            LabeledContent("Fondo emergenza", value: progress.emergency.euro)
            LabeledContent("Prossimo traguardo", value: progress.target.euro)
            LabeledContent("Manca", value: progress.missing.euro)
            LabeledContent("Da risparmiare al mese", value: progress.monthly.euro)
            Text("Cifra mancante divisa per \(progress.months) mesi fino a dicembre, incluso quello corrente.").font(.caption).foregroundStyle(NativeDesign.secondary)
            NavigationLink("Modifica obiettivo e fondo") { PlanningEditor() }
        }
    }
    @ViewBuilder private var movements: some View {
        Section {
            TextField("Cerca movimento", text: $search)
            Picker("Conto", selection: $account) { ForEach(["Tutti", "Trade Republic", "Revolut", "IsyBank"], id: \.self) { Text($0) } }
        }
        if !store.state.pending.isEmpty {
            Section("Salvati sul dispositivo") {
                ForEach(store.state.pending) { pending in
                    HStack { VStack(alignment: .leading) { Text(pending.payload.text("name")); Text(pending.accepted ? "Inviato · aggiornamento da completare" : "Da sincronizzare").font(.caption).foregroundStyle(NativeDesign.secondary) }; Spacer(); MoneyText(amount: pending.payload.amount("amount")) }
                }
            }
        }
        let rows = store.transactions.filter { (account == "Tutti" || $0.text("account") == account) && (search.isEmpty || ($0.text("name") + $0.text("category")).localizedCaseInsensitiveContains(search)) }
        Section("Movimenti del mese") {
            if rows.isEmpty { Text("Nessun movimento").foregroundStyle(NativeDesign.secondary) }
            ForEach(rows.map { DisplayRecord($0, key: "row") }) { item in
                Button { router.sheet = .movement(item.value) } label: {
                    HStack(alignment: .top, spacing: 12) {
                        NativeIcon(name: NativeCategoryIcon.name(item.value.text("displayCategory", fallback: item.value.text("category"))), color: NativeDesign.accent)
                        VStack(alignment: .leading, spacing: 5) { Text(item.value.text("name")).font(.body.weight(.medium)).foregroundStyle(Color.primary); Text(item.value.text("displayCategory", fallback: item.value.text("category")) + " · " + CivilDate.label(item.value.text("date"))).font(.caption).foregroundStyle(NativeDesign.secondary) }
                        Spacer(); MoneyText(amount: item.value.amount("amount")).foregroundStyle(Color.primary)
                    }.padding(.vertical, 3)
                }
            }
        }
    }
    @ViewBuilder private var extras: some View {
        let selected = store.allocations.filter { $0.text("month") == store.financeMonth }
        Section("Spese extra · " + CivilDate.monthTitle(store.financeMonth)) {
            if selected.isEmpty { Text("Nessun accantonamento in questo mese").foregroundStyle(NativeDesign.secondary) }
            ForEach(selected.map { DisplayRecord($0, key: "cycle_id") }) { item in
                Button { router.sheet = .extra(item.value) } label: {
                    HStack(alignment: .top) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(item.value.text("name")).foregroundStyle(Color.primary)
                            Text(NativeExtraState.title(item.value.text("status"))).font(.caption).foregroundStyle(NativeDesign.secondary)
                            Text("Totale previsto " + (item.value.amount("total_cents") / 100).euro).font(.caption2).foregroundStyle(NativeDesign.secondary)
                        }
                        Spacer()
                        VStack(alignment: .trailing, spacing: 4) {
                            MoneyText(amount: Double(NativeExtraState.displayedCents(item.value, plan: store.state.plan)) / 100).foregroundStyle(Color.primary)
                            Text(item.value.text("status") == "Pagato" ? "quota saldata" : "questo mese").font(.caption2).foregroundStyle(NativeDesign.secondary)
                        }
                    }
                }
            }
        }
        Section {
            Button { router.sheet = .extra([:]) } label: { Label("Pianifica una spesa extra", systemImage: "plus.circle") }.buttonStyle(NativePressStyle())
            Text("Pianifica il totale e i mesi di accantonamento. Quando paghi, apri la voce e registra l’importo effettivo: il pagamento usa i risparmi, senza addebitare di nuovo il budget del mese.").font(.caption).foregroundStyle(NativeDesign.secondary)
        }
    }
}
struct IndexedRecord: Identifiable { let index: Int; let value: Record; var id: Int { index } }
struct BudgetDetail: View {
    @EnvironmentObject var store: NativeStore
    var body: some View {
        List {
            Section(CivilDate.monthTitle(store.financeMonth)) {
                LabeledContent("Stipendio di riferimento", value: store.summary.amount("monthlySalary").euro)
                ForEach(store.summary.records("monthlyBudgetBreakdown").enumerated().map { IndexedRecord(index: $0.offset, value: $0.element) }) { item in LabeledContent(item.value.text("name"), value: item.value.amount("amount").euro) }
                LabeledContent("Spese libere", value: store.summary.amount("monthlySpent").euro)
                LabeledContent("Residuo", value: store.summary.amount("monthlyRemaining").euro)
            }
            Section("Impegni sul saldo attuale") {
                ForEach(store.summary.records("recurringCommitments").enumerated().map { IndexedRecord(index: $0.offset, value: $0.element) }) { item in LabeledContent(item.value.text("name"), value: item.value.amount("remaining").euro) }
                LabeledContent("Totale impegnato", value: store.summary.amount("committedCurrent").euro)
            }
            Section("Budget giornaliero") {
                let daily = NativeValidation.dailyBudget(store.summary, month: store.financeMonth)
                if daily.days > 0 {
                    LabeledContent("Dopo gli accantonamenti", value: daily.low.euro)
                    LabeledContent("Prima degli accantonamenti", value: daily.high.euro)
                    Text("Calcolo su \(daily.days) giorni" + (store.financeMonth == CivilDate.month() ? ", incluso oggi." : " del mese selezionato.")).font(.caption).foregroundStyle(NativeDesign.secondary)
                } else { Text("Mese concluso: il riepilogo riguarda l’intero mese.").font(.caption).foregroundStyle(NativeDesign.secondary) }
            }
        }.modifier(NativeListAppearance()).navigationTitle("Budget").toolbar { DoneButton() }
    }
}

struct MovementEditor: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    let record: Record
    @State private var detail: Record = [:]
    @State private var name = ""
    @State private var amount = ""
    @State private var type = "Spesa"
    @State private var account = "Trade Republic"
    @State private var category = "Altro"
    @State private var date = Date()
    @State private var note = ""
    @State private var counterpart = "Trade Republic"
    @State private var months = 1
    @State private var treatment = "auto"
    @State private var recovery = ""
    @State private var recoveryAmount = ""
    @State private var included = false
    @State private var saving = false
    @State private var loaded = false
    @State private var error: String?
    @State private var confirmDelete = false
    @State private var requestID = UUID().uuidString
    private var editing: Bool { record.integer("row") > 0 }
    private var options: [String] {
        var rows = type == "Entrata" ? ["Stipendio", "Interessi", "Rimborsi", "Altro"] : Input.categories
        if !rows.contains(category) { rows.append(category) }; return rows
    }
    var body: some View {
        Form {
            Section {
                Picker("Tipo", selection: $type) {
                    ForEach(editing ? ["Spesa", "Entrata", "Rimborso", "Trasferimento", "Investimento", "Da verificare"] : ["Spesa", "Entrata", "Rimborso", "Trasferimento"], id: \.self) { Text($0) }
                }
                TextField("Importo €", text: $amount).keyboardType(.decimalPad)
                TextField("Descrizione", text: $name)
                DatePicker("Data", selection: $date, in: ...Date(), displayedComponents: .date)
                if editing { Picker("Conto", selection: $account) { ForEach(["Trade Republic", "Revolut", "IsyBank"], id: \.self) { Text($0) } } }
                else { LabeledContent("Conto", value: type == "Trasferimento" ? "Revolut" : "Trade Republic") }
                if type == "Trasferimento" { Picker("Destinazione", selection: $counterpart) { ForEach(editing ? ["Trade Republic", "Revolut", "IsyBank"] : ["Trade Republic"], id: \.self) { Text($0) } } }
                else { Picker("Categoria", selection: $category) { ForEach(options, id: \.self) { Text($0) } } }
            }
            Section("Budget") {
                Stepper("Mesi coperti: \(months)", value: $months, in: 1...12)
                if type == "Spesa" {
                    Picker("Trattamento", selection: $treatment) {
                        Text("Automatico").tag("auto"); Text("Ordinaria").tag("ordinary"); Text("Già pianificata").tag("planned"); Text("Da risparmi").tag("savings"); Text("Recupero nei mesi scelti").tag("recovery")
                    }
                    if treatment == "recovery" { TextField("Mesi AAAA-MM, separati da virgole", text: $recovery).textInputAutocapitalization(.never); TextField("Importo da recuperare €", text: $recoveryAmount).keyboardType(.decimalPad) }
                }
                if !editing && type != "Trasferimento" { Toggle("Già inclusa nel saldo rilevato", isOn: $included); Text("Usa questa opzione solo se la banca aveva già contabilizzato il movimento nella rilevazione. Il server verifica la data.").font(.caption).foregroundStyle(NativeDesign.secondary) }
            }
            Section("Note") { TextField("Note", text: $note, axis: .vertical) }
            if let error { Text(error).foregroundStyle(.red) }
            if editing { Section { Button("Elimina movimento", role: .destructive) { confirmDelete = true }.disabled(saving || store.busy || !loaded) } }
        }.modifier(NativeListAppearance()).navigationTitle(editing ? "Modifica movimento" : "Nuovo movimento").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() }.disabled(saving) }
            ToolbarItem(placement: .confirmationAction) { Button("Salva") { Task { await save() } }.disabled(saving || store.busy || !loaded || Input.cents(amount) == nil || name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
        }
        .confirmationDialog("Eliminare il movimento? Eventuali collegamenti finanziari saranno aggiornati dal server.", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Elimina", role: .destructive) { Task { do { try await store.perform("deleteMovement", args: [.int(record.integer("row"))]); dismiss() } catch { self.error = error.localizedDescription } } }
        }
        .task {
            if editing && !store.isDemo {
                do { let r = try await store.read("getMovement", args: [.int(record.integer("row"))]); populate(r.object); loaded = true }
                catch { self.error = error.localizedDescription }
            } else { populate(record); loaded = true }
        }
    }
    private func populate(_ r: Record) {
        detail = r; name = r.text("description", fallback: r.text("name")); amount = r.isEmpty ? "" : String(format: "%.2f", abs(r.amount("amount"))).replacingOccurrences(of: ".", with: ",")
        type = r.text("movement_type", fallback: r.text("type", fallback: "Spesa"))
        if r.text("notes").hasPrefix("Rimborso / restituzione:") { type = "Rimborso" }
        account = r.text("account", fallback: "Trade Republic"); category = r.text("category", fallback: "Altro")
        date = CivilDate.date(r.text("actual_date", fallback: r.text("date", fallback: CivilDate.day())))
        note = r.text("notes", fallback: r.text("note")); months = max(1, r.integer("competence_months") == 0 ? r.integer("months") : r.integer("competence_months"))
        treatment = r.text("budgetTreatment", fallback: "auto"); recovery = r.text("recoveryMonths"); recoveryAmount = String(r.amount("recoveryAmount")); counterpart = r.text("counterparty_account", fallback: r.text("counterpart", fallback: "Trade Republic"))
    }
    private func save() async {
        guard let cents = Input.cents(amount) else { return }
        saving = true; defer { saving = false }
        var payload: Record = ["requestId": .string(requestID), "row": .int(record.integer("row")), "name": .string(name), "amount": .number(Double(cents) / 100), "type": .string(type),
            "account": .string(editing ? account : type == "Trasferimento" ? "Revolut" : "Trade Republic"), "category": .string(category), "date": .string(CivilDate.day(date)), "months": .int(months), "note": .string(note),
            "counterpart": .string(counterpart), "includedInSnapshot": .bool(included), "budgetTreatment": .string(type == "Spesa" ? treatment : "auto")]
        if treatment == "recovery" && type == "Spesa" {
            payload["recoveryMonths"] = .string(recovery)
            if !recoveryAmount.isEmpty { guard let recoverCents = Input.cents(recoveryAmount) else { error = "Importo di recupero non valido."; return }; payload["recoveryAmount"] = .number(Double(recoverCents) / 100) }
        }
        do { try await store.perform(editing ? "editMovement" : "saveTransaction", payload); dismiss() }
        catch { self.error = error.localizedDescription }
    }
}
