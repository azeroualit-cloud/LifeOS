import Foundation

/// Explicit offline demo adapter. Production calculations are validated by the server.
enum NativePlanDemo {
    static func apply(_ method: String, payload: Record, state: inout NativeArchive, today: String = CivilDate.day()) throws {
        var next = state, data = next.finance.record("plansV2")
        var plans = data.records("plans"), payments = data.records("payments"), commands = data.record("commands")
        let id = payload.text("requestId")
        guard !id.isEmpty else { throw Message(text: "Identificatore operazione mancante.") }
        let encoder = JSONEncoder(); encoder.outputFormatting = .sortedKeys
        let fingerprint = String(data: try encoder.encode(payload), encoding: .utf8)!
        if let old = commands[id] {
            guard old.string == method + fingerprint else { throw Message(text: "Operazione già usata con dati diversi.") }; return
        }
        if method == "saveFinancePlan" {
            guard let kind = NativePlanKind(rawValue: payload.text("kind")) else { throw Message(text: "Tipo di piano non valido.") }
            var draft = NativePlanDraft(); draft.kind = kind; draft.name = payload.text("name"); draft.category = payload.text("category", fallback: "Altro"); draft.amount = String(format: "%.2f", Double(payload.integer("amountCents")) / 100)
            draft.startMonth = payload.text("startMonth"); draft.endMonth = payload.text("endMonth"); draft.beneficiaryMonth = payload.text("beneficiaryMonth"); draft.paymentDate = payload.text("paymentDate"); draft.intervalMonths = max(1, payload.integer("intervalMonths"))
            var plan = try draft.payload(requestID: id, today: today)
            plan["id"] = .string(id); plan["status"] = .string("active"); plan["rateChanges"] = .array([])
            if kind == .recovery {
                let row = try recordCash(name: draft.name, category: draft.category, cents: payload.integer("amountCents"), day: draft.paymentDate, requestID: id, state: &next)
                payments.append(["id": .string(id), "planId": .string(id), "date": .string(draft.paymentDate), "amountCents": payload["amountCents"]!, "status": .string("posted"), "movementId": .int(row), "settlementKey": .string("once")])
            }
            plans.append(plan)
        } else {
            guard let index = plans.firstIndex(where: { $0.text("id") == payload.text("planId") }) else { throw Message(text: "Piano non trovato.") }
            var plan = plans[index]
            guard plan.text("status") == "active" else { throw Message(text: "Il piano non è attivo.") }
            if method == "stopFinancePlan" {
                if plan.text("kind") == "advance" {
                    guard plan.text("beneficiaryMonth") >= String(today.prefix(7)) else { throw Message(text: "Non puoi cancellare il recupero di un anticipo già usato in un mese chiuso.") }
                    plan["status"] = .string("cancelled")
                } else { plan["status"] = .string("stopped"); plan["stopAfter"] = .string(String(today.prefix(7))) }
            } else if method == "recordFinancePlanPayment" {
                guard let kind = NativePlanKind(rawValue: plan.text("kind")), kind.payable else { throw Message(text: "Questo piano non prevede un nuovo pagamento.") }
                let amount = payload.integer("amountCents"), day = payload.text("date"), cycle = payload.text("cycleMonth", fallback: String(day.prefix(7)))
                guard amount > 0, amount <= 100_000_000, day <= today, CivilDate.day(CivilDate.date(day)) == day else { throw Message(text: "Importo o data non validi.") }
                let settlement = kind == .goal ? "once" : [.fixed, .estimated].contains(kind) ? cycle : id
                guard !payments.contains(where: { $0.text("planId") == plan.text("id") && $0.text("settlementKey") == settlement }) else { throw Message(text: "Pagamento già registrato.") }
                if [.fixed, .estimated].contains(kind) {
                    guard NativePlanRules.validMonth(cycle), cycle <= String(today.prefix(7)), cycle >= plan.text("startMonth") else { throw Message(text: "Scadenza non valida.") }
                }
                let covered = payload.integer("competenceMonths") == 0 ? 1 : payload.integer("competenceMonths")
                guard (1...12).contains(covered) else { throw Message(text: "Mesi coperti non validi.") }
                if payload.flag("recoverDifference") {
                    guard kind == .goal, amount > plan.integer("amountCents") else { throw Message(text: "Nessuna eccedenza da recuperare.") }
                    var draft = NativePlanDraft(); draft.kind = .goal; draft.name = "Recupero eccedenza · " + plan.text("name"); draft.amount = String(format: "%.2f", Double(amount - plan.integer("amountCents")) / 100)
                    draft.startMonth = payload.text("recoveryStartMonth"); draft.endMonth = payload.text("recoveryEndMonth")
                    var recovery = try draft.payload(requestID: id + "-difference", today: today)
                    recovery["id"] = .string(id + "-difference"); recovery["kind"] = .string("recovery"); recovery["status"] = .string("active")
                    plans.append(recovery)
                }
                let row = try recordCash(name: plan.text("name"), category: plan.text("category", fallback: "Altro"), cents: amount, day: day, requestID: id, state: &next)
                payments.append(["id": .string(id), "planId": plan["id"]!, "date": .string(day), "amountCents": .int(amount), "status": .string("posted"), "movementId": .int(row), "settlementKey": .string(settlement), "competenceMonths": .int(covered)])
                if kind == .goal { plan["status"] = .string("closed"); plan["closedMonth"] = .string(String(today.prefix(7))) }
                if kind == .estimated {
                    let history = payments.filter { $0.text("planId") == plan.text("id") }.sorted { $0.text("date") < $1.text("date") }.suffix(12)
                    let total = history.reduce(0) { $0 + $1.integer("amountCents") }, months = history.reduce(0) { $0 + max(1, $1.integer("competenceMonths")) }
                    let from = NativePlanRules.adding(1, to: String(today.prefix(7)))
                    var changes = plan.records("rateChanges").filter { $0.text("fromMonth") != from }
                    changes.append(["fromMonth": .string(from), "amountCents": .int(max(1, Int((Double(total) / Double(months)).rounded())))])
                    plan["rateChanges"] = .array(changes.map(JSONValue.object))
                }
            } else { throw Message(text: "Operazione non disponibile nella demo.") }
            plans[index] = plan
        }
        commands[id] = .string(method + fingerprint)
        data["plans"] = .array(plans.map(JSONValue.object)); data["payments"] = .array(payments.map(JSONValue.object)); data["commands"] = .object(commands)
        next.finance["plansV2"] = .object(data); project(month: next.financeMonth, state: &next, today: today); state = next
    }
    private static func recordCash(name: String, category: String, cents: Int, day: String, requestID: String, state: inout NativeArchive) throws -> Int {
        try DemoActions.apply("saveTransaction", ["requestId": .string(requestID), "name": .string(name), "amount": .number(Double(cents) / 100), "date": .string(day), "account": .string("Trade Republic"), "category": .string(category), "type": .string("Spesa"), "budgetTreatment": .string("savings")], args: nil, state: &state)
        return state.finance.records("transactions").last!.integer("row")
    }
    static func project(month: String, state: inout NativeArchive, today: String = CivilDate.day()) {
        var data = state.finance.record("plansV2"), plans = data.records("plans")
        let payments = data.records("payments"), current = String(today.prefix(7))
        func fund(_ plan: Record, through end: String) -> (Int, Int, Int) {
            let start = plan.text("startMonth")
            guard NativePlanRules.validMonth(start), start <= end else { return (0, 0, 0) }
            // Continuous funds do not inherit the finite-goal month-count limit.
            var cursor = start, saved = 0
            while cursor <= end { saved += max(0, NativePlanRules.contribution(plan, month: cursor)); cursor = NativePlanRules.adding(1, to: cursor) }
            let spent = payments.filter { $0.text("planId") == plan.text("id") && String($0.text("date").prefix(7)) <= end }.reduce(0) { $0 + $1.integer("amountCents") }
            let earmarked = plan.text("status") == "active" && !["advance", "recovery"].contains(plan.text("kind")) ? max(0, saved - spent) : 0
            return (earmarked, saved, spent)
        }
        let adjustment = -plans.reduce(0) { $0 + NativePlanRules.contribution($1, month: month) }
        let currentEarmarked = plans.reduce(0) { $0 + fund($1, through: current).0 }
        var summary = state.finance.record("summary")
        let previous = data.integer("demoAppliedAdjustmentCents"), previousReserved = data.integer("demoAppliedReservedCents")
        summary["monthlyRemaining"] = .number(summary.amount("monthlyRemaining") + Double(adjustment - previous) / 100)
        summary["monthlyCommitted"] = .number(summary.amount("monthlyCommitted") - Double(adjustment - previous) / 100)
        summary["committedCurrent"] = .number(summary.amount("committedCurrent") + Double(currentEarmarked - previousReserved) / 100)
        summary["remainingFree"] = .number(summary.amount("budget") - summary.amount("committedCurrent"))
        for index in plans.indices {
            let values = fund(plans[index], through: month)
            plans[index]["contributionCents"] = .int(NativePlanRules.contribution(plans[index], month: month))
            plans[index]["fundCents"] = .int(values.0); plans[index]["contributedCents"] = .int(values.1); plans[index]["paidCents"] = .int(values.2)
            plans[index]["fromGeneralSavingsCents"] = .int(max(0, values.2 - values.1))
        }
        data["version"] = .int(2); data["month"] = .string(month); data["adjustmentCents"] = .int(adjustment); data["plans"] = .array(plans.map(JSONValue.object)); data["payments"] = .array(payments.map(JSONValue.object))
        data["demoAppliedAdjustmentCents"] = .int(adjustment); data["demoAppliedReservedCents"] = .int(currentEarmarked)
        state.finance["summary"] = .object(summary); state.finance["plansV2"] = .object(data)
    }
}
