import SwiftUI

/// Separate glass surfaces, coordinated by the system, keep four destinations and add visible.
struct NativeBottomNavigation: View {
    @EnvironmentObject var router: NativeRouter
    @Environment(\.dynamicTypeSize) private var typeSize
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let addLabel: String
    let add: () -> Void
    private let destinations: [(NativeTab, String, String, String)] = [
        (.dashboard, "Dashboard", "square.grid.2x2", "dashboard"),
        (.tasks, "Attività", "checklist", "tasks"),
        (.calendar, "Calendario", "calendar", "calendar"),
        (.finance, "Finanza", "chart.bar", "finance")
    ]
    private var selection: Int { destinations.firstIndex { $0.0 == router.tab } ?? 0 }
    var body: some View {
        coordinatedGlass
            .padding(.horizontal, NativeDesign.Layout.navigationInset)
            .padding(.top, NativeDesign.Space.small).padding(.bottom, NativeDesign.Space.small)
    }
    @ViewBuilder private var coordinatedGlass: some View {
        if #available(iOS 26.0, *) {
            GlassEffectContainer(spacing: NativeDesign.Space.medium) { controls }
        } else { controls }
    }
    private var controls: some View {
        HStack(spacing: NativeDesign.Space.medium) {
            ZStack(alignment: .leading) {
                // Only this lightweight indicator animates. Never animate TabView routing
                // or the incoming page's layout/data loading with the bar's transaction.
                GeometryReader { geometry in
                    let width = geometry.size.width / CGFloat(destinations.count)
                    Capsule().fill(NativeDesign.accent.opacity(NativeDesign.Motion.navigationSelectionOpacity))
                        .frame(width: width, height: NativeDesign.Layout.tabHeight)
                        .offset(x: CGFloat(selection) * width)
                        .animation(reduceMotion ? nil : .spring(response: NativeDesign.Motion.navigationResponse, dampingFraction: NativeDesign.Motion.navigationDamping), value: selection)
                        .accessibilityHidden(true)
                }.allowsHitTesting(false)
                HStack(spacing: NativeDesign.Space.none) {
                    ForEach(destinations, id: \.0) { destination in
                        let selected = router.tab == destination.0
                        Button {
                            guard router.tab != destination.0 else { return }
                            router.tab = destination.0
                        } label: {
                            VStack(spacing: NativeDesign.Space.xs) {
                                Image(systemName: destination.2).font(.title3.weight(.regular))
                                if !typeSize.isAccessibilitySize {
                                    Text(destination.1).font(.caption2.weight(selected ? .semibold : .regular))
                                        .lineLimit(1).minimumScaleFactor(0.75)
                                }
                            }.frame(maxWidth: .infinity).frame(height: NativeDesign.Layout.tabHeight)
                                .foregroundStyle(selected ? NativeDesign.accent : NativeDesign.secondary)
                                .contentShape(Capsule())
                        }.buttonStyle(NativeNavigationPressStyle())
                            .accessibilityLabel(destination.1).accessibilityIdentifier("tab-" + destination.3)
                            .accessibilityAddTraits(selected ? .isSelected : [])
                    }
                }
            }.frame(height: NativeDesign.Layout.tabHeight)
                .padding(NativeDesign.Space.xs).modifier(NativeGlass(interactive: false))
            Button(action: add) {
                Image(systemName: "plus").font(.title.weight(.regular))
                    .frame(width: NativeDesign.Layout.primaryAction, height: NativeDesign.Layout.primaryAction).contentShape(Circle())
            }.buttonStyle(NativeNavigationPressStyle()).foregroundStyle(NativeDesign.accent)
                .modifier(NativeGlass()).accessibilityLabel(addLabel).accessibilityIdentifier("primary-add")
        }
    }
}

private struct NativeNavigationPressStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed && !reduceMotion ? NativeDesign.Motion.navigationPressScale : 1)
            .opacity(configuration.isPressed ? NativeDesign.Motion.pressedOpacity : 1)
            .animation(reduceMotion ? nil : .spring(response: NativeDesign.Motion.navigationPressResponse, dampingFraction: NativeDesign.Motion.navigationDamping), value: configuration.isPressed)
    }
}
