import SwiftUI

/// Keep native tab geometry and Liquid Glass interaction under system control.
struct NativeTabBarAppearance: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) { content.tabBarMinimizeBehavior(.never) }
        else { content }
    }
}

/// Host the shared 44pt button as custom toolbar content. A bare automatic
/// Button becomes a UIKit bar item that can shrink to 36pt on iOS 26.
struct NativeToolbarButton: View {
    let symbol: String
    let label: String
    let action: () -> Void

    var body: some View {
        HStack(spacing: NativeDesign.Space.none) {
            NativeIconButton(symbol: symbol, label: label, action: action)
        }.fixedSize()
    }
}
