import SwiftUI

/// A separate primary action leaves all four destinations visible, including on compact phones.
struct NativeBottomNavigation: View {
    @EnvironmentObject var router: NativeRouter
    @Environment(\.dynamicTypeSize) private var typeSize
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let addLabel: String
    let add: () -> Void
    private let destinations: [(NativeTab, String, String, String)] = [
        (.dashboard, "Dashboard", "square.grid.2x2", "dashboard"),
        (.tasks, "Attività", "checklist", "tasks"),
        (.calendar, "Calendario", "calendar", "calendar"),
        (.finance, "Finanza", "chart.bar", "finance")
    ]
    var body: some View {
        HStack(spacing: NativeDesign.Space.medium) {
            HStack(spacing: NativeDesign.Space.none) {
                ForEach(destinations, id: \.0) { destination in
                    let selected = router.tab == destination.0
                    Button { router.tab = destination.0 } label: {
                        VStack(spacing: NativeDesign.Space.xs) {
                            Image(systemName: destination.2).font(.title3.weight(.regular))
                            if !typeSize.isAccessibilitySize {
                                Text(destination.1).font(.caption2.weight(selected ? .semibold : .regular))
                                    .lineLimit(1).minimumScaleFactor(0.75)
                            }
                        }.frame(maxWidth: .infinity).frame(height: NativeDesign.Layout.tabHeight)
                            .foregroundStyle(selected ? NativeDesign.accent : NativeDesign.secondary)
                            .background(selected ? NativeDesign.accent.opacity(0.14) : Color.clear, in: Capsule())
                            .contentShape(Capsule())
                    }.buttonStyle(.plain)
                        .accessibilityLabel(destination.1).accessibilityIdentifier("tab-" + destination.3)
                        .accessibilityAddTraits(selected ? .isSelected : [])
                }
            }.padding(NativeDesign.Space.xs).modifier(NativeGlass())
            Button(action: add) {
                Image(systemName: "plus").font(.title.weight(.regular)).frame(width: NativeDesign.Layout.primaryAction, height: NativeDesign.Layout.primaryAction)
                    .contentShape(Circle())
            }.buttonStyle(NativePressStyle()).foregroundStyle(NativeDesign.accent)
                .modifier(NativeGlass()).accessibilityLabel(addLabel).accessibilityIdentifier("primary-add")
        }.padding(.horizontal, NativeDesign.Layout.navigationInset).padding(.top, NativeDesign.Space.small).padding(.bottom, NativeDesign.Space.small)
            .animation(reduceMotion ? nil : .easeOut(duration: NativeDesign.Motion.selectionDuration), value: router.tab)
    }
}
