import Foundation
import HealthKit
import Combine

@MainActor final class NativeHealthStore: ObservableObject {
    @Published private(set) var days: [HealthDay] = []
    @Published private(set) var loading = false
    @Published private(set) var message: String?
    @Published private(set) var sources: [String] = []
    @Published private(set) var sourceNames: [String: String] = [:]
    @Published var selectedSource = ""
    private let health = HKHealthStore()
    private var didStart = false
    private var demo = false
    private var food: [HKQuantitySample] = []
    private var weights: [HKQuantitySample] = []
    private let calendar = Calendar.current
    var estimate: HealthEstimate? { NativeHealthMath.estimate(days) }
    var available: Bool { HKHealthStore.isHealthDataAvailable() }

    func start(demo: Bool) async {
        guard !didStart else { return }
        didStart = true; self.demo = demo
        if demo {
            #if DEBUG
            if !ProcessInfo.processInfo.arguments.contains("--empty-home") { days = NativeHealthMath.demo() }
            #endif
            return
        }
        // Prompt only from an explicit user action. Read previously permitted data on entry.
        await refresh()
    }
    func connect() async {
        guard !demo, !loading else { return }
        guard available else { message = "Salute non è disponibile su questo dispositivo."; return }
        loading = true; message = nil
        do {
            let types: Set<HKObjectType> = [HKObjectType.quantityType(forIdentifier: .bodyMass)!, HKObjectType.quantityType(forIdentifier: .dietaryEnergyConsumed)!]
            try await health.requestAuthorization(toShare: [], read: types)
            loading = false
            await refresh()
        } catch {
            days = []; food = []; weights = []; sources = []; sourceNames = [:]
            loading = false; message = "Accesso a Salute non completato. Verifica i permessi in Impostazioni > Salute."
        }
    }
    func refresh() async {
        guard !demo, !loading, available else { return }
        loading = true; message = nil
        defer { loading = false }
        do {
            let today = calendar.startOfDay(for: Date())
            let start = calendar.date(byAdding: .day, value: -56, to: today)!
            let end = Date()
            let newWeights = try await samples(.bodyMass, start: start, end: end)
            let newFood = try await samples(.dietaryEnergyConsumed, start: start, end: end)
            weights = newWeights; food = newFood
            sources = Array(Set(food.map { $0.sourceRevision.source.bundleIdentifier })).sorted()
            sourceNames = Dictionary(food.map { ($0.sourceRevision.source.bundleIdentifier, $0.sourceRevision.source.name) }, uniquingKeysWith: { first, _ in first })
            if !sources.contains(selectedSource) {
                // A single nutrition source avoids counting the same meals from multiple apps.
                selectedSource = sources.max { a, b in
                    Set(food.filter { $0.sourceRevision.source.bundleIdentifier == a }.map { calendar.startOfDay(for: $0.startDate) }).count <
                    Set(food.filter { $0.sourceRevision.source.bundleIdentifier == b }.map { calendar.startOfDay(for: $0.startDate) }).count
                } ?? ""
            }
            rebuild()
        } catch {
            // Clear old samples rather than continuing to expose stale or revoked data.
            days = []; food = []; weights = []; sources = []; sourceNames = [:]
            message = "Lettura Salute non riuscita. Sblocca iPhone e riprova; verifica anche la firma HealthKit dell’app."
        }
    }
    func rebuild() {
        guard !demo else { return }
        var result: [Date: HealthDay] = [:]
        for sample in weights.sorted(by: { $0.startDate < $1.startDate }) {
            let value = sample.quantity.doubleValue(for: .gramUnit(with: .kilo))
            guard value.isFinite, value > 0 else { continue }
            let day = calendar.startOfDay(for: sample.startDate)
            var item = result[day] ?? HealthDay(date: day)
            item.weight = value // latest sample for a day
            result[day] = item
        }
        for sample in food where sample.sourceRevision.source.bundleIdentifier == selectedSource {
            let value = sample.quantity.doubleValue(for: .kilocalorie())
            guard value.isFinite, value > 0 else { continue }
            let day = calendar.startOfDay(for: sample.startDate)
            var item = result[day] ?? HealthDay(date: day)
            item.calories = (item.calories ?? 0) + value
            result[day] = item
        }
        days = result.values.sorted { $0.date < $1.date }
        if days.isEmpty {
            message = "Nessun dato leggibile. Potrebbero mancare le registrazioni o i permessi: iOS non distingue questi casi."
        }
    }
    private func samples(_ identifier: HKQuantityTypeIdentifier, start: Date, end: Date) async throws -> [HKQuantitySample] {
        let type = HKObjectType.quantityType(forIdentifier: identifier)!
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        return try await withCheckedThrowingContinuation { continuation in
            let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: HKObjectQueryNoLimit,
                                      sortDescriptors: [NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)]) { _, samples, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: samples as? [HKQuantitySample] ?? []) }
            }
            health.execute(query)
        }
    }
}
