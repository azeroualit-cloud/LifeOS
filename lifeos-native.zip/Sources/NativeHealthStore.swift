import Foundation
import HealthKit
import Combine

@MainActor final class NativeHealthStore: ObservableObject {
    @Published private(set) var days: [HealthDay] = []
    @Published private(set) var loading = false
    @Published private(set) var message: String?
    @Published private(set) var sources: [String] = []
    @Published private(set) var sourceNames: [String: String] = [:]
    @Published var selectedSource = ""
    private let health = HKHealthStore()
    private var didStart = false
    private var demo = false
    private var food: [HKQuantitySample] = []
    private var weights: [HKQuantitySample] = []
    private let calendar = Calendar.current
    var estimate: HealthEstimate? { NativeHealthMath.estimate(days) }
    var available: Bool { HKHealthStore.isHealthDataAvailable() }

    func start(demo: Bool) async {
        guard !didStart else { return }
        didStart = true; self.demo = demo
        if demo {
            #if DEBUG
            if !ProcessInfo.processInfo.arguments.contains("--empty-home") { days = NativeHealthMath.demo() }
            #endif
            return
        }
        guard available else { message = "Salute non è disponibile su questo dispositivo."; return }
        do {
            let types: Set<HKObjectType> = [HKObjectType.quantityType(forIdentifier: .bodyMass)!, HKObjectType.quantityType(forIdentifier: .dietaryEnergyConsumed)!]
            let status = try await health.statusForAuthorizationRequest(toShare: [], read: types)
            if status == .shouldRequest { await connect() }
            else { await refresh() }
        } catch {
            message = "Salute non è accessibile. Verifica che la firma dell’app includa HealthKit. Puoi riprovare dal pulsante qui sotto."
        }
    }
    func connect() async {
        guard !demo, !loading else { return }
        guard available else { message = "Salute non è disponibile su questo dispositivo."; return }
        loading = true; message = nil
        do {
            let types: Set<HKObjectType> = [HKObjectType.quantityType(forIdentifier: .bodyMass)!, HKObjectType.quantityType(forIdentifier: .dietaryEnergyConsumed)!]
            try await health.requestAuthorization(toShare: [], read: types)
            loading = false
            await refresh()
        } catch {
            days = []; food = []; weights = []; sources = []; sourceNames = [:]
            loading = false; message = "Accesso a Salute non completato. Verifica i permessi in Impostazioni > Salute."
        }
    }
    func refresh() async {
        guard !demo, !loading, available else { return }
        loading = true; message = nil
        defer { loading = false }
        do {
            let today = calendar.startOfDay(for: Date())
            let start = calendar.date(byAdding: .month, value: -6, to: today)!
            let end = Date()
            let newWeights = try await samples(.bodyMass, start: start, end: end)
            let newFood = try await samples(.dietaryEnergyConsumed, start: start, end: end)
            weights = newWeights; food = newFood
            sources = Array(Set(food.map { $0.sourceRevision.source.bundleIdentifier })).sorted()
            sourceNames = Dictionary(food.map { ($0.sourceRevision.source.bundleIdentifier, $0.sourceRevision.source.name) }, uniquingKeysWith: { first, _ in first })
            if !sources.contains(selectedSource) {
                // A single nutrition source avoids counting the same meals from multiple apps.
                selectedSource = sources.max { a, b in
                    Set(food.filter { $0.sourceRevision.source.bundleIdentifier == a }.map { calendar.startOfDay(for: $0.startDate) }).count <
                    Set(food.filter { $0.sourceRevision.source.bundleIdentifier == b }.map { calendar.startOfDay(for: $0.startDate) }).count
                } ?? ""
            }
            rebuild()
        } catch {
            // Clear old samples rather than continuing to expose stale or revoked data.
            days = []; food = []; weights = []; sources = []; sourceNames = [:]
            message = "Lettura Salute non riuscita. Sblocca iPhone e riprova; verifica anche la firma HealthKit dell’app."
        }
    }
    enum WeightSaveError: LocalizedError {
        case invalid, unavailable, denied, busy
        var errorDescription: String? {
            switch self {
            case .invalid: return "Inserisci un peso valido in kg e una data non futura."
            case .unavailable: return "Apple Health non è disponibile su questo dispositivo."
            case .denied: return "Consenti a Life OS di scrivere il peso in Impostazioni > Salute, poi riprova."
            case .busy: return "Attendi il completamento della lettura di Salute e riprova."
            }
        }
    }
    func saveWeight(_ kilograms: Double, at date: Date) async throws {
        guard kilograms.isFinite, kilograms > 0, kilograms <= 500, date <= Date() else { throw WeightSaveError.invalid }
        guard !loading else { throw WeightSaveError.busy }
        if demo {
            #if DEBUG
            let day = calendar.startOfDay(for: date)
            // Match HealthKit's latest-measurement-per-day presentation in the test fixture.
            if let index = days.firstIndex(where: { $0.date == day }) { days[index].weight = kilograms }
            else { days.append(HealthDay(date: day, weight: kilograms)); days.sort { $0.date < $1.date } }
            return
            #else
            throw WeightSaveError.unavailable
            #endif
        }
        guard available else { throw WeightSaveError.unavailable }
        loading = true
        defer { loading = false }
        let type = HKObjectType.quantityType(forIdentifier: .bodyMass)!
        let readTypes: Set<HKObjectType> = [type, HKObjectType.quantityType(forIdentifier: .dietaryEnergyConsumed)!]
        try await health.requestAuthorization(toShare: [type], read: readTypes)
        guard health.authorizationStatus(for: type) == .sharingAuthorized else { throw WeightSaveError.denied }
        let sample = HKQuantitySample(type: type, quantity: HKQuantity(unit: .gramUnit(with: .kilo), doubleValue: kilograms), start: date, end: date)
        try await health.save(sample)
        weights.append(sample)
        message = nil
        rebuild()
    }

    func rebuild() {
        guard !demo else { return }
        var result: [Date: HealthDay] = [:]
        for sample in weights.sorted(by: { $0.startDate < $1.startDate }) {
            let value = sample.quantity.doubleValue(for: .gramUnit(with: .kilo))
            guard value.isFinite, value > 0 else { continue }
            let day = calendar.startOfDay(for: sample.startDate)
            var item = result[day] ?? HealthDay(date: day)
            item.weight = value // latest sample for a day
            result[day] = item
        }
        for sample in food where sample.sourceRevision.source.bundleIdentifier == selectedSource {
            let value = sample.quantity.doubleValue(for: .kilocalorie())
            guard value.isFinite, value > 0 else { continue }
            let day = calendar.startOfDay(for: sample.startDate)
            var item = result[day] ?? HealthDay(date: day)
            item.calories = (item.calories ?? 0) + value
            result[day] = item
        }
        days = result.values.sorted { $0.date < $1.date }
        if days.isEmpty {
            message = "Nessun dato leggibile. Potrebbero mancare le registrazioni o i permessi: iOS non distingue questi casi."
        }
    }
    private func samples(_ identifier: HKQuantityTypeIdentifier, start: Date, end: Date) async throws -> [HKQuantitySample] {
        let type = HKObjectType.quantityType(forIdentifier: identifier)!
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        return try await withCheckedThrowingContinuation { continuation in
            let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: HKObjectQueryNoLimit,
                                      sortDescriptors: [NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)]) { _, samples, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: samples as? [HKQuantitySample] ?? []) }
            }
            health.execute(query)
        }
    }
}
