import SwiftUI

/// Standard text fade; no per-character delays or custom intro playback.
struct NativeTypingSummary: View {
    @Environment(\.nativeReduceMotion) private var reduceMotion
    let text: AttributedString
    let ready: Bool
    private var plainText: String { String(text.characters) }
    var body: some View {
        Text(text).font(NativeDesign.body).fixedSize(horizontal: false, vertical: true)
            .contentTransition(reduceMotion ? .identity : .opacity)
            .animation(reduceMotion ? nil : .default, value: plainText)
            .accessibilityLabel(plainText)
    }
}
