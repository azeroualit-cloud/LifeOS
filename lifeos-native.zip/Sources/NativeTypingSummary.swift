import SwiftUI
import UIKit

/// Reveals glyphs without changing text layout, colour emphasis or accessibility.
struct NativeTypingSummary: View {
    @EnvironmentObject private var router: NativeRouter
    @Environment(\.nativeReduceMotion) private var reduceMotion
    let text: AttributedString
    let ready: Bool
    @State private var visibleCharacters: Int?
    private var plainText: String { String(text.characters) }
    private var count: Int { text.characters.count }
    private struct ContentKey: Equatable { let text: String; let ready: Bool }
    private var rendered: AttributedString {
        var result = text
        let visible = min(count, visibleCharacters ?? (router.homeIntroConsumed || !ready || reduceMotion || UIAccessibility.isVoiceOverRunning ? count : 0))
        if visible < count {
            let start = result.characters.index(result.startIndex, offsetBy: visible)
            // Retain every character and font: wrapping and section positions stay fixed.
            result[start..<result.endIndex].foregroundColor = .clear
        }
        return result
    }
    var body: some View {
        Text(rendered).font(NativeDesign.body).fixedSize(horizontal: false, vertical: true)
            .accessibilityLabel(plainText)
            .task(id: ContentKey(text: plainText, ready: ready)) { await reveal() }
            .onDisappear { visibleCharacters = count }
    }
    @MainActor private func reveal() async {
        guard ready, !router.homeIntroConsumed, !reduceMotion, !UIAccessibility.isVoiceOverRunning, count > 0 else {
            visibleCharacters = count
            if ready { router.homeIntroConsumed = true }
            return
        }
        visibleCharacters = 0; router.homeIntroConsumed = true
        let started = ProcessInfo.processInfo.systemUptime
        while !Task.isCancelled {
            if reduceMotion || UIAccessibility.isVoiceOverRunning { visibleCharacters = count; return }
            let progress = min(1, (ProcessInfo.processInfo.systemUptime - started) / NativeDesign.Motion.introDuration)
            visibleCharacters = min(count, Int((Double(count) * progress).rounded(.up)))
            if progress >= 1 { return }
            do { try await Task.sleep(nanoseconds: NativeDesign.Motion.introTickNanoseconds) }
            catch { return }
        }
    }
}
