import SwiftUI

/// Keeps navigation inside one sheet, so choosing a type cannot race dismissal.
struct WidgetQuickAddScreen: View {
    @EnvironmentObject private var store: NativeStore
    var body: some View {
        List {
            NavigationLink {
                EventEditor(record: ["day": .string(CivilDate.day())])
            } label: { Label("Evento", systemImage: "calendar.badge.plus") }
                .accessibilityIdentifier("widget-add-event")
            NavigationLink {
                TaskEditor(record: ["list_kind": .string("action"), "scheduled_date": .string(CivilDate.day())])
            } label: { Label("Attività", systemImage: "checklist") }
                .accessibilityIdentifier("widget-add-task")
            if let status = store.widgetStatus { Text(status).font(NativeDesign.metadata).foregroundStyle(NativeDesign.secondary) }
        }
        .navigationTitle("Aggiungi").navigationBarTitleDisplayMode(.inline)
        .toolbar { DoneButton() }
    }
}
