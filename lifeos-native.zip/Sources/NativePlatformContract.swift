import Foundation

// Generated from shared/platform-contract.json.
enum NativePlatformContract {
    static let expenseCategories = ["Alimentari", "Ristorazione", "Casa", "Affitto", "Condominio", "Arredamento e casa", "Utenze", "Elettricità", "Gas", "Acqua", "Abbonamenti", "Auto", "Assicurazione", "Bollo", "Manutenzione auto", "Benzina", "Shopping", "Salute", "Palestra", "Dentista", "Farmaci e visite", "Svago", "Viaggi", "Altro"]
    static let incomeCategories = ["Stipendio", "Interessi", "Rimborsi", "Altro"]
    static let planKinds = ["advance": "Anticipa budget", "goal": "Obiettivo finito", "fund": "Fondo senza scadenza", "fixed": "Spesa ricorrente fissa", "estimated": "Utenza con quota stimata", "recovery": "Rateizza una spesa"]
    static let planStatuses = ["active": "In corso", "stopped": "Interrotto", "closed": "Concluso", "cancelled": "Annullato", "pendingPayment": "Pagamento da completare"]
    static let plansUnavailable = "Il server collegato non supporta Piani v2. Aggiorna il Worker usato da questa piattaforma e riprova. I piani precedenti sono conservati."
}
