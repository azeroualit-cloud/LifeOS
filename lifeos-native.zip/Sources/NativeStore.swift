import Foundation
import SwiftUI

@MainActor final class NativeStore: ObservableObject {
    @Published private(set) var state = NativeArchive()
    @Published private(set) var busy = false
    @Published var error: String?
    @Published var notice: String?
    @Published var financeMonth = CivilDate.month()
    @Published var calendarMonth = CivilDate.month()
    @Published var weather = ""
    @Published private(set) var weatherDetails: NativeWeather?
    @Published private(set) var weatherDate: Date?
    @Published private(set) var syncStatus = ""
    @Published private(set) var analysisBusy = false
    @Published private(set) var financeGeneration = 0
    @Published private(set) var sharedDatabase = false
    private var weatherBusy = false
    private var analysisGeneration = -1
    private var lastAutomaticSync = Date.distantPast
    private let persistsSession: Bool
    private let file: URL
    private let session: URLSession
    private var connectionFile: URL { file.deletingLastPathComponent().appendingPathComponent("lifeos-connection-backup.json") }
    var hasSavedConnection: Bool { FileManager.default.fileExists(atPath: connectionFile.path) }
    private var revision = 0
    private var archiveWritable = true
    var server: URL? { state.endpoint.flatMap(URL.init(string:)) }
    var isDemo: Bool { state.demo }
    var life: Record { state.life }
    var finance: Record { state.finance }
    var summary: Record { finance.record("summary") }
    var tasks: [Record] { life.records("tasks") }
    var categories: [Record] { life.records("categories").sorted { $0.amount("position") < $1.amount("position") } }
    var routines: [Record] { life.records("routines") }
    var transactions: [Record] { finance.records("transactions").filter { !isDemo || $0.text("date").hasPrefix(financeMonth) }.sorted { $0.text("date") > $1.text("date") } }
    var allocations: [Record] { state.plan.records("allocations") }
    var dashboardEvents: [Record] {
        let today = CivilDate.day()
        return isDemo ? expandedEvents(low: today, high: CivilDate.adding(7, to: today), source: life.records("events")) : life.records("upcomingEvents")
    }
    var events: [Record] {
        guard isDemo else { return life.records("events") }
        let low = CivilDate.adding(-1, to: calendarMonth + "-01", component: .month)
        let high = CivilDate.adding(2, to: calendarMonth + "-01", component: .month)
        return expandedEvents(low: low, high: high, source: life.records("events"))
    }
    var highlights: [Record] {
        let upcoming: [Record]
        if isDemo {
            let now = Date(), hour = CivilDate.calendar.component(.hour, from: now), minute = CivilDate.calendar.component(.minute, from: now)
            let clock = String(format: "%02d:%02d", hour, minute)
            upcoming = expandedEvents(low: CivilDate.day(), high: CivilDate.adding(7, to: CivilDate.day()), source: life.records("events"))
                .filter { $0.text("occurrence_status", fallback: "open") == "open" && ($0.text("day") > CivilDate.day() || $0.text("start_time").isEmpty || $0.text("start_time") >= clock) }
        } else { upcoming = life.records("upcomingEvents") }
        let first = CivilDate.day(), last = CivilDate.adding(6, to: CivilDate.day())
        let priority = upcoming.filter { $0.text("day") >= first && $0.text("day") <= last && $0.text("occurrence_status", fallback: "open") == "open" }
            .sorted { ($0.text("day"), $0.text("start_time")) < ($1.text("day"), $1.text("start_time")) }
        let events = priority.prefix(3).map { row -> Record in var r = row; r["highlightKind"] = .string("event"); return r }
        let todo = tasks.filter { $0.text("list_kind") == "action" && $0.text("status") == "todo" }.sorted {
            let a = $0.text("due_date", fallback: "9999"), b = $1.text("due_date", fallback: "9999")
            return a == b ? $0.amount("sort_order") < $1.amount("sort_order") : a < b
        }.prefix(max(0, 3 - events.count)).map { row -> Record in var r = row; r["highlightKind"] = .string("task"); return r }
        return events + todo
    }
    init(directory: URL? = nil, session injectedSession: URLSession? = nil, migrateLegacy: Bool = true) {
        let config = URLSessionConfiguration.ephemeral; config.timeoutIntervalForRequest = 40; config.timeoutIntervalForResource = 90
        persistsSession = injectedSession == nil
        session = injectedSession ?? URLSession(configuration: config)
        let folder = directory ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        file = folder.appendingPathComponent("lifeos-native-v2.json")
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: file.path) {
                state = try JSONDecoder().decode(NativeArchive.self, from: Data(contentsOf: file))
            } else {
                var initial = DemoData.make()
                let legacy = migrateLegacy ? try Storage(folder: folder).load() : Archive()
                if !legacy.queue.isEmpty || !legacy.confirmed.isEmpty || legacy.finance != nil {
                    initial.demo = false
                    initial.imported = true
                    initial.life = DemoData.emptyLife()
                    initial.plan = [:]
                    initial.endpoint = UserDefaults.standard.string(forKey: "test-server")
                    if let finance = legacy.finance {
                        initial.finance = try JSONDecoder().decode(JSONValue.self, from: JSONEncoder().encode(finance)).object
                    } else { initial.finance = [:] }
                    initial.pending = try legacy.queue.map { e in
                        PendingWrite(id: e.requestId, method: "saveTransaction", payload: try JSONDecoder().decode(JSONValue.self, from: JSONEncoder().encode(e)).object)
                    } + legacy.confirmed.map { e in
                        PendingWrite(id: e.requestId, method: "saveTransaction", payload: try JSONDecoder().decode(JSONValue.self, from: JSONEncoder().encode(e)).object, accepted: true)
                    }
                }
                try save(initial)
            }
            financeMonth = state.financeMonth; calendarMonth = state.calendarMonth
            rollover()
            if persistsSession, let server { acceptCookies(SessionVault.load(origin: server.absoluteString)) }
        } catch { archiveWritable = false; self.error = "Archivio non disponibile: \(error.localizedDescription). I dati precedenti non sono stati cancellati." }
    }
    #if DEBUG
    func seedVisualHome(empty: Bool) {
        guard isDemo else { return }
        var demo = state
        if empty {
            for key in ["events", "tasks", "routines", "shifts"] { demo.life[key] = .array([]) }
            demo.finance["summary"] = .object([:])
        } else {
            let today = CivilDate.day()
            demo.life["events"] = .array((1...12).map { i in .object(["id": .int(i), "day": .string(CivilDate.adding(i % 5, to: today)), "title": .string("Appuntamento \(i)"), "frequency": .string("none")]) })
            demo.life["routines"] = .array((1...8).map { i in .object(["id": .int(i), "title": .string(i == 1 ? "Abitudine con un nome molto lungo da leggere senza sovrapposizioni" : "Abitudine \(i)"), "checked": .bool(i % 2 == 0)]) })
        }
        try? save(demo)
    }
    func seedVisualMoney() {
        var demo = state
        var summary = demo.finance.record("summary")
        summary["budget"] = .number(12345.67); summary["committedCurrent"] = .number(345.67); summary["remainingFree"] = .number(12000)
        summary["monthlyRemaining"] = .number(-1234.56)
        demo.finance["summary"] = .object(summary)
        let names = ["Casa", "Alimentari", "Ristorazione", "Benzina", "Shopping", "Abbonamenti", "Salute", "Svago"]
        demo.finance["categories"] = .array(names.enumerated().map { index, name in .object(["name": .string(name), "amount": .number(Double(800 - index * 90))]) })
        try? save(demo)
    }
    func seedVisualTasks() {
            var demo = state
            let sample = demo.life.records("tasks").first ?? [:]
            demo.life["tasks"] = .array((1...60).map { i in
                var row = sample; row["id"] = .int(i); row["title"] = .string("Attività lunga di verifica \(i): pianificare e organizzare gli impegni della settimana"); row["notes"] = .string("Nota su due righe per controllare l’allineamento e lo scorrimento della lista."); row["status"] = .string(i % 3 == 0 ? "waiting" : "todo"); row["sort_order"] = .int(i)
                return .object(row)
            })
            try? save(demo)
    }
    #endif
    private func save(_ next: NativeArchive) throws {
        guard archiveWritable else { throw Message(text: "L’archivio esistente non è leggibile. Conserva i file prima di tentare un recupero.") }
        let data = try JSONEncoder().encode(next)
        try data.write(to: file, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        state = next
    }
    func rollover() {
        guard state.demo, state.routineDay != CivilDate.day() else { return }
        var next = state
        next.routineDay = CivilDate.day(); next.life["today"] = .string(CivilDate.day())
        next.life["routines"] = .array(routines.map { var r = $0; r["checked"] = .int(0); return .object(r) })
        do { try save(next) } catch { self.error = error.localizedDescription }
    }
    func configure(_ raw: String) throws {
        guard !busy else { throw Message(text: "Attendi la fine dell’operazione.") }
        guard let u = URL(string: raw.trimmingCharacters(in: .whitespacesAndNewlines)), u.scheme == "https", let host = u.host,
              u.user == nil, u.password == nil, u.query == nil, u.fragment == nil, u.path.isEmpty || u.path == "/" else {
            throw Message(text: "Inserisci l’indirizzo HTTPS del server Life OS.")
        }
        let clean = "https://" + host + (u.port.map { ":\($0)" } ?? "")
        let firstConnection = state.endpoint == nil && !state.pending.contains(where: { $0.accepted })
        guard state.pending.isEmpty || clean == state.endpoint || firstConnection else {
            throw Message(text: "Ci sono movimenti da conservare: non possono essere inviati automaticamente a un altro server.")
        }
        if state.endpoint == clean { return }
        revision += 1
        var next = NativeArchive(); next.demo = false; next.endpoint = clean
        // A local write created before the first connection has no server to leave.
        // Keep its UUID/payload and persist the destination before any network request.
        next.pending = state.pending
        try save(next)
        weatherDetails = nil; weatherDate = nil; weather = ""
        sharedDatabase = false; analysisGeneration = -1; financeGeneration += 1
        financeMonth = state.financeMonth; calendarMonth = state.calendarMonth
        session.configuration.httpCookieStorage?.removeCookies(since: .distantPast)
    }
    func useDemo() throws {
        guard archiveWritable else { throw Message(text: "L’archivio precedente non è leggibile e non verrà sovrascritto.") }
        guard !busy else { throw Message(text: "Attendi la fine dell’operazione.") }
        guard !state.demo else { notice = "La demo è già aperta. Le modifiche locali sono conservate."; return }
        if !state.demo {
            try JSONEncoder().encode(state).write(to: connectionFile, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        }
        revision += 1
        try save(DemoData.make())
        weatherDetails = nil; weatherDate = nil; weather = ""
        sharedDatabase = false; analysisGeneration = -1; financeGeneration += 1
        financeMonth = state.financeMonth; calendarMonth = state.calendarMonth
        session.configuration.httpCookieStorage?.removeCookies(since: .distantPast)
        notice = "Demo con dati simulati. Nessuna connessione al database."
    }
    func restoreConnection() throws {
        guard !busy, state.demo, hasSavedConnection else { throw Message(text: "L’archivio precedente si ripristina dalla demo.") }
        let previous = try JSONDecoder().decode(NativeArchive.self, from: Data(contentsOf: connectionFile))
        revision += 1
        try save(previous)
        weatherDetails = nil; weatherDate = nil; weather = ""
        sharedDatabase = false; analysisGeneration = -1; financeGeneration += 1
        financeMonth = state.financeMonth; calendarMonth = state.calendarMonth
        session.configuration.httpCookieStorage?.removeCookies(since: .distantPast)
    }
    func importFinance(_ data: Data) throws {
        guard server == nil, !busy else { throw Message(text: "L’importazione locale è disponibile senza un server configurato.") }
        let snapshot = try NativeValidation.snapshot(data)
        var next = state; next.finance = snapshot; next.demo = false; next.imported = true
        let key = snapshot.text("key")
        let months = Set(snapshot.records("transactions").map { String($0.text("date").prefix(7)) })
        if key.range(of: #"^20\d\d-(0[1-9]|1[0-2])$"#, options: .regularExpression) != nil { next.financeMonth = key }
        else if months.count == 1, let month = months.first { next.financeMonth = month }
        next.life = DemoData.emptyLife(); next.plan = [:]; next.refreshedAt = Date(); next.financeRefreshedAt = Date()
        try save(next); financeMonth = next.financeMonth; notice = "Snapshot importato. I movimenti locali sono conservati."
    }
    func backupData() throws -> Data {
        guard archiveWritable else { throw Message(text: "L’archivio non è leggibile. Conserva il file originale per il recupero.") }
        let current = try JSONDecoder().decode(JSONValue.self, from: JSONEncoder().encode(state))
        var result: Record = ["format": .string("LifeOS-native-backup-v2"), "current": current]
        if hasSavedConnection { result["previous"] = try JSONDecoder().decode(JSONValue.self, from: Data(contentsOf: connectionFile)) }
        return try JSONEncoder().encode(JSONValue.object(result))
    }
    func acceptCookies(_ cookies: [HTTPCookie]) {
        guard let server else { return }
        let matching = cookies.filter { c in
            let domain = c.domain.hasPrefix(".") ? String(c.domain.dropFirst()) : c.domain
            return domain == server.host || (c.domain.hasPrefix(".") && server.host!.hasSuffix("." + domain))
        }
        session.configuration.httpCookieStorage?.setCookies(matching, for: server, mainDocumentURL: server)
        if persistsSession, !matching.isEmpty, !SessionVault.save(matching, origin: server.absoluteString) {
            notice = "Accesso riuscito. La sessione non è stata conservata nel Portachiavi: potresti dover accedere di nuovo alla prossima apertura."
        }
    }
    func signIn(password: String) async throws {
        guard let server else { throw Message(text: "Collega prima il tuo server Life OS.") }
        guard !busy else { throw Message(text: "Attendi la fine dell’aggiornamento e riprova.") }
        busy = true; defer { busy = false }
        var request = URLRequest(url: server.appendingPathComponent("auth/login"))
        request.httpMethod = "POST"; request.timeoutInterval = 40
        request.setValue(server.absoluteString, forHTTPHeaderField: "Origin")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(["user": "nas", "password": password])
        let (_, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, http.url?.host == server.host,
              http.url?.scheme == server.scheme, http.url?.port == server.port else { throw Message(text: "Risposta di accesso non valida.") }
        guard http.statusCode == 200 else { throw Message(text: http.statusCode == 401 ? "Password non valida." : "Accesso non riuscito. Riprova tra poco.") }
        let headers = http.allHeaderFields.reduce(into: [String: String]()) { $0[String(describing: $1.key)] = String(describing: $1.value) }
        let cookies = HTTPCookie.cookies(withResponseHeaderFields: headers, for: server)
        guard cookies.contains(where: { $0.name == "liquidita_session" && $0.isSecure }) else { throw Message(text: "Il server non ha confermato la sessione.") }
        if http.value(forHTTPHeaderField: "X-LifeOS-Data-Source") == "shared" { sharedDatabase = true }
        acceptCookies(cookies)
    }
    func read(_ method: String, args: [JSONValue] = []) async throws -> JSONValue {
        for attempt in 0...1 {
            do { return try await requestOnce(method, args: args) }
            catch {
                guard attempt == 0, NativeSyncPolicy.canRetry(method: method, error: error) else { throw error }
                try await Task.sleep(nanoseconds: 400_000_000)
            }
        }
        throw URLError(.unknown)
    }
    private func requestOnce(_ method: String, args: [JSONValue]) async throws -> JSONValue {
        guard let server else { throw Message(text: "Collega prima Life OS nelle Impostazioni.") }
        var request = URLRequest(url: server.appendingPathComponent("api/" + method))
        request.httpMethod = "POST"; request.setValue(server.absoluteString, forHTTPHeaderField: "Origin")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(args)
        request.timeoutInterval = 40
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, http.url?.host == server.host, http.url?.scheme == server.scheme,
              http.url?.port == server.port else {
            throw Message(text: "Accedi a Life OS nelle Impostazioni.")
        }
        if http.value(forHTTPHeaderField: "X-LifeOS-Data-Source") == "shared" { sharedDatabase = true }
        guard (200..<300).contains(http.statusCode) else {
            if [502, 503, 504].contains(http.statusCode) { throw NativeServerUnavailable(status: http.statusCode) }
            let text = String(data: data, encoding: .utf8) ?? ""
            if http.mimeType == "text/html" { throw Message(text: "Accedi a Life OS nelle Impostazioni.") }
            throw Message(text: text.isEmpty ? "Operazione rifiutata (\(http.statusCode))." : String(text.prefix(500)))
        }
        guard http.mimeType == "application/json" else { throw Message(text: "Il server non ha restituito JSON. Verifica l’accesso a Life OS.") }
        let result = try JSONDecoder().decode(JSONValue.self, from: data)
        return result
    }
    private func fetchPart(_ method: String, args: [JSONValue], needed: Bool) async -> Result<JSONValue, Error>? {
        guard needed else { return nil }
        do { return .success(try await read(method, args: args)) } catch { return .failure(error) }
    }
    private func refresh(_ scope: NativeRefreshScope = .all) async throws {
        let version = revision, fm = financeMonth, cm = calendarMonth
        let y = Int(fm.prefix(4)) ?? 2026, m = Int(fm.suffix(2)) ?? 1
        async let lifeResult = fetchPart("getLifeData", args: [.string(cm)], needed: scope.contains(.life))
        async let financeResult = fetchPart("getFinanceOverview", args: [.int(y), .int(m)], needed: scope.contains(.finance))
        let (l, f) = await (lifeResult, financeResult)
        guard version == revision, fm == financeMonth, cm == calendarMonth else { throw CancellationError() }
        var next = state, failure: Error?, changed = false, financeChanged = false
        if let l {
            do {
                let value = try l.get().object
                guard case .array? = value["tasks"] else { throw Message(text: "Elenco attività non compatibile.") }
                next.life = value; next.calendarMonth = cm; next.lifeRefreshedAt = Date(); changed = true
            } catch { failure = error }
        }
        if let f {
            do {
                let value = try f.get().object
                _ = try NativeValidation.snapshot(JSONEncoder().encode(value))
                guard case .array? = value.record("extraPlan")["allocations"] else { throw Message(text: "Piano finanziario non compatibile.") }
                // Preserve cached charts for this month until the optional analysis refresh finishes.
                var merged = state.financeMonth == fm ? next.finance : [:]
                merged.merge(value) { _, new in new }
                next.finance = merged; next.plan = value.record("extraPlan"); next.financeMonth = fm; next.financeRefreshedAt = Date()
                changed = true; financeChanged = true
            } catch { failure = failure ?? error }
        }
        if changed { next.refreshedAt = Date(); next.imported = false; try save(next) }
        if financeChanged { financeGeneration += 1 }
        if let failure { throw failure }
    }
    func loadAnalysis() async {
        guard !isDemo, server != nil else { return }
        do { while analysisBusy { try await Task.sleep(nanoseconds: 100_000_000) } }
        catch { return }
        guard analysisGeneration != financeGeneration, !Task.isCancelled else { return }
        analysisBusy = true; defer { analysisBusy = false }
        do {
            while busy { try await Task.sleep(nanoseconds: 100_000_000) }
            let version = revision, generation = financeGeneration, month = financeMonth
            let result = try await read("getFinanceData", args: [.int(Int(month.prefix(4)) ?? 2026), .int(Int(month.suffix(2)) ?? 1)])
            try Task.checkCancellation()
            guard version == revision, generation == financeGeneration, month == financeMonth else { return }
            _ = try NativeValidation.snapshot(JSONEncoder().encode(result))
            var next = state; next.finance = result.object; next.financeRefreshedAt = Date(); try save(next)
            analysisGeneration = generation
        } catch is CancellationError {} catch {
            if (error as? URLError)?.code == .cancelled { return }
            if !NativeSyncPolicy.isTransient(error) { notice = "Analisi non aggiornata. Puoi riprovare dalla schermata Finanza." }
        }
    }
    var analysisIsCurrent: Bool { isDemo || analysisGeneration == financeGeneration }
    func sync(automatic: Bool = false, scope: NativeRefreshScope = .all) async {
        if isDemo { rollover(); return }
        guard server != nil, !busy else { return }
        if automatic, state.pending.isEmpty, Date().timeIntervalSince(lastAutomaticSync) < 25 { return }
        busy = true; error = nil; syncStatus = "Aggiornamento…"; defer { busy = false }
        let hadPending = !state.pending.isEmpty
        do {
            // The destination is persisted before writes. Stable UUIDs make a later retry safe.
            // No full read before sending: it doubled latency and prevented offline queues draining.
            while let write = state.pending.first(where: { !$0.accepted }) {
                let result = try await read(write.method, args: [.object(write.payload)])
                let accepted = write.method == "saveTransaction" ? result == .bool(true) : result.object.integer("row") > 0
                guard accepted else { throw Message(text: "Il server non ha confermato il movimento. La coda è conservata.") }
                var next = state
                if let index = next.pending.firstIndex(where: { $0.id == write.id }) { next.pending[index].accepted = true }
                try save(next)
            }
            try await refresh(hadPending ? scope.union(.finance) : scope)
            if hadPending { var next = state; next.pending.removeAll { $0.accepted }; try save(next) }
            lastAutomaticSync = Date(); syncStatus = "Aggiornato"; notice = nil
        } catch is CancellationError { syncStatus = "Aggiornamento sospeso" }
        catch {
            if NativeSyncPolicy.isTransient(error) {
                syncStatus = state.pending.isEmpty ? "Dati salvati · riprovo al prossimo aggiornamento" : "Movimenti salvati · in attesa di rete"
                notice = syncStatus
            } else {
                syncStatus = "Accesso o verifica richiesta"
                if automatic { notice = error.localizedDescription } else { self.error = error.localizedDescription }
            }
        }
    }
    func perform(_ method: String, _ payload: Record = [:], args: [JSONValue]? = nil) async throws {
        guard !busy else { throw Message(text: "Attendi la fine dell’operazione in corso.") }
        error = nil
        if isDemo {
            var next = state
            try DemoActions.apply(method, payload, args: args, state: &next)
            next.refreshedAt = Date(); try save(next); return
        }
        if method == "saveTransaction" || method == "saveExtra" {
            guard server != nil else { throw Message(text: "Per nuovi movimenti collega Life OS oppure apri la demo.") }
            var p = payload
            let id = p.text("requestId", fallback: UUID().uuidString); p["requestId"] = .string(id)
            var next = state
            if !next.pending.contains(where: { $0.id == id }) { next.pending.append(PendingWrite(id: id, method: method, payload: p)) }
            try save(next)
            notice = "Salvato sul dispositivo."
            await sync(automatic: true, scope: .finance); return
        }
        guard server != nil else { throw Message(text: "Questo snapshot è consultabile. Per modificare attività e calendario usa la demo o collega Life OS.") }
        busy = true; defer { busy = false }
        // No automatic retry: these API methods do not all support request IDs.
        let result = try await read(method, args: args ?? [.object(payload)])
        guard result != .bool(false) else { throw Message(text: "Il server non ha confermato la modifica.") }
        do { try await refresh(NativeSyncPolicy.scope(for: method)) }
        catch { notice = "Operazione inviata. Aggiornamento non riuscito: sincronizza prima di ripetere l’azione." }
    }
    func run(_ method: String, _ payload: Record = [:], args: [JSONValue]? = nil) async {
        do { try await perform(method, payload, args: args) } catch { self.error = error.localizedDescription }
    }
    func shift(_ day: String) -> ShiftKind? { life.records("shifts").first { $0.text("day") == day }.flatMap { ShiftKind(rawValue: $0.text("kind")) } }
    func changeMonth(_ delta: Int, finance: Bool) async {
        guard !busy else { return }
        if finance {
            let next = String(CivilDate.adding(delta, to: financeMonth + "-01", component: .month).prefix(7))
            guard next >= "2024-01", next <= "2035-12" else { return }
            financeMonth = next
        }
        else { calendarMonth = String(CivilDate.adding(delta, to: calendarMonth + "-01", component: .month).prefix(7)) }
        revision += 1
        if isDemo {
            var next = state; next.financeMonth = financeMonth; next.calendarMonth = calendarMonth
            do { try save(next) } catch { self.error = error.localizedDescription }
            return
        }
        await sync(scope: finance ? .finance : .life)
        financeMonth = state.financeMonth; calendarMonth = state.calendarMonth
    }
    func expandedEvents(low: String, high: String, source: [Record]) -> [Record] {
        source.flatMap { event -> [Record] in
            CivilDate.occurrenceDays(start: event.text("day"), frequency: event.text("frequency"), until: event.text("until_day"), low: low, high: high).compactMap { day in
                var e = event; e["series_day"] = event["day"]; e["day"] = .string(day)
                let key = "\(event.integer("id")):\(day)"
                let status = life.record("occurrences").text(key, fallback: "open")
                if status == "skipped" { return nil }
                e["occurrence_status"] = .string(status); return e
            }
        }.sorted { ($0.text("day"), $0.text("start_time")) < ($1.text("day"), $1.text("start_time")) }
    }
    func loadWeather() async {
        guard !weatherBusy else { return }
        if let date = weatherDate, Date().timeIntervalSince(date) < 900 { return }
        if isDemo {
            weatherDetails = NativeWeather(temperature: 18, low: 12, high: 22, code: 0, change: "Nuvoloso dalle 18:00 · Demo")
            weatherDate = Date(); weather = "18° · Demo"; return
        }
        weatherBusy = true; defer { weatherBusy = false }
        guard let url = URL(string: "https://api.open-meteo.com/v1/forecast?latitude=43.72&longitude=10.95&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&hourly=weather_code&forecast_days=2&timezone=Europe%2FRome") else { return }
        do {
            var request = URLRequest(url: url); request.timeoutInterval = 12
            let (data, response) = try await URLSession.shared.data(for: request)
            guard (response as? HTTPURLResponse)?.statusCode == 200,
                  let parsed = NativeWeather.parse(try JSONDecoder().decode(JSONValue.self, from: data).object) else { throw URLError(.badServerResponse) }
            weatherDetails = parsed; weatherDate = Date(); weather = "\(Int(parsed.temperature.rounded()))°"
        } catch { weather = "Meteo non disponibile" }
    }
}
