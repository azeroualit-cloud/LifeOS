import Foundation
import SwiftUI

@MainActor final class NativeStore: ObservableObject {
    @Published private(set) var state = NativeArchive()
    @Published private(set) var busy = false
    @Published var error: String?
    @Published var notice: String?
    @Published var financeMonth = CivilDate.month()
    @Published var calendarMonth = CivilDate.month()
    @Published var weather = ""
    private let file: URL
    private let session: URLSession
    private var connectionFile: URL { file.deletingLastPathComponent().appendingPathComponent("lifeos-connection-backup.json") }
    var hasSavedConnection: Bool { FileManager.default.fileExists(atPath: connectionFile.path) }
    private var revision = 0
    private var archiveWritable = true
    var server: URL? { state.endpoint.flatMap(URL.init(string:)) }
    var isDemo: Bool { state.demo }
    var life: Record { state.life }
    var finance: Record { state.finance }
    var summary: Record { finance.record("summary") }
    var tasks: [Record] { life.records("tasks") }
    var categories: [Record] { life.records("categories").sorted { $0.amount("position") < $1.amount("position") } }
    var routines: [Record] { life.records("routines") }
    var transactions: [Record] { finance.records("transactions").filter { !isDemo || $0.text("date").hasPrefix(financeMonth) }.sorted { $0.text("date") > $1.text("date") } }
    var allocations: [Record] { state.plan.records("allocations") }
    var events: [Record] {
        guard isDemo else { return life.records("events") }
        let low = CivilDate.adding(-1, to: calendarMonth + "-01", component: .month)
        let high = CivilDate.adding(2, to: calendarMonth + "-01", component: .month)
        return expandedEvents(low: low, high: high, source: life.records("events"))
    }
    var highlights: [Record] {
        let upcoming: [Record]
        if isDemo {
            let now = Date(), hour = CivilDate.calendar.component(.hour, from: now), minute = CivilDate.calendar.component(.minute, from: now)
            let clock = String(format: "%02d:%02d", hour, minute)
            upcoming = expandedEvents(low: CivilDate.day(), high: CivilDate.adding(7, to: CivilDate.day()), source: life.records("events"))
                .filter { $0.text("occurrence_status", fallback: "open") == "open" && ($0.text("day") > CivilDate.day() || $0.text("start_time").isEmpty || $0.text("start_time") >= clock) }
        } else { upcoming = life.records("upcomingEvents") }
        var result = Array(upcoming.prefix(3)).map { var r = $0; r["highlightKind"] = .string("event"); return r }
        result += tasks.filter { $0.text("list_kind") == "action" && $0.text("status") == "todo" }
            .sorted { $0.amount("sort_order") < $1.amount("sort_order") }.prefix(max(0, 3 - result.count)).map { var r = $0; r["highlightKind"] = .string("task"); return r }
        return result
    }
    init(directory: URL? = nil, session injectedSession: URLSession? = nil, migrateLegacy: Bool = true) {
        let config = URLSessionConfiguration.ephemeral; config.timeoutIntervalForRequest = 25
        session = injectedSession ?? URLSession(configuration: config)
        let folder = directory ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        file = folder.appendingPathComponent("lifeos-native-v2.json")
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: file.path) {
                state = try JSONDecoder().decode(NativeArchive.self, from: Data(contentsOf: file))
            } else {
                var initial = DemoData.make()
                let legacy = migrateLegacy ? try Storage(folder: folder).load() : Archive()
                if !legacy.queue.isEmpty || !legacy.confirmed.isEmpty || legacy.finance != nil {
                    initial.demo = false
                    initial.imported = true
                    initial.life = DemoData.emptyLife()
                    initial.plan = [:]
                    initial.endpoint = UserDefaults.standard.string(forKey: "test-server")
                    if let finance = legacy.finance {
                        initial.finance = try JSONDecoder().decode(JSONValue.self, from: JSONEncoder().encode(finance)).object
                    } else { initial.finance = [:] }
                    initial.pending = try legacy.queue.map { e in
                        PendingWrite(id: e.requestId, method: "saveTransaction", payload: try JSONDecoder().decode(JSONValue.self, from: JSONEncoder().encode(e)).object)
                    } + legacy.confirmed.map { e in
                        PendingWrite(id: e.requestId, method: "saveTransaction", payload: try JSONDecoder().decode(JSONValue.self, from: JSONEncoder().encode(e)).object, accepted: true)
                    }
                }
                try save(initial)
            }
            financeMonth = state.financeMonth; calendarMonth = state.calendarMonth
            rollover()
        } catch { archiveWritable = false; self.error = "Archivio non disponibile: \(error.localizedDescription). I dati precedenti non sono stati cancellati." }
    }
    private func save(_ next: NativeArchive) throws {
        guard archiveWritable else { throw Message(text: "L’archivio esistente non è leggibile. Conserva i file prima di tentare un recupero.") }
        let data = try JSONEncoder().encode(next)
        try data.write(to: file, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        state = next
    }
    func rollover() {
        guard state.demo, state.routineDay != CivilDate.day() else { return }
        var next = state
        next.routineDay = CivilDate.day(); next.life["today"] = .string(CivilDate.day())
        next.life["routines"] = .array(routines.map { var r = $0; r["checked"] = .int(0); return .object(r) })
        do { try save(next) } catch { self.error = error.localizedDescription }
    }
    func configure(_ raw: String) throws {
        guard !busy else { throw Message(text: "Attendi la fine dell’operazione.") }
        guard let u = URL(string: raw.trimmingCharacters(in: .whitespacesAndNewlines)), u.scheme == "https", let host = u.host,
              u.user == nil, u.password == nil, u.query == nil, u.fragment == nil, u.path.isEmpty || u.path == "/" else {
            throw Message(text: "Inserisci l’origine HTTPS della copia di test.")
        }
        let clean = "https://" + host + (u.port.map { ":\($0)" } ?? "")
        let firstConnection = state.endpoint == nil && !state.pending.contains(where: { $0.accepted })
        guard state.pending.isEmpty || clean == state.endpoint || firstConnection else {
            throw Message(text: "Ci sono movimenti da conservare: non possono essere inviati automaticamente a un altro server.")
        }
        if state.endpoint == clean { return }
        revision += 1
        var next = NativeArchive(); next.demo = false; next.endpoint = clean
        // A local write created before the first connection has no server to leave.
        // Keep its UUID/payload and persist the destination before any network request.
        next.pending = state.pending
        try save(next)
        financeMonth = state.financeMonth; calendarMonth = state.calendarMonth
        session.configuration.httpCookieStorage?.removeCookies(since: .distantPast)
    }
    func useDemo() throws {
        guard archiveWritable else { throw Message(text: "L’archivio precedente non è leggibile e non verrà sovrascritto.") }
        guard !busy else { throw Message(text: "Attendi la fine dell’operazione.") }
        guard !state.demo else { notice = "La demo è già aperta. Le modifiche locali sono conservate."; return }
        if !state.demo {
            try JSONEncoder().encode(state).write(to: connectionFile, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        }
        revision += 1
        try save(DemoData.make())
        financeMonth = state.financeMonth; calendarMonth = state.calendarMonth
        session.configuration.httpCookieStorage?.removeCookies(since: .distantPast)
        notice = "Demo con dati simulati. Nessuna connessione al database."
    }
    func restoreConnection() throws {
        guard !busy, state.demo, hasSavedConnection else { throw Message(text: "L’archivio precedente si ripristina dalla demo.") }
        let previous = try JSONDecoder().decode(NativeArchive.self, from: Data(contentsOf: connectionFile))
        revision += 1
        try save(previous)
        financeMonth = state.financeMonth; calendarMonth = state.calendarMonth
        session.configuration.httpCookieStorage?.removeCookies(since: .distantPast)
    }
    func importFinance(_ data: Data) throws {
        guard server == nil, !busy else { throw Message(text: "L’importazione locale è disponibile senza un server configurato.") }
        let snapshot = try NativeValidation.snapshot(data)
        var next = state; next.finance = snapshot; next.demo = false; next.imported = true
        let key = snapshot.text("key")
        let months = Set(snapshot.records("transactions").map { String($0.text("date").prefix(7)) })
        if key.range(of: #"^20\d\d-(0[1-9]|1[0-2])$"#, options: .regularExpression) != nil { next.financeMonth = key }
        else if months.count == 1, let month = months.first { next.financeMonth = month }
        next.life = DemoData.emptyLife(); next.plan = [:]; next.refreshedAt = Date()
        try save(next); financeMonth = next.financeMonth; notice = "Snapshot importato. I movimenti locali sono conservati."
    }
    func backupData() throws -> Data {
        guard archiveWritable else { throw Message(text: "L’archivio non è leggibile. Conserva il file originale per il recupero.") }
        let current = try JSONDecoder().decode(JSONValue.self, from: JSONEncoder().encode(state))
        var result: Record = ["format": .string("LifeOS-native-backup-v2"), "current": current]
        if hasSavedConnection { result["previous"] = try JSONDecoder().decode(JSONValue.self, from: Data(contentsOf: connectionFile)) }
        return try JSONEncoder().encode(JSONValue.object(result))
    }
    func acceptCookies(_ cookies: [HTTPCookie]) {
        guard let server else { return }
        let matching = cookies.filter { c in
            let domain = c.domain.hasPrefix(".") ? String(c.domain.dropFirst()) : c.domain
            return domain == server.host || (c.domain.hasPrefix(".") && server.host!.hasSuffix("." + domain))
        }
        session.configuration.httpCookieStorage?.setCookies(matching, for: server, mainDocumentURL: server)
    }
    func read(_ method: String, args: [JSONValue] = []) async throws -> JSONValue {
        guard let server else { throw Message(text: "Collega prima la copia di test.") }
        var request = URLRequest(url: server.appendingPathComponent("api/" + method))
        request.httpMethod = "POST"; request.setValue(server.absoluteString, forHTTPHeaderField: "Origin")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(args)
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, http.url?.host == server.host, http.url?.scheme == server.scheme,
              http.url?.port == server.port else {
            throw Message(text: "Accedi alla copia di test nelle Impostazioni.")
        }
        guard (200..<300).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? ""
            if http.mimeType == "text/html" { throw Message(text: "Accedi alla copia di test nelle Impostazioni.") }
            throw Message(text: text.isEmpty ? "Operazione rifiutata (\(http.statusCode))." : String(text.prefix(500)))
        }
        guard http.mimeType == "application/json" else { throw Message(text: "Il server non ha restituito JSON. Verifica l’accesso alla copia di test.") }
        let result = try JSONDecoder().decode(JSONValue.self, from: data)
        return result
    }
    private func refresh() async throws {
        let version = revision, fm = financeMonth, cm = calendarMonth
        let y = Int(fm.prefix(4)) ?? 2026, m = Int(fm.suffix(2)) ?? 1
        async let lifeResult = read("getLifeData", args: [.string(cm)])
        async let financeResult = read("getFinanceData", args: [.int(y), .int(m)])
        async let planResult = read("getExtraPlan", args: [.int(y)])
        let (l, f, p) = try await (lifeResult, financeResult, planResult)
        guard version == revision, fm == financeMonth, cm == calendarMonth else { return }
        _ = try NativeValidation.snapshot(JSONEncoder().encode(f))
        guard case .array? = l.object["tasks"], case .array? = p.object["allocations"] else {
            throw Message(text: "La copia di test ha restituito dati non compatibili. La coda è stata conservata.")
        }
        var next = state; next.life = l.object; next.finance = f.object; next.plan = p.object
        next.financeMonth = fm; next.calendarMonth = cm
        next.refreshedAt = Date(); next.imported = false; try save(next)
    }
    func sync() async {
        if isDemo { rollover(); return }
        guard server != nil, !busy else { return }
        busy = true; error = nil; defer { busy = false }
        do {
            try await refresh()
            while let write = state.pending.first(where: { !$0.accepted }) {
                let result = try await read(write.method, args: [.object(write.payload)])
                let accepted = write.method == "saveTransaction" ? result == .bool(true) : result.object.integer("row") > 0
                guard accepted else { throw Message(text: "Il server non ha confermato il movimento. La coda è stata conservata.") }
                var next = state
                if let index = next.pending.firstIndex(where: { $0.id == write.id }) { next.pending[index].accepted = true }
                try save(next)
            }
            try await refresh()
            var next = state; next.pending.removeAll { $0.accepted }; try save(next)
        } catch { self.error = error.localizedDescription }
    }
    func perform(_ method: String, _ payload: Record = [:], args: [JSONValue]? = nil) async throws {
        guard !busy else { throw Message(text: "Attendi la fine dell’operazione in corso.") }
        error = nil
        if isDemo {
            var next = state
            try DemoActions.apply(method, payload, args: args, state: &next)
            next.refreshedAt = Date(); try save(next); return
        }
        if method == "saveTransaction" || method == "saveExtra" {
            guard server != nil else { throw Message(text: "Per nuovi movimenti usa la demo oppure configura la copia di test.") }
            var p = payload
            let id = p.text("requestId", fallback: UUID().uuidString); p["requestId"] = .string(id)
            var next = state
            if !next.pending.contains(where: { $0.id == id }) { next.pending.append(PendingWrite(id: id, method: method, payload: p)) }
            try save(next)
            notice = "Salvato sul dispositivo."
            await sync(); return
        }
        guard server != nil else { throw Message(text: "Questo snapshot è consultabile. Per modificare attività e calendario usa la demo o collega la copia di test.") }
        busy = true; defer { busy = false }
        // No automatic retry: these API methods do not all support request IDs.
        _ = try await read(method, args: args ?? [.object(payload)])
        do { try await refresh() }
        catch { notice = "Operazione inviata. Aggiornamento non riuscito: sincronizza prima di ripetere l’azione." }
    }
    func run(_ method: String, _ payload: Record = [:], args: [JSONValue]? = nil) async {
        do { try await perform(method, payload, args: args) } catch { self.error = error.localizedDescription }
    }
    func shift(_ day: String) -> ShiftKind? { life.records("shifts").first { $0.text("day") == day }.flatMap { ShiftKind(rawValue: $0.text("kind")) } }
    func changeMonth(_ delta: Int, finance: Bool) async {
        guard !busy else { return }
        if finance {
            let next = String(CivilDate.adding(delta, to: financeMonth + "-01", component: .month).prefix(7))
            guard next >= "2024-01", next <= "2035-12" else { return }
            financeMonth = next
        }
        else { calendarMonth = String(CivilDate.adding(delta, to: calendarMonth + "-01", component: .month).prefix(7)) }
        revision += 1
        if isDemo {
            var next = state; next.financeMonth = financeMonth; next.calendarMonth = calendarMonth
            do { try save(next) } catch { self.error = error.localizedDescription }
            return
        }
        await sync()
        financeMonth = state.financeMonth; calendarMonth = state.calendarMonth
    }
    func expandedEvents(low: String, high: String, source: [Record]) -> [Record] {
        source.flatMap { event -> [Record] in
            CivilDate.occurrenceDays(start: event.text("day"), frequency: event.text("frequency"), until: event.text("until_day"), low: low, high: high).compactMap { day in
                var e = event; e["series_day"] = event["day"]; e["day"] = .string(day)
                let key = "\(event.integer("id")):\(day)"
                let status = life.record("occurrences").text(key, fallback: "open")
                if status == "skipped" { return nil }
                e["occurrence_status"] = .string(status); return e
            }
        }.sorted { ($0.text("day"), $0.text("start_time")) < ($1.text("day"), $1.text("start_time")) }
    }
    func loadWeather() async {
        guard !isDemo else { weather = "18° · Sereno · Demo"; return }
        guard let url = URL(string: "https://api.open-meteo.com/v1/forecast?latitude=43.72&longitude=10.95&current=temperature_2m,weather_code&timezone=Europe%2FRome") else { return }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let current = try JSONDecoder().decode(JSONValue.self, from: data).object.record("current")
            guard case .number(let temperature)? = current["temperature_2m"], temperature.isFinite else { weather = "Meteo non disponibile"; return }
            let code = current.integer("weather_code")
            weather = "\(Int(temperature.rounded()))° · " + (code == 0 ? "Sereno" : code < 4 ? "Nuvoloso" : code < 50 ? "Nebbia" : "Precipitazioni")
        } catch { weather = "Meteo non disponibile" }
    }
}
