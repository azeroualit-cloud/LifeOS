import SwiftUI

struct ExtraEditor: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    let record: Record
    private enum Field: Hashable { case name, amount, note, payment, linkAmount }
    @FocusState private var focusedField: Field?
    @State private var detail: Record = [:]
    @State private var name = ""
    @State private var amount = ""
    @State private var start = Date()
    @State private var end = Date()
    @State private var annual = false
    @State private var status = "Programmato"
    @State private var note = ""
    @State private var payment = ""
    @State private var paymentDate = Date()
    @State private var movement = 0
    @State private var linkAmount = ""
    @State private var candidates: [Record] = []
    @State private var candidateMonth = Date()
    @State private var loaded = false
    @State private var saving = false
    @State private var error: String?
    @State private var requestID = UUID().uuidString
    @State private var confirmCancel = false
    @State private var confirmDelete = false
    private var cycleID: Int { record.integer("cycle_id") }
    private var editing: Bool { cycleID > 0 }
    private var monthCount: Int {
        let a = CivilDate.calendar.dateComponents([.year, .month], from: start), b = CivilDate.calendar.dateComponents([.year, .month], from: end)
        return ((b.year ?? 0) - (a.year ?? 0)) * 12 + (b.month ?? 0) - (a.month ?? 0) + 1
    }
    var body: some View {
        Form {
            Section("1 · Pianifica la spesa") {
                TextField("Nome", text: $name).focused($focusedField, equals: .name)
                TextField("Totale previsto €", text: $amount).focused($focusedField, equals: .amount).keyboardType(.decimalPad)
                DatePicker("Primo mese", selection: $start, displayedComponents: .date).disabled(editing && annual)
                DatePicker("Ultimo mese", selection: $end, displayedComponents: .date).disabled(annual)
                if !editing { Toggle("Ripeti ogni anno", isOn: $annual); Picker("Stato", selection: $status) { Text("In corso · accantona ogni mese").tag("Programmato"); Text("Da valutare").tag("Previsto") } }
                else { LabeledContent("Stato", value: NativeExtraState.title(detail.text("status", fallback: record.text("status")))) }
                LabeledContent("Conto", value: detail.text("account", fallback: "Trade Republic"))
                TextField("Note", text: $note, axis: .vertical).focused($focusedField, equals: .note)
            }
            Section("Accantonamento mensile") {
                if let cents = Input.cents(amount), !NativeValidation.shares(cents: cents, months: monthCount).isEmpty {
                    let shares = NativeValidation.shares(cents: cents, months: monthCount)
                    LabeledContent("Durata", value: "\(monthCount) mesi")
                    LabeledContent("Da mettere da parte", value: (Double(shares[0]) / 100).euro)
                    Text("I centesimi residui sono distribuiti sui primi mesi. Le quote non sono nuove uscite bancarie.").font(.caption).foregroundStyle(Color.secondary)
                } else { Text("Scegli un periodo da uno a sessanta mesi.").foregroundStyle(Color.secondary) }
            }
            if editing && detail.text("kind", fallback: record.text("kind")) == "expense" && !["Pagato", "Annullato"].contains(detail.text("status", fallback: record.text("status"))) {
                Section("2 · Segna come pagata") {
                    TextField("Importo pagato €", text: $payment).focused($focusedField, equals: .payment).keyboardType(.decimalPad)
                    DatePicker("Data del pagamento", selection: $paymentDate, in: ...Date(), displayedComponents: .date)
                    Text("Puoi correggere qui l’importo effettivo, anche se diverso dal previsto. Il piano verrà chiuso per tutti i mesi; il denaro esce dai risparmi e non viene sottratto di nuovo dal budget mensile.").font(.caption).foregroundStyle(Color.secondary)
                    Button("Paga dai risparmi e chiudi il piano") {
                        guard let cents = Input.cents(payment) else { return }
                        Task { await action("recordExtraPayment", ["cycleId": .int(cycleID), "amount": .number(Double(cents) / 100), "date": .string(CivilDate.day(paymentDate)), "account": .string("Trade Republic"), "name": .string(name)]) }
                    }.disabled(Input.cents(payment) == nil || !loaded || saving || store.busy).accessibilityIdentifier("extra-pay-savings")
                }
            }
            if editing && !["Pagato", "Annullato"].contains(detail.text("status", fallback: record.text("status"))) {
                Section("Hai già registrato il pagamento?") {
                    DatePicker("Mese del movimento", selection: $candidateMonth, displayedComponents: .date)
                    Button("Carica movimenti del mese") { Task { await loadCandidates() } }.disabled(store.busy || saving)
                    Picker("Movimento", selection: $movement) {
                        Text("Seleziona").tag(0)
                        ForEach(candidates.map { DisplayRecord($0, key: "row") }) { item in Text(item.value.text("name") + " · " + abs(item.value.amount("amount")).euro).tag(item.value.integer("row")) }
                    }
                    TextField("Importo attribuito €", text: $linkAmount).focused($focusedField, equals: .linkAmount).keyboardType(.decimalPad)
                    Button("Collega senza creare una nuova spesa") {
                        guard let cents = Input.cents(linkAmount) else { return }
                        Task { await action("linkExtraMovement", ["cycleId": .int(cycleID), "movementId": .int(movement), "amount": .number(Double(cents) / 100)]) }
                    }.disabled(movement == 0 || Input.cents(linkAmount) == nil || !loaded || saving || store.busy)
                }
            }
            if editing {
                if let settlement = store.state.plan.records("settlements").first(where: { $0.integer("cycle_id") == cycleID }) {
                    Section("Pagata") {
                        LabeledContent("Previsto", value: ((detail["total_cents"] == nil ? record.amount("total_cents") : detail.amount("total_cents")) / 100).euro)
                        LabeledContent("Pagato effettivamente", value: (settlement.amount("actual_cents") / 100).euro)
                        Text("Tutti i mesi del piano risultano chiusi. Gli accantonamenti mostrano l’importo effettivamente pagato.").font(.caption).foregroundStyle(Color.secondary)
                    }
                }
                Section("Pagamenti collegati") {
                    ForEach(store.state.plan.records("links").filter { $0.integer("cycle_id") == cycleID }.enumerated().map { IndexedRecord(index: $0.offset, value: $0.element) }) { item in
                        HStack { Text("Movimento \(item.value.integer("movement_source_row"))"); Spacer(); MoneyText(amount: item.value.amount("attributed_cents") / 100) }
                        Button("Scollega movimento \(item.value.integer("movement_source_row"))", role: .destructive) { Task { await action("unlinkExtraMovement", ["cycleId": .int(cycleID), "movementId": .int(item.value.integer("movement_source_row"))]) } }.disabled(saving || store.busy)
                    }
                }
                Section {
                    Button("Annulla piano", role: .destructive) { confirmCancel = true }
                    if detail.text("status", fallback: record.text("status")) == "Annullato" { Button("Elimina piano", role: .destructive) { confirmDelete = true } }
                }.disabled(!loaded || saving || store.busy)
            }
            if let error { Text(error).foregroundStyle(.red) }
        }.scrollDismissesKeyboard(.interactively).navigationTitle(editing ? "Spesa extra" : "Nuova spesa extra").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("Fine") { focusedField = nil }.accessibilityIdentifier("extra-keyboard-done")
            }
            ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() }.disabled(saving) }
            ToolbarItem(placement: .confirmationAction) { Button("Salva") { Task { await save() } }.disabled(saving || store.busy || !loaded || Input.cents(amount) == nil || name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
        }
        .onChange(of: annual) { _, value in if value { end = CivilDate.calendar.date(byAdding: .month, value: 11, to: start) ?? start } }
        .onChange(of: start) { _, value in if annual && !editing { end = CivilDate.calendar.date(byAdding: .month, value: 11, to: value) ?? value } }
        .confirmationDialog("Annullare il piano? I movimenti bancari rimangono nello storico.", isPresented: $confirmCancel, titleVisibility: .visible) { Button("Annulla piano", role: .destructive) { Task { await action("cancelExtraCycle", ["cycleId": .int(cycleID)]) } } }
        .confirmationDialog("Eliminare definitivamente il piano annullato?", isPresented: $confirmDelete, titleVisibility: .visible) { Button("Elimina piano", role: .destructive) { Task { await action("deleteExtraPlan", ["cycleId": .int(cycleID)]) } } }
        .task {
            do {
                if editing && !store.isDemo { detail = try await store.read("getExtraCycleDetail", args: [.int(cycleID)]).object }
                else { detail = record }
                name = detail.text("name"); amount = editing ? String(format: "%.2f", detail.amount("total_cents") / 100).replacingOccurrences(of: ".", with: ",") : ""
                start = CivilDate.date(detail.text("start_month", fallback: store.financeMonth) + "-01")
                end = CivilDate.date(detail.text("end_month", fallback: store.financeMonth) + "-01")
                annual = detail.text("repeat") == "Annuale"; note = detail.text("notes"); loaded = true
                candidates = store.transactions.filter { $0.amount("amount") < 0 }; payment = amount; linkAmount = amount
            } catch { self.error = error.localizedDescription }
        }
    }
    private func save() async {
        guard let cents = Input.cents(amount) else { return }
        let payload: Record = ["cycleId": .int(cycleID), "requestId": .string(requestID), "name": .string(name), "amount": .number(Double(cents) / 100), "month": .string(CivilDate.month(start)), "endMonth": .string(CivilDate.month(end)), "account": .string(detail.text("account", fallback: "Trade Republic")), "repeat": .string(annual ? "Annuale" : "No"), "status": .string(status), "note": .string(note)]
        await action(editing ? "updateExtraPlan" : "saveExtra", payload)
    }
    private func action(_ method: String, _ payload: Record) async {
        saving = true; defer { saving = false }
        do { try await store.perform(method, payload); dismiss() } catch { self.error = error.localizedDescription }
    }
    private func loadCandidates() async {
        saving = true; defer { saving = false }
        do {
            if store.isDemo { candidates = store.finance.records("transactions").filter { $0.text("date").hasPrefix(CivilDate.month(candidateMonth)) && $0.amount("amount") < 0 } }
            else {
                let parts = CivilDate.calendar.dateComponents([.year, .month], from: candidateMonth)
                let value = try await store.read("getFinanceOverview", args: [.int(parts.year!), .int(parts.month!)])
                candidates = value.object.records("transactions").filter { $0.amount("amount") < 0 }
            }
        } catch { self.error = error.localizedDescription }
    }
}
struct RecurringEditor: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    let record: Record
    @State private var amount = ""
    @State private var estimate = ""
    @State private var date = Date()
    @State private var months = 1
    @State private var saving = false
    @State private var error: String?
    @State private var requestID = UUID().uuidString
    var body: some View {
        Form {
            Section("Stima mensile") {
                TextField("Stima €", text: $estimate).keyboardType(.decimalPad)
                if let next = record["nextEstimate"], case .number(let amount) = next { LabeledContent("Stima mese successivo", value: amount.euro) }
                Button("Salva stima") { Task { await saveEstimate() } }.disabled(saving || store.busy || Input.cents(estimate) == nil)
            }
            Section("Registra pagamento") {
                TextField("Importo €", text: $amount).keyboardType(.decimalPad)
                DatePicker("Data", selection: $date, in: ...Date(), displayedComponents: .date)
                Stepper("Mesi coperti: \(months)", value: $months, in: 1...12)
                Button("Registra") { Task { await pay() } }.disabled(saving || store.busy || Input.cents(amount) == nil)
            }
            if let error { Text(error).foregroundStyle(.red) }
        }.navigationTitle(record.text("name")).toolbar { DoneButton() }.onAppear { estimate = String(record.amount("estimate")) }
    }
    private func saveEstimate() async {
        guard let cents = Input.cents(estimate) else { return }; saving = true; defer { saving = false }
        do { try await store.perform("saveEstimate", args: [.string(record.text("name")), .number(Double(cents) / 100)]); dismiss() } catch { self.error = error.localizedDescription }
    }
    private func pay() async {
        guard let cents = Input.cents(amount) else { return }; saving = true; defer { saving = false }
        do {
            // saveTransaction provides requestId idempotency and durable offline storage.
            try await store.perform("saveTransaction", ["requestId": .string(requestID), "type": .string("Spesa"), "name": .string(record.text("name")), "category": .string(record.text("name")), "account": .string("Trade Republic"), "date": .string(CivilDate.day(date)), "months": .int(months), "amount": .number(Double(cents) / 100), "budgetTreatment": .string("auto")]); dismiss()
        } catch { self.error = error.localizedDescription }
    }
}
struct PlanningEditor: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    @State private var goal = ""
    @State private var working = false
    @State private var error: String?
    private var emergency: Double? {
        if goal.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return 0 }
        guard let n = Double(goal.replacingOccurrences(of: ",", with: ".")), n.isFinite, n >= 0, n <= 1_000_000 else { return nil }
        return n
    }
    private var progress: NativeSavingsProgress {
        NativeSavingsProgress(summary: store.summary, planning: ["goal": .number(emergency ?? 0)])
    }
    var body: some View {
        Form {
            Section("Fondo di emergenza") {
                TextField("Fondo emergenza €", text: $goal).keyboardType(.decimalPad)
                Text("È una parte del patrimonio, non una spesa aggiuntiva.").font(.caption).foregroundStyle(Color.secondary)
            }
            Section("Prossimo obiettivo") {
                LabeledContent("Traguardo successivo", value: progress.target.euro)
                LabeledContent("Da risparmiare", value: progress.missing.euro)
                LabeledContent("Mesi fino a dicembre", value: String(progress.months))
                LabeledContent("Risparmio mensile necessario", value: progress.monthly.euro)
                Text("Il prossimo traguardo avanza ogni 5.000 €. Il risparmio mensile è la cifra mancante divisa per i mesi rimanenti, incluso questo.").font(.caption).foregroundStyle(Color.secondary)
            }
            if let error { Text(error).foregroundStyle(.red) }
        }.navigationTitle("Obiettivo e fondo").navigationBarTitleDisplayMode(.inline).toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() }.disabled(working) }
            ToolbarItem(placement: .confirmationAction) { Button("Salva") { Task { await save() } }.disabled(emergency == nil || progress.monthly > 100000 || working || store.busy) }
        }.onAppear { let p = store.finance.record("planning"); goal = p["goal"] == nil || p["goal"] == .null ? "" : String(p.amount("goal")) }
    }
    private func save() async {
        guard let emergency else { return }; working = true; defer { working = false }
        do { try await store.perform("savePlanningSettings", args: [.number(emergency), .number(progress.monthly)]); dismiss() }
        catch { self.error = error.localizedDescription }
    }
}
