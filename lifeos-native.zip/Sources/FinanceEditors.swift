import SwiftUI

struct ExtraEditor: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    let record: Record
    @State private var detail: Record = [:]
    @State private var name = ""
    @State private var amount = ""
    @State private var start = Date()
    @State private var end = Date()
    @State private var annual = false
    @State private var status = "Programmato"
    @State private var note = ""
    @State private var payment = ""
    @State private var paymentDate = Date()
    @State private var movement = 0
    @State private var linkAmount = ""
    @State private var candidates: [Record] = []
    @State private var candidateMonth = Date()
    @State private var loaded = false
    @State private var saving = false
    @State private var error: String?
    @State private var requestID = UUID().uuidString
    @State private var confirmCancel = false
    @State private var confirmDelete = false
    private var cycleID: Int { record.integer("cycle_id") }
    private var editing: Bool { cycleID > 0 }
    private var monthCount: Int {
        let a = CivilDate.calendar.dateComponents([.year, .month], from: start), b = CivilDate.calendar.dateComponents([.year, .month], from: end)
        return ((b.year ?? 0) - (a.year ?? 0)) * 12 + (b.month ?? 0) - (a.month ?? 0) + 1
    }
    var body: some View {
        Form {
            Section("Piano") {
                TextField("Nome", text: $name)
                TextField("Totale €", text: $amount).keyboardType(.decimalPad)
                DatePicker("Primo mese", selection: $start, displayedComponents: .date).disabled(editing && annual)
                DatePicker("Ultimo mese", selection: $end, displayedComponents: .date).disabled(annual)
                if !editing { Toggle("Ripeti ogni anno", isOn: $annual); Picker("Stato", selection: $status) { Text("Programmato").tag("Programmato"); Text("Previsto").tag("Previsto") } }
                else { LabeledContent("Stato", value: detail.text("status", fallback: record.text("status"))) }
                LabeledContent("Conto", value: detail.text("account", fallback: "Trade Republic"))
                TextField("Note", text: $note, axis: .vertical)
            }
            Section("Quote") {
                if let cents = Input.cents(amount), !NativeValidation.shares(cents: cents, months: monthCount).isEmpty {
                    let shares = NativeValidation.shares(cents: cents, months: monthCount)
                    LabeledContent("Durata", value: "\(monthCount) mesi")
                    LabeledContent("Quota", value: (Double(shares[0]) / 100).euro)
                    Text("I centesimi residui sono distribuiti sui primi mesi. Le quote non sono nuove uscite bancarie.").font(.caption).foregroundStyle(Color.secondary)
                } else { Text("Scegli un periodo da uno a sessanta mesi.").foregroundStyle(Color.secondary) }
            }
            if editing && detail.text("kind", fallback: record.text("kind")) == "expense" && !["Pagato", "Annullato"].contains(detail.text("status", fallback: record.text("status"))) {
                Section("Registra pagamento") {
                    TextField("Importo pagato €", text: $payment).keyboardType(.decimalPad)
                    DatePicker("Data del pagamento", selection: $paymentDate, in: ...Date(), displayedComponents: .date)
                    Button("Registra la spesa e collega il piano") {
                        guard let cents = Input.cents(payment) else { return }
                        Task { await action("recordExtraPayment", ["cycleId": .int(cycleID), "amount": .number(Double(cents) / 100), "date": .string(CivilDate.day(paymentDate)), "account": .string("Trade Republic"), "name": .string(name)]) }
                    }.disabled(Input.cents(payment) == nil || !loaded || saving || store.busy)
                }
            }
            if editing && !["Pagato", "Annullato"].contains(detail.text("status", fallback: record.text("status"))) {
                Section("Collega movimento esistente") {
                    DatePicker("Mese del movimento", selection: $candidateMonth, displayedComponents: .date)
                    Button("Carica movimenti del mese") { Task { await loadCandidates() } }.disabled(store.busy || saving)
                    Picker("Movimento", selection: $movement) {
                        Text("Seleziona").tag(0)
                        ForEach(candidates.map { DisplayRecord($0, key: "row") }) { item in Text(item.value.text("name") + " · " + abs(item.value.amount("amount")).euro).tag(item.value.integer("row")) }
                    }
                    TextField("Importo attribuito €", text: $linkAmount).keyboardType(.decimalPad)
                    Button("Collega senza creare una nuova spesa") {
                        guard let cents = Input.cents(linkAmount) else { return }
                        Task { await action("linkExtraMovement", ["cycleId": .int(cycleID), "movementId": .int(movement), "amount": .number(Double(cents) / 100)]) }
                    }.disabled(movement == 0 || Input.cents(linkAmount) == nil || !loaded || saving || store.busy)
                }
            }
            if editing {
                Section("Pagamenti collegati") {
                    ForEach(store.state.plan.records("links").filter { $0.integer("cycle_id") == cycleID }.enumerated().map { IndexedRecord(index: $0.offset, value: $0.element) }) { item in
                        HStack { Text("Movimento \(item.value.integer("movement_source_row"))"); Spacer(); MoneyText(amount: item.value.amount("attributed_cents") / 100) }
                        Button("Scollega movimento \(item.value.integer("movement_source_row"))", role: .destructive) { Task { await action("unlinkExtraMovement", ["cycleId": .int(cycleID), "movementId": .int(item.value.integer("movement_source_row"))]) } }.disabled(saving || store.busy)
                    }
                }
                Section {
                    Button("Annulla piano", role: .destructive) { confirmCancel = true }
                    if detail.text("status", fallback: record.text("status")) == "Annullato" { Button("Elimina piano", role: .destructive) { confirmDelete = true } }
                }.disabled(!loaded || saving || store.busy)
            }
            if let error { Text(error).foregroundStyle(.red) }
        }.navigationTitle(editing ? "Straordinaria" : "Nuova straordinaria").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() }.disabled(saving) }
            ToolbarItem(placement: .confirmationAction) { Button("Salva") { Task { await save() } }.disabled(saving || store.busy || !loaded || Input.cents(amount) == nil || name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
        }
        .onChange(of: annual) { _, value in if value { end = CivilDate.calendar.date(byAdding: .month, value: 11, to: start) ?? start } }
        .onChange(of: start) { _, value in if annual && !editing { end = CivilDate.calendar.date(byAdding: .month, value: 11, to: value) ?? value } }
        .confirmationDialog("Annullare il piano? I movimenti bancari rimangono nello storico.", isPresented: $confirmCancel, titleVisibility: .visible) { Button("Annulla piano", role: .destructive) { Task { await action("cancelExtraCycle", ["cycleId": .int(cycleID)]) } } }
        .confirmationDialog("Eliminare definitivamente il piano annullato?", isPresented: $confirmDelete, titleVisibility: .visible) { Button("Elimina piano", role: .destructive) { Task { await action("deleteExtraPlan", ["cycleId": .int(cycleID)]) } } }
        .task {
            do {
                if editing && !store.isDemo { detail = try await store.read("getExtraCycleDetail", args: [.int(cycleID)]).object }
                else { detail = record }
                name = detail.text("name"); amount = editing ? String(format: "%.2f", detail.amount("total_cents") / 100) : ""
                start = CivilDate.date(detail.text("start_month", fallback: store.financeMonth) + "-01")
                end = CivilDate.date(detail.text("end_month", fallback: store.financeMonth) + "-01")
                annual = detail.text("repeat") == "Annuale"; note = detail.text("notes"); loaded = true
                candidates = store.transactions.filter { $0.amount("amount") < 0 }; payment = amount; linkAmount = amount
            } catch { self.error = error.localizedDescription }
        }
    }
    private func save() async {
        guard let cents = Input.cents(amount) else { return }
        let payload: Record = ["cycleId": .int(cycleID), "requestId": .string(requestID), "name": .string(name), "amount": .number(Double(cents) / 100), "month": .string(CivilDate.month(start)), "endMonth": .string(CivilDate.month(end)), "account": .string(detail.text("account", fallback: "Trade Republic")), "repeat": .string(annual ? "Annuale" : "No"), "status": .string(status), "note": .string(note)]
        await action(editing ? "updateExtraPlan" : "saveExtra", payload)
    }
    private func action(_ method: String, _ payload: Record) async {
        saving = true; defer { saving = false }
        do { try await store.perform(method, payload); dismiss() } catch { self.error = error.localizedDescription }
    }
    private func loadCandidates() async {
        saving = true; defer { saving = false }
        do {
            if store.isDemo { candidates = store.finance.records("transactions").filter { $0.text("date").hasPrefix(CivilDate.month(candidateMonth)) && $0.amount("amount") < 0 } }
            else {
                let parts = CivilDate.calendar.dateComponents([.year, .month], from: candidateMonth)
                let value = try await store.read("getFinanceOverview", args: [.int(parts.year!), .int(parts.month!)])
                candidates = value.object.records("transactions").filter { $0.amount("amount") < 0 }
            }
        } catch { self.error = error.localizedDescription }
    }
}
struct RecurringEditor: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    let record: Record
    @State private var amount = ""
    @State private var estimate = ""
    @State private var date = Date()
    @State private var months = 1
    @State private var saving = false
    @State private var error: String?
    @State private var requestID = UUID().uuidString
    var body: some View {
        Form {
            Section("Stima mensile") {
                TextField("Stima €", text: $estimate).keyboardType(.decimalPad)
                if let next = record["nextEstimate"], case .number(let amount) = next { LabeledContent("Stima mese successivo", value: amount.euro) }
                Button("Salva stima") { Task { await saveEstimate() } }.disabled(saving || store.busy || Input.cents(estimate) == nil)
            }
            Section("Registra pagamento") {
                TextField("Importo €", text: $amount).keyboardType(.decimalPad)
                DatePicker("Data", selection: $date, in: ...Date(), displayedComponents: .date)
                Stepper("Mesi coperti: \(months)", value: $months, in: 1...12)
                Button("Registra") { Task { await pay() } }.disabled(saving || store.busy || Input.cents(amount) == nil)
            }
            if let error { Text(error).foregroundStyle(.red) }
        }.navigationTitle(record.text("name")).toolbar { DoneButton() }.onAppear { estimate = String(record.amount("estimate")) }
    }
    private func saveEstimate() async {
        guard let cents = Input.cents(estimate) else { return }; saving = true; defer { saving = false }
        do { try await store.perform("saveEstimate", args: [.string(record.text("name")), .number(Double(cents) / 100)]); dismiss() } catch { self.error = error.localizedDescription }
    }
    private func pay() async {
        guard let cents = Input.cents(amount) else { return }; saving = true; defer { saving = false }
        do {
            // saveTransaction provides requestId idempotency and durable offline storage.
            try await store.perform("saveTransaction", ["requestId": .string(requestID), "type": .string("Spesa"), "name": .string(record.text("name")), "category": .string(record.text("name")), "account": .string("Trade Republic"), "date": .string(CivilDate.day(date)), "months": .int(months), "amount": .number(Double(cents) / 100), "budgetTreatment": .string("auto")]); dismiss()
        } catch { self.error = error.localizedDescription }
    }
}
struct PlanningEditor: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    @State private var goal = ""
    @State private var saving = ""
    @State private var projection: Record = [:]
    @State private var working = false
    @State private var error: String?
    private func number(_ text: String) -> Double? {
        guard let n = Double(text.replacingOccurrences(of: ",", with: ".")), n.isFinite, n >= 0 else { return nil }; return n
    }
    private var args: [JSONValue]? {
        guard let monthly = number(saving), monthly <= 100000 else { return nil }
        if goal.isEmpty { return [.null, .number(monthly)] }
        guard let target = number(goal), target <= 1000000 else { return nil }
        return [.number(target), .number(monthly)]
    }
    var body: some View {
        Form {
            Section("Fondo di emergenza") { TextField("Obiettivo € (facoltativo)", text: $goal).keyboardType(.decimalPad); TextField("Risparmio mensile €", text: $saving).keyboardType(.decimalPad) }
            Section {
                Button("Simula senza salvare") { Task { await simulate() } }.disabled(args == nil || working || store.busy)
                if !projection.isEmpty { LabeledContent("Fine anno", value: projection.amount("projection").euro); LabeledContent("Da raggiungere", value: projection.amount("missing").euro) }
                Text("La simulazione non cambia movimenti, saldo o impegni.").font(.caption).foregroundStyle(Color.secondary)
            }
            if let error { Text(error).foregroundStyle(.red) }
        }.navigationTitle("Fondo e fine anno").toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("Salva") { Task { await save() } }.disabled(args == nil || working || store.busy) }
        }.onAppear { let p = store.finance.record("planning"); goal = p["goal"] == .null ? "" : String(p.amount("goal")); saving = String(p.amount("monthlySaving")) }
    }
    private func simulate() async {
        guard let args else { return }; working = true; defer { working = false }
        do {
            if store.isDemo { let balance = store.summary.amount("budget"), months = 12 - CivilDate.calendar.component(.month, from: Date()); projection = ["projection": .number(balance + args[1].number * Double(months)), "missing": .number(max(0, args[0].number - balance))] }
            else { projection = try await store.read("getPlanningProjection", args: args).object }
        } catch { self.error = error.localizedDescription }
    }
    private func save() async {
        guard let args else { return }; working = true; defer { working = false }
        do { try await store.perform("savePlanningSettings", args: args); dismiss() } catch { self.error = error.localizedDescription }
    }
}
