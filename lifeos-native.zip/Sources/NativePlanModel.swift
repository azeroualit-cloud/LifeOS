import Foundation

enum NativePlanKind: String, CaseIterable, Identifiable {
    case advance, goal, fund, fixed, estimated, recovery
    var id: String { rawValue }
    var title: String {
        switch self {
        case .advance: return "Anticipa budget"
        case .goal: return "Obiettivo finito"
        case .fund: return "Fondo senza scadenza"
        case .fixed: return "Spesa ricorrente fissa"
        case .estimated: return "Utenza con quota stimata"
        case .recovery: return "Rateizza una spesa"
        }
    }
    var finite: Bool { [.advance, .goal, .recovery].contains(self) }
    var payable: Bool { ![.advance, .recovery].contains(self) }
}
struct NativePlanDraft {
    var kind: NativePlanKind = .goal
    var name = ""
    var category = "Altro"
    var amount = ""
    var startMonth = CivilDate.month()
    var endMonth = CivilDate.month()
    var beneficiaryMonth = CivilDate.month()
    var paymentDate = CivilDate.day()
    var intervalMonths = 1
    func payload(requestID: String, today: String = CivilDate.day()) throws -> Record {
        let title = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !title.isEmpty, title.count <= 120 else { throw Message(text: "Inserisci un nome di massimo 120 caratteri.") }
        guard let cents = Input.cents(amount), cents <= 100_000_000 else { throw Message(text: "Importo non valido.") }
        guard NativePlanRules.validMonth(startMonth), startMonth >= String(today.prefix(7)), (1...12).contains(intervalMonths) else { throw Message(text: "Scegli un primo mese aperto o futuro e una periodicità valida.") }
        if kind.finite { _ = try NativePlanRules.months(startMonth, endMonth) }
        if kind == .advance {
            guard NativePlanRules.validMonth(beneficiaryMonth), beneficiaryMonth >= String(today.prefix(7)), beneficiaryMonth < startMonth else { throw Message(text: "Il mese beneficiario deve precedere i mesi di recupero ed essere aperto o futuro.") }
        }
        if kind == .recovery {
            guard paymentDate <= today, CivilDate.day(CivilDate.date(paymentDate)) == paymentDate, startMonth >= String(paymentDate.prefix(7)) else { throw Message(text: "Scegli una data di pagamento valida e non futura. Il recupero non può precederla.") }
        }
        var result: Record = ["requestId": .string(requestID), "kind": .string(kind.rawValue), "name": .string(title), "category": .string(category), "amountCents": .int(cents),
            "startMonth": .string(startMonth), "intervalMonths": .int(intervalMonths)]
        if kind.finite { result["endMonth"] = .string(endMonth) }
        if kind == .advance { result["beneficiaryMonth"] = .string(beneficiaryMonth) }
        if kind == .recovery { result["paymentDate"] = .string(paymentDate) }
        return result
    }
    func preview(today: String = CivilDate.day()) throws -> [Record] {
        let plan = try payload(requestID: "preview-only", today: today)
        let range = kind.finite ? try NativePlanRules.months(startMonth, endMonth) : (0..<3).map { NativePlanRules.adding($0, to: startMonth) }
        let dates = Array(Set(range + (kind == .advance ? [beneficiaryMonth] : []))).sorted()
        return dates.map { ["month": .string($0), "deltaCents": .int(-NativePlanRules.contribution(plan, month: $0))] }
    }
}
enum NativePlanRules {
    static func validMonth(_ value: String) -> Bool { value.range(of: #"^20\d\d-(0[1-9]|1[0-2])$"#, options: .regularExpression) != nil }
    static func adding(_ count: Int, to month: String) -> String { String(CivilDate.adding(count, to: month + "-01", component: .month).prefix(7)) }
    static func months(_ first: String, _ last: String) throws -> [String] {
        guard validMonth(first), validMonth(last), first <= last else { throw Message(text: "L’ultimo mese deve essere uguale o successivo al primo.") }
        let count = (Int(last.prefix(4))! - Int(first.prefix(4))!) * 12 + Int(last.suffix(2))! - Int(first.suffix(2))! + 1
        guard count <= 240 else { throw Message(text: "Per un piano senza termine scegli Fondo senza scadenza.") }
        return (0..<count).map { adding($0, to: first) }
    }
    static func contribution(_ plan: Record, month: String) -> Int {
        guard let kind = NativePlanKind(rawValue: plan.text("kind")), validMonth(month), !["cancelled", "pendingPayment"].contains(plan.text("status")) else { return 0 }
        let cents = plan.integer("amountCents"), start = plan.text("startMonth"), end = plan.text("endMonth")
        guard cents > 0, validMonth(start) else { return 0 }
        if kind == .advance, month == plan.text("beneficiaryMonth") { return -cents }
        guard month >= start, end.isEmpty || month <= end else { return 0 }
        for key in ["stopAfter", "closedMonth"] { if !plan.text(key).isEmpty, month > plan.text(key) { return 0 } }
        if kind.finite {
            guard let range = try? months(start, end), let index = range.firstIndex(of: month) else { return 0 }
            return cents / range.count + (index < cents % range.count ? 1 : 0)
        }
        if kind == .fixed {
            let interval = max(1, min(12, plan.integer("intervalMonths")))
            let offset = (Int(month.prefix(4))! - Int(start.prefix(4))!) * 12 + Int(month.suffix(2))! - Int(start.suffix(2))!
            return cents / interval + (offset % interval < cents % interval ? 1 : 0)
        }
        var rate = cents
        for row in plan.records("rateChanges").sorted(by: { $0.text("fromMonth") < $1.text("fromMonth") }) where row.text("fromMonth") <= month { rate = row.integer("amountCents") }
        return rate
    }
    static func stateTitle(_ value: String) -> String {
        switch value { case "active": return "In corso"; case "closed": return "Concluso"; case "stopped": return "Interrotto"; case "cancelled": return "Annullato"; case "pendingPayment": return "Pagamento da completare"; default: return value }
    }
}
