import SwiftUI

struct NativeSignInScreen: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    @FocusState private var focused: Bool
    @State private var password = ""
    @State private var saving = false
    @State private var message: String?
    var onAuthenticated: () -> Void
    var body: some View {
        Form {
            Section {
                VStack(alignment: .leading, spacing: 14) {
                    Image(systemName: "lock.shield").font(.system(size: 38, weight: .light)).foregroundStyle(NativeDesign.accent)
                    Text("Il tuo Life OS").font(.system(.title, design: .rounded, weight: .bold))
                    Text("Accedi per ritrovare gli stessi dati nell’app e sul sito.").font(.subheadline).foregroundStyle(Color.secondary)
                }.padding(.vertical, 18)
            }.listRowBackground(Color.clear)
            Section {
                SecureField("Password", text: $password).textContentType(.password).focused($focused).submitLabel(.go)
                    .onSubmit { Task { await submit() } }
                Button { Task { await submit() } } label: {
                    HStack { Text("Accedi").fontWeight(.semibold); Spacer(); if saving { ProgressView() } else { Image(systemName: "arrow.right") } }.frame(minHeight: 36)
                }.disabled(password.isEmpty || saving)
            } footer: { Text("Usa la password che hai impostato per l’app. La sessione viene protetta nel Portachiavi di iPhone.") }
            if let message { Section { Label(message, systemImage: "exclamationmark.circle").font(.callout).foregroundStyle(.red) } }
        }.modifier(NativeListAppearance()).navigationTitle("Accesso").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() }.disabled(saving) } }
            .interactiveDismissDisabled(saving)
    }
    private func submit() async {
        guard !saving, !password.isEmpty else { return }
        saving = true; message = nil; focused = false; defer { saving = false }
        do { try await store.signIn(password: password); password = ""; onAuthenticated() }
        catch { message = NativeSyncPolicy.isTransient(error) ? "Connessione non disponibile. Riprova quando torna la rete." : error.localizedDescription }
    }
}
