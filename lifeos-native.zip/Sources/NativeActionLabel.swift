import SwiftUI

struct NativeActionLabel: View {
    let title: String
    let symbol: String
    var body: some View {
        VStack(spacing: NativeDesign.Space.small) {
            Image(systemName: symbol).font(.title2.weight(.regular))
                .frame(width: NativeDesign.Layout.primaryAction, height: NativeDesign.Layout.primaryAction)
                .background(NativeDesign.inset, in: Circle()).accessibilityHidden(true)
            Text(title).font(.subheadline).fixedSize(horizontal: false, vertical: true)
        }.frame(maxWidth: .infinity).contentShape(Rectangle())
    }
}
