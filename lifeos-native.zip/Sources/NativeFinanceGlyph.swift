import SwiftUI

/// Small vector glyphs; the surrounding surface uses Apple's material, not rendered glass artwork.
enum NativeFinanceAction { case budget, extra, expense }
struct NativeFinanceGlyph: Shape {
    let action: NativeFinanceAction
    func path(in rect: CGRect) -> Path {
        var p = Path()
        func point(_ x: Double, _ y: Double) -> CGPoint {
            CGPoint(x: rect.minX + rect.width * x / 24, y: rect.minY + rect.height * y / 24)
        }
        func line(_ x: Double, _ y: Double, _ a: Double, _ b: Double) {
            p.move(to: point(x, y)); p.addLine(to: point(a, b))
        }
        switch action {
        case .budget:
            for i in 0..<4 {
                var segment = Path()
                segment.addArc(center: point(12, 12), radius: rect.width * 0.37,
                               startAngle: .degrees(Double(i) * 90 - 82), endAngle: .degrees(Double(i) * 90 - 12), clockwise: false)
                p.addPath(segment)
            }
        case .extra:
            for y in [4.0, 9.0, 14.0] {
                p.addEllipse(in: CGRect(x: point(4, y).x, y: point(4, y).y, width: rect.width * 16 / 24, height: rect.height * 6 / 24))
            }
            line(4, 7, 4, 17); line(20, 7, 20, 17)
        case .expense:
            p.move(to: point(6, 3))
            for (x, y) in [(18.0,3.0),(18,21),(15,19),(12,21),(9,19),(6,21)] { p.addLine(to: point(x,y)) }
            p.closeSubpath()
            line(9, 8, 15, 8); line(9, 12, 15, 12); line(9, 16, 12, 16)
        }
        return p
    }
}
struct NativeFinanceGlass: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular.tint(.black.opacity(0.6)).interactive(), in: Circle())
        } else {
            content.background(.regularMaterial, in: Circle()).background(.black.opacity(0.6), in: Circle())
        }
    }
}
