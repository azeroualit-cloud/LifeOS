import SwiftUI

struct NativePlanPaymentDetail: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    let planID: String
    let paymentID: String
    var onDeleted: (() -> Void)? = nil
    @State private var confirmDelete = false
    @State private var deleting = false
    @State private var error: String?
    @State private var requestID = UUID().uuidString
    private var payment: Record { store.finance.record("plansV2").records("payments").first { $0.text("id") == paymentID } ?? [:] }
    var body: some View {
        List {
            if !payment.isEmpty {
                Section {
                    LabeledContent("Importo", value: (Double(payment.integer("amountCents")) / 100).euro)
                    LabeledContent("Data", value: CivilDate.label(payment.text("date")))
                    Text("Pagamento collegato al piano. Puoi eliminarlo anche se il piano è interrotto.").font(.caption).foregroundStyle(NativeDesign.secondary)
                }
                Section {
                    Button(payment.text("status") == "deleting" ? "Completa l’eliminazione" : "Elimina pagamento e movimento", role: .destructive) {
                        confirmDelete = true
                    }.disabled(deleting || store.busy || payment.text("status") == "pending").accessibilityIdentifier("plan-payment-delete")
                }
            } else { Text("Pagamento non disponibile. Aggiorna i piani.") }
            if let error { NativeInlineMessage(text: error) }
        }.modifier(NativeListAppearance()).navigationTitle("Pagamento del piano").navigationBarTitleDisplayMode(.inline)
            .task { await store.loadFinancePlans() }
            .confirmationDialog("Eliminare questo pagamento e il movimento collegato? Il saldo verrà aggiornato. Il piano interrotto resterà interrotto; un obiettivo chiuso tornerà aperto.", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Elimina pagamento", role: .destructive) { Task { await remove() } }
            }
    }
    @MainActor private func remove() async {
        guard !deleting else { return }
        deleting = true; defer { deleting = false }
        do {
            if payment.text("status") == "deleting" {
                try await store.perform("resumeFinancePlanPayment", ["paymentId": .string(paymentID)])
            } else {
                try await store.perform("deleteFinancePlanPayment", ["requestId": .string(requestID), "planId": .string(planID), "paymentId": .string(paymentID)])
            }
            await store.loadFinancePlans()
            if let onDeleted { onDeleted() } else { dismiss() }
        } catch { self.error = error.localizedDescription }
    }
}
