import Foundation
import SwiftUI
import WebKit

@MainActor final class Store: ObservableObject {
    @Published private(set) var archive = Archive()
    @Published var error: String?
    @Published private(set) var busy = false
    private var storage: Storage?
    private let session: URLSession = {
        let c = URLSessionConfiguration.ephemeral
        c.timeoutIntervalForRequest = 20
        return URLSession(configuration: c)
    }()
    // The probe is bound to one configured clone. Never changes endpoint with a queued write.
    @Published private(set) var server: URL?
    init() {
        do { let s = try Storage(); archive = try s.load(); storage = s }
        catch { self.error = error.localizedDescription }
        if let raw = UserDefaults.standard.string(forKey: "test-server") { server = URL(string: raw) }
    }
    func configure(_ raw: String) throws {
        guard !busy, archive.queue.isEmpty, archive.confirmed.isEmpty else {
            throw Message(text: "Sincronizza le spese prima di cambiare server.")
        }
        guard let u = URL(string: raw.trimmingCharacters(in: .whitespacesAndNewlines)), u.scheme == "https",
              u.host != nil, u.user == nil, u.password == nil, u.query == nil, u.fragment == nil,
              u.path.isEmpty || u.path == "/" else { throw Message(text: "Inserisci l'origine HTTPS della copia di test.") }
        let clean = URL(string: "https://\(u.host!)" + (u.port.map { ":\($0)" } ?? ""))!
        if clean != server {
            try persist(Archive()); server = clean
            session.configuration.httpCookieStorage?.removeCookies(since: .distantPast)
            UserDefaults.standard.set(clean.absoluteString, forKey: "test-server")
        }
    }
    func add(_ expense: Expense) throws {
        var next = archive; next.queue.append(expense)
        try persist(next)
    }
    func importSnapshot(_ data: Data) throws {
        guard server == nil else { throw Message(text: "L'importazione è disponibile solo senza server configurato.") }
        let finance = try JSONDecoder().decode(Finance.self, from: data)
        guard [finance.summary.budget, finance.summary.committedCurrent, finance.summary.remainingFree].allSatisfy(\.isFinite) else {
            throw Message(text: "Importi non validi.")
        }
        var next = archive; next.finance = finance; next.refreshedAt = Date(); try persist(next)
    }
    func acceptCookies(_ cookies: [HTTPCookie]) {
        guard let server else { return }
        // URLSession's cookie policy selects cookies by domain/path/expiry for each request.
        let matching = cookies.filter { cookie in
            let domain = cookie.domain.hasPrefix(".") ? String(cookie.domain.dropFirst()) : cookie.domain
            return server.host == domain || (cookie.domain.hasPrefix(".") && server.host!.hasSuffix("." + domain))
        }
        session.configuration.httpCookieStorage?.setCookies(matching, for: server, mainDocumentURL: server)
    }
    func sync() async {
        guard let server, !busy else { return }
        busy = true; error = nil; defer { busy = false }
        do {
            // Refresh first: authentication/schema errors cannot consume the local queue.
            try await refresh(server)
            while let expense = archive.queue.first {
                let accepted: Bool = try await call(server, "saveTransaction", [try JSONEncoder().encode(expense)])
                guard accepted else { throw Message(text: "Spesa non confermata dal server.") }
                var next = archive
                next.queue.removeFirst(); next.confirmed.append(expense)
                try persist(next) // Same UUID survives network timeout or a local save failure.
            }
            try await refresh(server)
            var next = archive; next.confirmed = []; try persist(next)
        } catch { self.error = error.localizedDescription }
    }
    private func refresh(_ server: URL) async throws {
        var calendar = Calendar(identifier: .gregorian); calendar.timeZone = TimeZone(identifier: "Europe/Rome")!
        let date = calendar.dateComponents([.year, .month], from: Date())
        let finance: Finance = try await call(server, "getFinanceOverview", [Data(String(date.year!).utf8), Data(String(date.month!).utf8)])
        var next = archive; next.finance = finance; next.refreshedAt = Date(); try persist(next)
    }
    private func call<T: Decodable>(_ server: URL, _ method: String, _ args: [Data]) async throws -> T {
        var req = URLRequest(url: server.appendingPathComponent("api/" + method))
        req.httpMethod = "POST"; req.setValue(server.absoluteString, forHTTPHeaderField: "Origin")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = Data(("[" + args.map { String(decoding: $0, as: UTF8.self) }.joined(separator: ",") + "]").utf8)
        let (data, response) = try await session.data(for: req)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode),
              http.url?.host == server.host, http.mimeType == "application/json" else {
            throw Message(text: "Accesso richiesto o server non disponibile. Accedi alla copia di test.")
        }
        return try JSONDecoder().decode(T.self, from: data)
    }
    private func persist(_ next: Archive) throws {
        guard let storage else { throw Message(text: "Archivio locale non disponibile.") }
        try storage.save(next); archive = next
    }
}

// Only the sign-in screen is web based; finance screens and forms use SwiftUI.
struct Login: UIViewRepresentable {
    let url: URL
    let onCookies: ([HTTPCookie]) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(onCookies) }
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration(); config.websiteDataStore = .nonPersistent()
        let view = WKWebView(frame: .zero, configuration: config)
        view.navigationDelegate = context.coordinator; view.load(URLRequest(url: url)); return view
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
    final class Coordinator: NSObject, WKNavigationDelegate {
        let callback: ([HTTPCookie]) -> Void
        init(_ callback: @escaping ([HTTPCookie]) -> Void) { self.callback = callback }
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            webView.configuration.websiteDataStore.httpCookieStore.getAllCookies(callback)
        }
    }
}
