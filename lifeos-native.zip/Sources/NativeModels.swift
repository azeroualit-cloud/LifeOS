import Foundation

// Preserve unknown API fields: the Worker remains the authority for money and planning.
enum JSONValue: Codable, Equatable {
    case object([String: JSONValue]), array([JSONValue]), string(String), number(Double), bool(Bool), null
    init(from decoder: Decoder) throws {
        let c = try decoder.singleValueContainer()
        if c.decodeNil() { self = .null }
        else if let v = try? c.decode(Bool.self) { self = .bool(v) }
        else if let v = try? c.decode(Double.self) { self = .number(v) }
        else if let v = try? c.decode(String.self) { self = .string(v) }
        else if let v = try? c.decode([String: JSONValue].self) { self = .object(v) }
        else { self = .array(try c.decode([JSONValue].self)) }
    }
    func encode(to encoder: Encoder) throws {
        var c = encoder.singleValueContainer()
        switch self {
        case .object(let v): try c.encode(v)
        case .array(let v): try c.encode(v)
        case .string(let v): try c.encode(v)
        case .number(let v): try c.encode(v)
        case .bool(let v): try c.encode(v)
        case .null: try c.encodeNil()
        }
    }
    var object: Record { if case .object(let v) = self { return v }; return [:] }
    var array: [JSONValue] { if case .array(let v) = self { return v }; return [] }
    var string: String { if case .string(let v) = self { return v }; return "" }
    var number: Double { if case .number(let v) = self { return v }; return 0 }
    var bool: Bool { if case .bool(let v) = self { return v }; return number != 0 }
    static func int(_ n: Int) -> JSONValue { .number(Double(n)) }
}
typealias Record = [String: JSONValue]
extension Dictionary where Key == String, Value == JSONValue {
    func text(_ key: String, fallback: String = "") -> String { self[key]?.string.isEmpty == false ? self[key]!.string : fallback }
    func amount(_ key: String) -> Double { self[key]?.number ?? 0 }
    func integer(_ key: String) -> Int {
        let n = amount(key)
        guard n.isFinite, n >= Double(Int.min), n < Double(Int.max) else { return 0 }
        return Int(n)
    }
    func flag(_ key: String) -> Bool { self[key]?.bool ?? false }
    func record(_ key: String) -> Record { self[key]?.object ?? [:] }
    func records(_ key: String) -> [Record] { self[key]?.array.map(\.object) ?? [] }
}
struct DisplayRecord: Identifiable {
    let value: Record
    let id: String
    init(_ value: Record, key: String = "id") {
        self.value = value
        if key == "key" || key == "day" { id = value.text(key) }
        else { id = String(value.integer(key)) + (value.text("day").isEmpty ? "" : ":" + value.text("day")) }
    }
}
struct PendingWrite: Codable, Identifiable {
    let id: String
    let method: String
    let payload: Record
    var accepted = false
}
struct NativeArchive: Codable {
    var life: Record = [:]
    var finance: Record = [:]
    var plan: Record = [:]
    var pending: [PendingWrite] = []
    var demo = true
    var imported = false
    var refreshedAt: Date?
    var endpoint: String?
    var routineDay = ""
    var financeMonth = CivilDate.month()
    var calendarMonth = CivilDate.month()
}
extension NativeArchive {
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        life = try c.decode(Record.self, forKey: .life)
        finance = try c.decode(Record.self, forKey: .finance)
        plan = try c.decode(Record.self, forKey: .plan)
        pending = try c.decode([PendingWrite].self, forKey: .pending)
        demo = try c.decode(Bool.self, forKey: .demo)
        imported = try c.decode(Bool.self, forKey: .imported)
        refreshedAt = try c.decodeIfPresent(Date.self, forKey: .refreshedAt)
        endpoint = try c.decodeIfPresent(String.self, forKey: .endpoint)
        routineDay = try c.decode(String.self, forKey: .routineDay)
        financeMonth = try c.decodeIfPresent(String.self, forKey: .financeMonth) ?? CivilDate.month()
        calendarMonth = try c.decodeIfPresent(String.self, forKey: .calendarMonth) ?? CivilDate.month()
    }
}
enum CivilDate {
    static var calendar: Calendar {
        var c = Calendar(identifier: .gregorian); c.timeZone = TimeZone(identifier: "Europe/Rome")!; c.firstWeekday = 2; return c
    }
    static func day(_ date: Date = Date()) -> String { Input.day(date) }
    static func date(_ day: String) -> Date {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.timeZone = calendar.timeZone; f.dateFormat = "yyyy-MM-dd"
        return f.date(from: String(day.prefix(10))) ?? Date()
    }
    static func month(_ date: Date = Date()) -> String { String(day(date).prefix(7)) }
    static func adding(_ count: Int, to day: String, component: Calendar.Component = .day) -> String {
        self.day(calendar.date(byAdding: component, value: count, to: date(day)) ?? date(day))
    }
    static func monthTitle(_ month: String) -> String {
        let f = DateFormatter(); f.locale = Locale(identifier: "it_IT"); f.timeZone = calendar.timeZone; f.dateFormat = "MMMM yyyy"
        return f.string(from: date(month + "-01")).capitalized
    }
    static func label(_ day: String) -> String {
        let f = DateFormatter(); f.locale = Locale(identifier: "it_IT"); f.timeZone = calendar.timeZone; f.dateFormat = "EEE d MMM"
        return f.string(from: date(day))
    }
    static func grid(_ month: String) -> [String] {
        let first = date(month + "-01"), weekday = calendar.component(.weekday, from: first)
        let offset = (weekday + 5) % 7
        let count = calendar.range(of: .day, in: .month, for: first)?.count ?? 30
        let cells = ((count + offset + 6) / 7) * 7
        return (0..<cells).map { adding($0 - offset, to: day(first)) }
    }
    static func occurrenceDays(start: String, frequency: String, until: String, low: String, high: String) -> [String] {
        var result: [String] = []
        let base = date(start)
        for index in 0..<12000 {
            var current = start
            if index > 0 {
                if frequency == "none" || frequency.isEmpty { break }
                if frequency == "weekly" { current = adding(index * 7, to: start) }
                else {
                    let parts = calendar.dateComponents([.year, .month, .day], from: base)
                    let first = calendar.date(from: DateComponents(year: parts.year, month: parts.month, day: 1))!
                    let next = calendar.date(byAdding: .month, value: index * (frequency == "yearly" ? 12 : 1), to: first)!
                    let last = calendar.range(of: .day, in: .month, for: next)!.count
                    current = day(calendar.date(byAdding: .day, value: min(parts.day!, last) - 1, to: next)!)
                }
            }
            if current >= high || (!until.isEmpty && current > until) { break }
            if current >= low { result.append(current) }
        }
        return result
    }
}
enum ShiftKind: String, CaseIterable, Identifiable {
    case morning, afternoon, night, rest, holiday, erase
    var id: String { rawValue }
    var title: String { switch self { case .morning: return "Mattina"; case .afternoon: return "Pomeriggio"; case .night: return "Notte"; case .rest: return "Riposo"; case .holiday: return "Ferie"; case .erase: return "Cancella" } }
    var letter: String { switch self { case .morning: return "M"; case .afternoon: return "P"; case .night: return "N"; case .rest: return "R"; case .holiday: return "F"; case .erase: return "" } }
    var time: String { switch self { case .morning: return "06:00–14:00"; case .afternoon: return "14:00–22:00"; case .night: return "22:00–06:00"; default: return "" } }
}
enum NativeValidation {
    static func dailyBudget(_ summary: Record, day: String = CivilDate.day()) -> (days: Int, low: Double, high: Double) {
        let date = CivilDate.date(day), count = CivilDate.calendar.range(of: .day, in: .month, for: date)?.count ?? 30
        let days = max(1, count - CivilDate.calendar.component(.day, from: date) + 1)
        return (days, summary.amount("monthlyRemaining") / Double(days), (summary.amount("monthlySalary") - summary.amount("monthlySpent")) / Double(days))
    }
    static func snapshot(_ data: Data) throws -> Record {
        guard data.count <= 5_000_000 else { throw Message(text: "Il file è troppo grande.") }
        let value = try JSONDecoder().decode(JSONValue.self, from: data)
        let object = value.object, summary = object.record("summary")
        for key in ["budget", "committedCurrent", "remainingFree"] {
            guard case .number(let n)? = summary[key], n.isFinite else { throw Message(text: "Il JSON non è uno snapshot finanziario valido.") }
        }
        guard case .array(let rows)? = object["transactions"] else { throw Message(text: "Nel JSON manca l’elenco movimenti.") }
        var ids = Set<Int>()
        for row in rows {
            let r = row.object
            guard case .number(let amount)? = r["amount"], amount.isFinite,
                  r.integer("row") > 0, r.amount("row") == Double(r.integer("row")), ids.insert(r.integer("row")).inserted,
                  !r.text("name").isEmpty, r.text("date").range(of: #"^20\d\d-(0[1-9]|1[0-2])-([0-2]\d|3[01])$"#, options: .regularExpression) != nil,
                  CivilDate.day(CivilDate.date(r.text("date"))) == r.text("date") else {
                throw Message(text: "Il JSON contiene un movimento non valido.")
            }
        }
        return object
    }
    static func shares(cents: Int, months: Int) -> [Int] {
        guard cents > 0, (1...60).contains(months) else { return [] }
        return (0..<months).map { cents / months + ($0 < cents % months ? 1 : 0) }
    }
}
