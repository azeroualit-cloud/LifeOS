import Foundation

/// Own-device records from the temporary manual graph. Never writes to HealthKit.
enum NativeHealthLegacy {
    static func days(_ records: [Record], calendar: Calendar = .current) -> [HealthDay] {
        var gregorian = Calendar(identifier: .gregorian); gregorian.timeZone = calendar.timeZone
        var result: [Date: HealthDay] = [:]
        for row in records {
            let parts = row.text("day").split(separator: "-").compactMap { Int($0) }
            guard parts.count == 3, row.text("day").count == 10,
                  let date = gregorian.date(from: DateComponents(year: parts[0], month: parts[1], day: parts[2])) else { continue }
            let check = gregorian.dateComponents([.year, .month, .day], from: date)
            guard check.year == parts[0], check.month == parts[1], check.day == parts[2] else { continue }
            let day = calendar.startOfDay(for: date)
            var entry = result[day] ?? HealthDay(date: day)
            if case .number(let kg)? = row["weight_kg"], kg.isFinite, kg > 0, kg <= 500 { entry.weight = kg }
            if case .number(let kcal)? = row["calories"], kcal.isFinite, kcal >= 0, kcal <= 15000 { entry.calories = kcal }
            if entry.weight != nil || entry.calories != nil { result[day] = entry }
        }
        return result.values.sorted { $0.date < $1.date }
    }
}
