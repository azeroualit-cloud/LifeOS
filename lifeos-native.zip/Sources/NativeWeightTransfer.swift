import Foundation

/// A web link only prepares the existing editor. Saving still needs an explicit tap.
struct NativeWeightTransfer: Identifiable {
    let id: UUID
    let kilograms: Double
    let date: Date
    init(url: URL, now: Date = Date()) throws {
        guard let parts = URLComponents(url: url, resolvingAgainstBaseURL: false), parts.scheme == "lifeos",
              parts.host == "weight", ["", "/"].contains(parts.path), parts.user == nil, parts.password == nil,
              parts.port == nil, parts.fragment == nil, let items = parts.queryItems, items.count == 3,
              Set(items.map(\.name)) == Set(["id", "kg", "at"]) else { throw Message(text: "Link della pesata non valido.") }
        let fields = Dictionary(uniqueKeysWithValues: items.map { ($0.name, $0.value ?? "") })
        guard let id = UUID(uuidString: fields["id"] ?? ""), let weight = Double(fields["kg"] ?? ""),
              weight.isFinite, weight > 0, weight <= 500, let milliseconds = Double(fields["at"] ?? ""),
              milliseconds.isFinite, milliseconds >= -62_135_596_800_000,
              milliseconds <= now.timeIntervalSince1970 * 1000 else { throw Message(text: "Controlla peso e data della pesata.") }
        self.id = id; kilograms = weight; date = Date(timeIntervalSince1970: milliseconds / 1000)
    }
}
extension Notification.Name { static let lifeOSWeightSaved = Notification.Name("lifeos-weight-saved") }
