import Foundation

struct HealthDay: Identifiable, Equatable {
    let date: Date
    var weight: Double?
    var calories: Double?
    var id: Date { date }
}
struct HealthPoint: Identifiable {
    let date: Date
    let value: Double
    var id: Date { date }
}
struct HealthEstimate {
    let tdee: Double
    let averageIntake: Double
    let startWeight: Double
    let lastDate: Date
    let days: Int
}

/// Transparent engineering approximation, not the full validated NIH model.
/// Energy balance: intake - change in stored energy; 7,700 kcal/kg is an
/// approximation. Forecast expenditure changes by 22 kcal/day per kg changed,
/// following the population-level relationship described by Hall et al. (2011).
/// Neither parameter identifies individual body composition or water changes.
enum NativeHealthMath {
    static let energyPerKG = 7700.0
    static let expenditurePerKG = 22.0
    static func trend(_ days: [HealthDay], calendar: Calendar = .current) -> [HealthPoint] {
        let weights = days.filter { ($0.weight ?? 0) > 0 && ($0.weight?.isFinite ?? false) }.sorted { $0.date < $1.date }
        return weights.map { day in
            let start = calendar.date(byAdding: .day, value: -6, to: day.date)!
            let window = weights.filter { $0.date >= start && $0.date <= day.date }.compactMap(\.weight).sorted()
            let middle = window.count / 2
            let median = window.count % 2 == 0 ? (window[middle - 1] + window[middle]) / 2 : window[middle]
            return HealthPoint(date: day.date, value: median)
        }
    }
    static func estimate(_ days: [HealthDay], now: Date = Date(), calendar: Calendar = .current) -> HealthEstimate? {
        // Exclude today: calorie totals may still be incomplete. Never impute missing days as zero.
        let today = calendar.startOfDay(for: now)
        let cutoff = calendar.date(byAdding: .day, value: -35, to: today)!
        let history = days.filter { $0.date >= cutoff && $0.date < today }.sorted { $0.date < $1.date }
        let weights = trend(history, calendar: calendar)
        guard weights.count >= 10, let first = weights.first, let last = weights.last,
              calendar.dateComponents([.day], from: last.date, to: today).day! <= 7 else { return nil }
        let span = calendar.dateComponents([.day], from: first.date, to: last.date).day ?? 0
        guard span >= 20 else { return nil }
        // Intake during [first weighing, last weighing) explains the intervening change.
        let food = history.filter { $0.date >= first.date && $0.date < last.date }
        let logged = food.compactMap(\.calories).filter { $0.isFinite && $0 > 0 }
        guard logged.count == span else { return nil }
        let xs = weights.map { Double(calendar.dateComponents([.day], from: first.date, to: $0.date).day ?? 0) }
        let meanX = xs.reduce(0, +) / Double(xs.count)
        let meanY = weights.map(\.value).reduce(0, +) / Double(weights.count)
        let denominator = xs.map { pow($0 - meanX, 2) }.reduce(0, +)
        guard denominator > 0 else { return nil }
        let slope = zip(xs, weights).map { ($0.0 - meanX) * ($0.1.value - meanY) }.reduce(0, +) / denominator
        let intake = logged.reduce(0, +) / Double(logged.count)
        let tdee = intake - energyPerKG * slope
        guard tdee.isFinite, (800...6000).contains(tdee) else { return nil }
        return HealthEstimate(tdee: tdee, averageIntake: intake, startWeight: last.value, lastDate: last.date, days: span)
    }
    static func forecast(_ estimate: HealthEstimate, intake: Double, weeks: Int = 8) -> [HealthPoint] {
        guard intake.isFinite, (800...6000).contains(intake), (1...12).contains(weeks) else { return [] }
        // Analytic solution of dW/dt = (intake - TDEE0 - k * (W-W0)) / rho.
        return (0...(weeks * 7)).compactMap { day in
            let change = (intake - estimate.tdee) / expenditurePerKG * (1 - exp(-expenditurePerKG * Double(day) / energyPerKG))
            let value = estimate.startWeight + change
            guard value > 0 else { return nil }
            return HealthPoint(date: estimate.lastDate.addingTimeInterval(Double(day) * 86400), value: value)
        }
    }
    static func demo(now: Date = Date(), calendar: Calendar = .current) -> [HealthDay] {
        let today = calendar.startOfDay(for: now)
        return (-42...0).map { offset in
            let date = calendar.date(byAdding: .day, value: offset, to: today)!
            return HealthDay(date: date, weight: 80 - Double(offset) * 0.035 + sin(Double(offset)) * 0.25,
                             calories: offset == 0 ? nil : 2250 + sin(Double(offset)) * 180)
        }
    }
}

/// Health access is independent of the financial demo. Only explicit DEBUG UI
/// tests may substitute samples; launch arguments cannot enable this in release.
enum NativeHealthLaunchPolicy {
    static func usesSimulatedData(debugBuild: Bool, arguments: [String]) -> Bool {
        debugBuild && arguments.contains("--visual-test")
    }
    static var simulated: Bool {
        #if DEBUG
        return usesSimulatedData(debugBuild: true, arguments: ProcessInfo.processInfo.arguments)
        #else
        return false
        #endif
    }
}
