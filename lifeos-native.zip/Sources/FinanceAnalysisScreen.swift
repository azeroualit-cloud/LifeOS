import SwiftUI
import Charts

struct FinanceAnalysisScreen: View {
    @EnvironmentObject var store: NativeStore
    @State private var range = 12
    private var lifetime: Record { store.finance.record("lifetime") }
    private func selected(_ rows: [Record]) -> [Record] {
        let available = rows.filter { $0.text("month") <= store.financeMonth }
        return range == 0 ? available : Array(available.suffix(range))
    }
    var body: some View {
        List {
            Section {
                Picker("Periodo", selection: $range) { Text("3 mesi").tag(3); Text("6 mesi").tag(6); Text("12 mesi").tag(12); Text("Tutto").tag(0) }.pickerStyle(.segmented)
            }
            Section { NativeForecastCard() }
            comparisonCharts
            wealth
            salary
            Section("Storico complessivo") {
                if lifetime.isEmpty { Text("I dati storici non sono inclusi nello snapshot.").foregroundStyle(NativeDesign.secondary) }
                else {
                    LabeledContent("Entrate documentate", value: lifetime.amount("income").euro)
                    LabeledContent("Spese registrate", value: lifetime.amount("recordedSpent").euro)
                    let adjustment = lifetime.record("historicalSpendingEstimate")
                    if !adjustment.isEmpty {
                        LabeledContent(adjustment.text("label", fallback: "Spese storiche stimate"), value: adjustment.amount("amount").euro)
                        Text("Stima storica separata dai movimenti, dai saldi e dal budget mensile.").font(.caption).foregroundStyle(NativeDesign.secondary)
                    }
                    LabeledContent("Stipendi per competenza", value: lifetime.amount("salaryHistoryTotal").euro)
                    LabeledContent("Rimborso 730", value: lifetime.amount("taxRefund").euro)
                }
            }
            Section("Verifica dei dati") {
                LabeledContent("Movimenti da classificare", value: String(store.finance.record("quality").integer("pending")))
                LabeledContent("Trasferimenti da abbinare", value: String(store.finance.record("quality").integer("unmatched")))
                let reconciliation = lifetime.record("reconciliation")
                if !reconciliation.isEmpty {
                    Text(reconciliation.text("status") == "incomplete" ? "Riconciliazione storica incompleta" : reconciliation.text("status")).font(.headline)
                    LabeledContent("Differenza da spiegare", value: reconciliation.amount("unexplainedDifference").euro)
                    Text("La differenza è un dato di controllo e non una nuova spesa.").font(.caption).foregroundStyle(NativeDesign.secondary)
                }
                if !store.finance.text("dataNote").isEmpty { Text(store.finance.text("dataNote")).font(.caption).foregroundStyle(NativeDesign.secondary) }
            }
        }.modifier(NativeListAppearance()).task(id: store.financeGeneration) { await store.loadAnalysis() }.navigationTitle("Analisi").navigationBarTitleDisplayMode(.inline)
    }
    @ViewBuilder private var comparisonCharts: some View {
        if !selected(store.finance.records("yearly")).isEmpty {
            Section("Entrate e uscite") {
                Picker("Periodo", selection: $range) { Text("3 mesi").tag(3); Text("6 mesi").tag(6); Text("12 mesi").tag(12); Text("Tutto").tag(0) }.pickerStyle(.segmented)
                Chart {
                    ForEach(selected(store.finance.records("yearly")).map { DisplayRecord(["day": .string($0.text("month")), "income": $0["income"] ?? .number(0), "spent": $0["spent"] ?? .number(0)], key: "day") }) { item in
                        BarMark(x: .value("Mese", item.value.text("day")), y: .value("Euro", item.value.amount("income"))).foregroundStyle(by: .value("Flusso", "Entrate")).position(by: .value("Flusso", "Entrate"))
                        BarMark(x: .value("Mese", item.value.text("day")), y: .value("Euro", item.value.amount("spent"))).foregroundStyle(by: .value("Flusso", "Uscite")).position(by: .value("Flusso", "Uscite"))
                    }
                }.chartForegroundStyleScale(["Entrate": NativeDesign.financialGreen, "Uscite": NativeDesign.financialRed]).chartXAxis { AxisMarks { value in AxisValueLabel { if let month = value.as(String.self) { Text(String(month.suffix(2))).font(.caption2) } } } }.frame(height: 160)
            }
        }
        let categories = store.finance.records("categories").filter { $0.amount("amount") > 0 && $0.amount("amount").isFinite }.sorted { $0.amount("amount") > $1.amount("amount") }
        if !categories.isEmpty {
            Section("Spese per categoria") {
                NativeCategoryChart(rows: categories)
            }
        }
    }
    @ViewBuilder private var wealth: some View {
        let source = range == 0 ? lifetime.records("series") : store.finance.records("wealthHistory")
        let rows = selected(source).filter { r in
            if range == 0 { if case .number? = r["wealth"] { return true } }
            else { if case .number? = r["measured"] { return true }; if case .number? = r["estimated"] { return true } }
            return false
        }
        if !rows.isEmpty {
            Section("Patrimonio") {
                Chart {
                    ForEach(rows.enumerated().map { IndexedRecord(index: $0.offset, value: $0.element) }) { item in
                        let value = wealthValue(item.value)
                        if item.index > 0 {
                            let previous = rows[item.index - 1]
                            let previousValue = wealthValue(previous)
                            let color = value < previousValue ? NativeDesign.financialRed : NativeDesign.financialGreen
                            LineMark(x: .value("Mese", previous.text("month")), y: .value("Euro", previousValue), series: .value("Tratto", item.index)).foregroundStyle(color)
                            LineMark(x: .value("Mese", item.value.text("month")), y: .value("Euro", value), series: .value("Tratto", item.index)).foregroundStyle(color)
                        }
                        PointMark(x: .value("Mese", item.value.text("month")), y: .value("Euro", value)).foregroundStyle(item.index > 0 && value < wealthValue(rows[item.index - 1]) ? NativeDesign.financialRed : NativeDesign.financialGreen)
                    }
                }.frame(height: 220)
                Text("Misure e stime storiche provengono dal Worker. Prima della prima rilevazione il saldo può non essere ricostruibile.").font(.caption).foregroundStyle(NativeDesign.secondary)
            }
        }
    }
    @ViewBuilder private var salary: some View {
        let rows = selected(lifetime.records("salaryHistory"))
        if !rows.isEmpty {
            Section("Stipendi per competenza") {
                Chart {
                    ForEach(rows.enumerated().map { IndexedRecord(index: $0.offset, value: $0.element) }) { item in
                        BarMark(x: .value("Mese", item.value.text("month")), y: .value("Euro", item.value.amount("base"))).foregroundStyle(by: .value("Voce", "Base"))
                        BarMark(x: .value("Mese", item.value.text("month")), y: .value("Euro", item.value.amount("additional"))).foregroundStyle(by: .value("Voce", "Aggiuntive"))
                    }
                }.chartForegroundStyleScale(["Base": NativeDesign.financialGreen, "Aggiuntive": NativeDesign.financialGreen.opacity(0.55)]).frame(height: 220)
                Text("La competenza del cedolino è distinta dalla data di accredito.").font(.caption).foregroundStyle(NativeDesign.secondary)
            }
        }
    }
    private func wealthValue(_ row: Record) -> Double {
        if range == 0 { return row.amount("wealth") }
        if case .number(let measured)? = row["measured"] { return measured }
        return row.amount("estimated")
    }
}
struct BillsHistoryScreen: View {
    @EnvironmentObject var store: NativeStore
    var body: some View {
        List(store.finance.records("history").enumerated().map { IndexedRecord(index: $0.offset, value: $0.element) }) { item in
            VStack(alignment: .leading, spacing: NativeDesign.Space.xs) {
                HStack { Text(item.value.text("name")); Spacer(); MoneyText(amount: item.value.amount("paid")) }
                Text(CivilDate.label(item.value.text("date")) + " · \(item.value.integer("months")) mesi").font(.caption).foregroundStyle(NativeDesign.secondary)
                if !item.value.text("note").isEmpty { Text(item.value.text("note")).font(.caption).foregroundStyle(NativeDesign.secondary) }
            }.padding(.vertical, NativeDesign.Space.xs)
        }.modifier(NativeListAppearance()).navigationTitle("Storico pagamenti").navigationBarTitleDisplayMode(.inline)
    }
}
