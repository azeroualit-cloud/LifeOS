import Foundation
import SQLite3

final class Storage {
    private var db: OpaquePointer?
    init(folder: URL? = nil) throws {
        let storageFolder: URL
        if let folder {
            storageFolder = folder
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        } else {
            storageFolder = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        }
        let path = storageFolder.appendingPathComponent("lifeos-probe.sqlite")
        guard sqlite3_open(path.path, &db) == SQLITE_OK,
              sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS archive(id INTEGER PRIMARY KEY CHECK(id=1), json TEXT NOT NULL)", nil, nil, nil) == SQLITE_OK else {
            throw Message(text: "Impossibile aprire l'archivio locale.")
        }
        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: path.path)
    }
    deinit { sqlite3_close(db) }
    func load() throws -> Archive {
        var stmt: OpaquePointer?
        guard sqlite3_prepare_v2(db, "SELECT json FROM archive WHERE id=1", -1, &stmt, nil) == SQLITE_OK else { throw failure() }
        defer { sqlite3_finalize(stmt) }
        let status = sqlite3_step(stmt)
        if status == SQLITE_DONE { return Archive() }
        guard status == SQLITE_ROW else { throw failure() }
        guard let raw = sqlite3_column_text(stmt, 0) else { throw failure() }
        return try JSONDecoder().decode(Archive.self, from: Data(String(cString: raw).utf8))
    }
    func save(_ archive: Archive) throws {
        let json = String(decoding: try JSONEncoder().encode(archive), as: UTF8.self)
        var stmt: OpaquePointer?
        guard sqlite3_prepare_v2(db, "INSERT INTO archive VALUES(1,?) ON CONFLICT(id) DO UPDATE SET json=excluded.json", -1, &stmt, nil) == SQLITE_OK else { throw failure() }
        defer { sqlite3_finalize(stmt) }
        let transient = unsafeBitCast(-1, to: sqlite3_destructor_type.self)
        guard sqlite3_bind_text(stmt, 1, json, -1, transient) == SQLITE_OK,
              sqlite3_step(stmt) == SQLITE_DONE else { throw failure() }
    }
    private func failure() -> Message { Message(text: "Salvataggio locale non riuscito.") }
}
