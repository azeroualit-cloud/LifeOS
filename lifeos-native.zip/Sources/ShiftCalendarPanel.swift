import SwiftUI

struct ShiftCalendarPanel: View {
    @EnvironmentObject var store: NativeStore
    @State private var status: Record = [:]
    @State private var statusMonth = ""
    @State private var message = ""
    @State private var failure = ""
    @State private var working = false
    @State private var confirmRotation = false

    private var subscription: URL? {
        guard statusMonth == store.calendarMonth else { return nil }
        return ShiftCalendarLink.subscription(server: store.server, path: status.text("path"))
    }
    var body: some View {
        VStack(alignment: .leading, spacing: NativeDesign.Space.medium) {
            Text("Turni in Calendario Apple").font(NativeDesign.heading)
            Text("Opzionale: invia una copia dei turni a Calendario Apple. Attività, eventi e abitudini restano in Life OS.")
                .font(.subheadline).foregroundStyle(NativeDesign.secondary)
            Text("Pubblica il mese visualizzato, anche dopo una correzione o una cancellazione. Gli altri mesi pubblicati restano disponibili.")
                .font(.caption).foregroundStyle(NativeDesign.secondary)
            if statusMonth == store.calendarMonth, !status.text("publishedAt").isEmpty {
                Text("Questo mese è stato pubblicato. Le nuove modifiche richiedono una nuova pubblicazione.")
                    .font(.caption).foregroundStyle(NativeDesign.secondary)
            }
            if store.isDemo || store.server == nil {
                Text("Per pubblicare i turni collega il server Life OS nelle Impostazioni. La demo non invia dati ad Apple.")
                    .font(.caption).foregroundStyle(NativeDesign.secondary)
            }
            Button(working ? "Attendi…" : "Pubblica turni del mese") { Task { await update("publishShiftCalendar") } }
                .buttonStyle(.borderedProminent).disabled(store.busy || working || store.isDemo || store.server == nil)
                .frame(minHeight: NativeDesign.Layout.touchTarget).accessibilityIdentifier("publish-shift-calendar")
            if !message.isEmpty { Text(message).font(.caption).accessibilityIdentifier("shift-calendar-status") }
            if !failure.isEmpty {
                Text(failure + " Puoi riprovare.").font(.caption).foregroundStyle(NativeDesign.danger)
                    .accessibilityIdentifier("shift-calendar-error")
                Button("Riprova collegamento") { Task { await update("getShiftCalendar") } }.disabled(store.busy || working)
            }
            if let subscription {
                Link("Collega Calendario Apple", destination: subscription)
                    .frame(minHeight: NativeDesign.Layout.touchTarget).accessibilityIdentifier("subscribe-shift-calendar")
                Text("Collegalo una sola volta. Apple aggiorna periodicamente i turni: le modifiche possono richiedere tempo. I turni si modificano in Life OS.")
                    .font(.caption).foregroundStyle(NativeDesign.secondary)
                Text("Il link è riservato: chi lo possiede può leggere i turni.").font(.caption).foregroundStyle(NativeDesign.secondary)
                Button("Rigenera link riservato", role: .destructive) { confirmRotation = true }
                    .disabled(store.busy || working).frame(minHeight: NativeDesign.Layout.touchTarget)
            }
        }
        .task(id: store.calendarMonth) { await update("getShiftCalendar") }
        .confirmationDialog("Il vecchio link smetterà di funzionare. Dovrai collegare di nuovo il calendario su Apple.", isPresented: $confirmRotation, titleVisibility: .visible) {
            Button("Rigenera link", role: .destructive) { Task { await update("rotateShiftCalendarLink") } }
        }
    }
    @MainActor private func update(_ method: String) async {
        guard !working, !store.isDemo, store.server != nil else { return }
        let month = store.calendarMonth
        working = true; failure = ""; message = ""
        defer { working = false }
        do {
            let result = try await store.updateShiftCalendar(method, month: month)
            guard !Task.isCancelled, store.calendarMonth == month else { return }
            status = result; statusMonth = month
            if method == "publishShiftCalendar" { message = "Turni pubblicati. Apple li riceverà al prossimo aggiornamento." }
            if method == "rotateShiftCalendarLink" { message = "Nuovo link pronto. Collegalo di nuovo su Apple." }
        } catch {
            if !Task.isCancelled, store.calendarMonth == month { failure = error.localizedDescription }
        }
    }
}
