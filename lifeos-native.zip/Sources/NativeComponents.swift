import SwiftUI

struct NativeSurface: ViewModifier {
    var material = false
    @ViewBuilder
    func body(content: Content) -> some View {
        if material {
            content.background(.regularMaterial, in: RoundedRectangle(cornerRadius: NativeDesign.cardRadius, style: .continuous))
        } else {
            content.background(NativeDesign.surface.opacity(0.94), in: RoundedRectangle(cornerRadius: NativeDesign.cardRadius, style: .continuous))
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: NativeDesign.cardRadius, style: .continuous))
        }
    }
}
struct NativePressStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.opacity(configuration.isPressed ? NativeDesign.Motion.pressedOpacity : 1)
            .scaleEffect(configuration.isPressed && !reduceMotion ? NativeDesign.Motion.pressedScale : 1)
            .animation(reduceMotion ? nil : .easeOut(duration: NativeDesign.Motion.pressDuration), value: configuration.isPressed)
    }
}
enum NativeCardDensity: Equatable {
    case standard, compact
    var inset: CGFloat { self == .standard ? NativeDesign.Layout.cardInset : NativeDesign.Layout.compactCardInset }
    var gap: CGFloat { self == .standard ? NativeDesign.Space.large : NativeDesign.Space.medium }
}
struct NativeCard<Content: View>: View {
    let content: Content
    var material: Bool
    var density: NativeCardDensity
    init(material: Bool = false, density: NativeCardDensity = .standard, @ViewBuilder content: () -> Content) {
        self.material = material; self.density = density; self.content = content()
    }
    var body: some View {
        VStack(alignment: .leading, spacing: density.gap) { content }
            .frame(maxWidth: .infinity, alignment: .leading).padding(density.inset)
            .modifier(NativeSurface(material: material))
    }
}
struct NativeGroupedCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        VStack(spacing: NativeDesign.Space.none) { content }
            .padding(.horizontal, NativeDesign.Layout.groupedInset).padding(.vertical, NativeDesign.Space.xs)
            .modifier(NativeSurface())
    }
}
struct NativeRoutineAppearance: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.buttonStyle(.glass).buttonBorderShape(.roundedRectangle(radius: NativeDesign.controlRadius))
        } else {
            content.buttonStyle(.bordered).buttonBorderShape(.roundedRectangle(radius: NativeDesign.controlRadius))
        }
    }
}
struct NativeIcon: View {
    let name: String
    var color: Color = NativeDesign.accent
    var body: some View {
        Image(systemName: name).symbolVariant(.none).symbolRenderingMode(.monochrome).font(NativeDesign.symbol)
            .foregroundStyle(color).frame(width: NativeDesign.Layout.iconTile, height: NativeDesign.Layout.iconTile)
            .background(NativeDesign.inset, in: RoundedRectangle(cornerRadius: NativeDesign.controlRadius, style: .continuous))
            .accessibilityHidden(true)
    }
}
struct NativeSectionHeading: View {
    let title: String
    var body: some View { Text(title).font(.headline).frame(maxWidth: .infinity, alignment: .leading) }
}
struct NativeNavigationLabel: View {
    let title: String
    let symbol: String
    var body: some View {
        HStack(spacing: NativeDesign.Space.medium) {
            NativeIcon(name: symbol)
            Text(title).font(NativeDesign.body)
        }.frame(minHeight: NativeDesign.Layout.touchTarget)
    }
}
struct NativeListAppearance: ViewModifier {
    func body(content: Content) -> some View {
        content.listStyle(.insetGrouped).listSectionSpacing(NativeDesign.gap)
            .font(NativeDesign.body).environment(\.defaultMinListRowHeight, NativeDesign.Layout.rowHeight)
            .contentMargins(.horizontal, NativeDesign.Layout.screenInset, for: .scrollContent)
            .listRowSpacing(0).contentMargins(.top, NativeDesign.Space.small, for: .scrollContent).contentMargins(.bottom, NativeDesign.Space.section, for: .scrollContent).scrollBounceBehavior(.basedOnSize)
            .scrollContentBackground(.hidden).background(NativeDesign.canvas)
    }
}
struct NativeGlass: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) { content.glassEffect(.regular.interactive(), in: Capsule()) }
        else { content.background(.regularMaterial, in: Capsule()) }
    }
}
struct NativeConnectionBadge: View {
    @EnvironmentObject var store: NativeStore
    private var text: String {
        if store.isDemo { return "Demo" }
        if store.busy { return "Aggiornamento" }
        if !store.state.pending.isEmpty { return "\(store.state.pending.count) in coda" }
        if !store.syncStatus.isEmpty && store.syncStatus != "Aggiornato" { return "Da aggiornare" }
        return store.sharedDatabase ? "Condiviso con il sito" : store.server == nil ? "Sul dispositivo" : "Collegato"
    }
    var body: some View {
        NativeStatusBadge(title: text, tone: store.isDemo || !store.state.pending.isEmpty || (!store.syncStatus.isEmpty && store.syncStatus != "Aggiornato") ? .warning : .success, showsIndicator: true, loading: store.busy)
    }
}

struct NativeCheckmark: View {
    let checked: Bool
    var body: some View {
        Image(systemName: checked ? "checkmark.circle.fill" : "circle")
            .symbolRenderingMode(.monochrome).font(.title2.weight(.regular))
            .foregroundStyle(checked ? NativeDesign.accent : NativeDesign.secondary)
            .frame(width: NativeDesign.Layout.touchTarget, height: NativeDesign.Layout.touchTarget)
            .contentShape(Rectangle()).accessibilityHidden(true)
    }
}
struct NativeCompletionButton: View {
    let checked: Bool
    let label: String
    let action: () -> Void
    var body: some View {
        Button(action: action) { NativeCheckmark(checked: checked) }
            .buttonStyle(.borderless).accessibilityLabel(label)
            .accessibilityValue(checked ? "Completata" : "Da completare")
    }
}
struct NativeDisclosureIndicator: View {
    var body: some View {
        Image(systemName: "chevron.right").font(.footnote.weight(.semibold))
            .foregroundStyle(NativeDesign.secondary).accessibilityHidden(true)
    }
}
struct NativeRowText: View {
    let title: String
    var subtitle: String = ""
    var completed = false
    var titleLineLimit: Int?
    var titleIdentifier: String?
    var body: some View {
        VStack(alignment: .leading, spacing: NativeDesign.Space.xs) {
            titleView.lineLimit(titleLineLimit)
                .foregroundStyle(Color.primary).fixedSize(horizontal: false, vertical: true)
            if !subtitle.isEmpty {
                Text(subtitle).font(NativeDesign.metadata).foregroundStyle(NativeDesign.secondary)
                    .lineLimit(2).fixedSize(horizontal: false, vertical: true)
            }
        }.frame(maxWidth: .infinity, minHeight: NativeDesign.Layout.touchTarget, alignment: .leading)
            .multilineTextAlignment(.leading)
    }
    @ViewBuilder private var titleView: some View {
        if let titleIdentifier { Text(title).font(NativeDesign.body).strikethrough(completed).accessibilityIdentifier(titleIdentifier) }
        else { Text(title).font(NativeDesign.body).strikethrough(completed) }
    }
}
struct NativeIconButton: View {
    let symbol: String
    let label: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol).font(NativeDesign.symbol).symbolRenderingMode(.monochrome).foregroundStyle(NativeDesign.accent)
                .frame(width: NativeDesign.Layout.touchTarget, height: NativeDesign.Layout.touchTarget)
                .contentShape(Rectangle())
        }.buttonStyle(.plain).accessibilityLabel(label)
    }
}
struct NativeSectionHeader<Accessory: View>: View {
    let title: String
    var titleIdentifier: String?
    let accessory: Accessory
    init(_ title: String, titleIdentifier: String? = nil, @ViewBuilder accessory: () -> Accessory) {
        self.title = title; self.titleIdentifier = titleIdentifier; self.accessory = accessory()
    }
    var body: some View {
        HStack(spacing: NativeDesign.Space.medium) {
            if let titleIdentifier { Text(title).font(NativeDesign.heading).accessibilityIdentifier(titleIdentifier) }
            else { Text(title).font(NativeDesign.heading) }
            Spacer(minLength: NativeDesign.Space.small)
            accessory
        }
    }
}
enum NativeTone {
    case neutral, success, warning, danger
    var color: Color {
        switch self {
        case .neutral: return NativeDesign.secondary
        case .success: return NativeDesign.success
        case .warning: return NativeDesign.warning
        case .danger: return NativeDesign.danger
        }
    }
}
struct NativeStatusBadge: View {
    let title: String
    var symbol: String?
    var tone: NativeTone = .neutral
    var showsIndicator = false
    var loading = false
    var body: some View {
        HStack(spacing: NativeDesign.Space.xs) {
            if loading { ProgressView().controlSize(.mini) }
            else if let symbol { Image(systemName: symbol) }
            else if showsIndicator { Circle().fill(tone.color).frame(width: NativeDesign.Layout.statusDot, height: NativeDesign.Layout.statusDot) }
            Text(title)
        }.font(NativeDesign.metadata).foregroundStyle(tone.color)
            .padding(.horizontal, NativeDesign.Space.small).padding(.vertical, NativeDesign.Space.xs)
            .background(tone.color.opacity(0.12), in: RoundedRectangle(cornerRadius: NativeDesign.badgeRadius, style: .continuous))
            .accessibilityElement(children: .combine)
    }
}
struct NativeSelectionSurface: ViewModifier {
    let selected: Bool
    var tint: Color = NativeDesign.accent
    var outlined = false
    func body(content: Content) -> some View {
        content.background(selected ? tint.opacity(0.18) : NativeDesign.inset, in: RoundedRectangle(cornerRadius: NativeDesign.controlRadius, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: NativeDesign.controlRadius, style: .continuous).stroke(selected && outlined ? tint : .clear, lineWidth: 1.5))
    }
}
struct NativeCategoryChip: View {
    let title: String
    let selected: Bool
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title).font(.subheadline.weight(selected ? .semibold : .regular))
                .padding(.horizontal, NativeDesign.Space.medium)
                .frame(minWidth: NativeDesign.Layout.categoryWidth, minHeight: NativeDesign.Layout.touchTarget)
                .modifier(NativeSelectionSurface(selected: selected))
        }.buttonStyle(.plain).accessibilityAddTraits(selected ? .isSelected : [])
    }
}
struct NativeInlineMessage: View {
    let text: String
    var tone: NativeTone = .danger
    var body: some View {
        Text(text).font(NativeDesign.metadata).foregroundStyle(tone.color)
            .fixedSize(horizontal: false, vertical: true)
    }
}
