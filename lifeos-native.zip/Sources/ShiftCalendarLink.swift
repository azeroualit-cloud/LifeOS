import Foundation

enum ShiftCalendarLink {
    static func subscription(server: URL?, path: String) -> URL? {
        guard let server, server.scheme == "https", server.host != nil,
              path.range(of: #"^/calendar/turni/[a-f0-9]{64}\.ics$"#, options: .regularExpression) != nil,
              var components = URLComponents(url: server, resolvingAgainstBaseURL: false) else { return nil }
        components.scheme = "webcal"; components.path = path
        components.query = nil; components.fragment = nil; components.user = nil; components.password = nil
        return components.url
    }
}
