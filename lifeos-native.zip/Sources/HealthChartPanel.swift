import SwiftUI
import Charts

struct HealthChartPanel: View {
    @EnvironmentObject var store: NativeStore
    @State private var metric = "Peso"
    private var samples: [HealthMeasurement] {
        let today = CivilDate.day(), start = CivilDate.adding(-89, to: today)
        return Array(store.life.records("health").compactMap(HealthMeasurement.init).filter { $0.day >= start && $0.day <= today }.sorted { $0.day < $1.day }.suffix(30))
    }
    var body: some View {
        let rows = samples.filter { metric == "Peso" ? $0.weight != nil : $0.calories != nil }
        let unit = metric == "Peso" ? "kg" : "kcal"
        VStack(alignment: .leading, spacing: NativeDesign.Space.large) {
            Text("Peso e calorie").font(NativeDesign.heading)
            Picker("Misurazione", selection: $metric) { Text("Peso").tag("Peso"); Text("Calorie").tag("Calorie") }.pickerStyle(.segmented)
                .accessibilityIdentifier("health-chart-metric")
            Text("Ultime 30 misurazioni negli ultimi 90 giorni. I giorni senza dati restano vuoti.").font(.caption).foregroundStyle(NativeDesign.secondary)
            if rows.isEmpty {
                Text(store.isDemo || store.life["health"] != nil ? "Nessuna misurazione disponibile. Usa Aggiungi peso per iniziare." : "Misurazioni da aggiornare. Sincronizza Life OS nelle Impostazioni.").foregroundStyle(NativeDesign.secondary).accessibilityIdentifier("health-empty")
            } else {
                Chart(rows) { sample in
                    if let value = metric == "Peso" ? sample.weight : sample.calories {
                        PointMark(x: .value("Data", CivilDate.date(sample.day)), y: .value(unit, value))
                            .foregroundStyle(NativeDesign.accent)
                            .accessibilityLabel(CivilDate.label(sample.day))
                            .accessibilityValue(value.formatted() + " " + unit)
                    }
                }.chartYScale(domain: .automatic(includesZero: metric != "Peso"))
                    .chartYAxisLabel(unit)
                    .frame(height: NativeDesign.Layout.healthChartHeight).accessibilityIdentifier("health-chart")
                DisclosureGroup("Mostra misurazioni") {
                    ForEach(rows) { sample in
                        LabeledContent(CivilDate.label(sample.day), value: ((metric == "Peso" ? sample.weight : sample.calories) ?? 0).formatted() + " " + unit)
                    }
                }.font(.caption)
            }
        }.accessibilityIdentifier("health-panel")
    }
}

struct WeightEditor: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    @State private var date = Date()
    @State private var weight = ""
    @State private var calories = ""
    @State private var saving = false
    @State private var issue = ""
    var body: some View {
        Form {
            DatePicker("Data", selection: $date, in: ...Date(), displayedComponents: .date)
            TextField("Peso (kg)", text: $weight).keyboardType(.decimalPad)
            TextField("Calorie (kcal, facoltative)", text: $calories).keyboardType(.numberPad)
            Text("Una misurazione per giorno. Un nuovo salvataggio aggiorna i valori inseriti; i campi vuoti conservano quelli precedenti.").font(.caption).foregroundStyle(NativeDesign.secondary)
            if !issue.isEmpty { Text(issue).foregroundStyle(NativeDesign.danger).accessibilityIdentifier("health-save-error") }
            Button(saving ? "Salvataggio…" : "Salva misurazione") {
                Task {
                    guard !saving else { return }; saving = true; issue = ""
                    defer { saving = false }
                    do {
                        let payload = try HealthMeasurement.payload(day: CivilDate.day(date), weight: weight, calories: calories)
                        try await store.perform("saveHealthEntry", payload)
                        dismiss()
                    } catch { issue = error.localizedDescription }
                }
            }.disabled(store.busy || saving).accessibilityIdentifier("save-health-measurement")
        }.modifier(NativeListAppearance()).navigationTitle("Aggiungi peso").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() }.disabled(saving) } }
            .onAppear { loadDay() }.onChange(of: date) { _, _ in loadDay() }
    }
    private func loadDay() {
        let row = store.life.records("health").first { $0.text("day") == CivilDate.day(date) } ?? [:]
        weight = row["weight_kg"].flatMap { if case .number(let value) = $0 { return String(value) }; return nil } ?? ""
        calories = row["calories"].flatMap { if case .number(let value) = $0 { return String(Int(value)) }; return nil } ?? ""
    }
}
