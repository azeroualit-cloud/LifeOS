import Foundation

struct HealthMeasurement: Identifiable {
    let day: String
    let weight: Double?
    let calories: Double?
    var id: String { day }
    init?(_ record: Record) {
        day = record.text("day")
        guard day.count == 10, CivilDate.day(CivilDate.date(day)) == day else { return nil }
        func value(_ key: String, range: ClosedRange<Double>) -> Double? {
            guard case .number(let number)? = record[key], number.isFinite, range.contains(number) else { return nil }
            return number
        }
        weight = value("weight_kg", range: 20...500)
        calories = value("calories", range: 0...15000)
    }
    static func payload(day: String, weight: String, calories: String, today: String = CivilDate.day()) throws -> Record {
        guard day.count == 10, CivilDate.day(CivilDate.date(day)) == day, day <= today else { throw Message(text: "Scegli oggi o una data precedente.") }
        func parse(_ text: String, range: ClosedRange<Double>, integer: Bool = false) throws -> JSONValue? {
            let clean = text.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: ",", with: ".")
            if clean.isEmpty { return nil }
            guard let number = Double(clean), number.isFinite, range.contains(number), !integer || number.rounded() == number else { throw Message(text: "Controlla peso (20–500 kg) e calorie (0–15000 kcal).") }
            return .number(number)
        }
        let kg = try parse(weight, range: 20...500), kcal = try parse(calories, range: 0...15000, integer: true)
        guard kg != nil || kcal != nil else { throw Message(text: "Inserisci il peso o le calorie.") }
        var result: Record = ["day": .string(day)]
        result["weightKg"] = kg; result["calories"] = kcal
        return result
    }
}
