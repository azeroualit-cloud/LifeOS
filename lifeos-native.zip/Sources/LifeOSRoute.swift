import Foundation

enum LifeOSRoute: String {
    case task, activities, weight, calendar, dashboard
    init?(_ url: URL) {
        guard url.scheme == "lifeos", url.user == nil, url.password == nil,
              url.query == nil, url.fragment == nil, url.path.isEmpty || url.path == "/",
              let host = url.host, let route = Self(rawValue: host) else { return nil }
        self = route
    }
}
extension Notification.Name { static let lifeOSRoute = Notification.Name("LifeOSRoute") }
