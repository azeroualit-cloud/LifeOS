import SwiftUI

struct TasksScreen: View {
    @EnvironmentObject var store: NativeStore
    @EnvironmentObject var router: NativeRouter
    @State private var category = "action"
    @State private var editMode: EditMode = .inactive
    private func rows(_ status: String) -> [Record] {
        store.tasks.filter { $0.text("list_kind") == category && $0.text("status") == status }
            .sorted { $0.amount("sort_order") < $1.amount("sort_order") }
    }
    var body: some View {
        List {
            Section {
                HStack(spacing: 8) {
                    Text("Categorie").font(.subheadline.weight(.semibold))
                    Spacer()
                    Button(editMode == .active ? "Fine" : "Riordina") { editMode = editMode == .active ? .inactive : .active }.font(.subheadline).disabled(store.busy).accessibilityIdentifier("reorder-tasks")
                    Button { router.sheet = .categories } label: { Image(systemName: "folder").frame(width: 44, height: 44) }.accessibilityLabel("Gestisci categorie")
                }.buttonStyle(.plain).listRowSeparator(.hidden)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(store.categories.map { DisplayRecord($0, key: "key") }) { item in
                            Button { category = item.value.text("key") } label: {
                                Text(item.value.text("label")).font(.subheadline.weight(category == item.value.text("key") ? .semibold : .regular))
                                    .padding(.horizontal, 14).frame(minHeight: 44)
                                    .background(category == item.value.text("key") ? NativeDesign.accent.opacity(0.18) : Color.secondary.opacity(0.08), in: Capsule())
                            }.buttonStyle(.plain).accessibilityAddTraits(category == item.value.text("key") ? .isSelected : [])
                        }
                    }
                }.listRowSeparator(.hidden)
            }.listRowBackground(Color.clear).listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
            Section("Da fare") {
                if rows("todo").isEmpty { Text("Nessuna attività da fare").foregroundStyle(Color.secondary) }
                ForEach(rows("todo").map { DisplayRecord($0) }) { item in taskRow(item.value) }
                    .onMove { indexes, destination in
                        var ordered = rows("todo"); ordered.move(fromOffsets: indexes, toOffset: destination)
                        Task { await store.run("reorderTasks", ["category": .string(category), "ids": .array(ordered.map { .int($0.integer("id")) })]) }
                    }
            }
            if !rows("waiting").isEmpty { Section("In attesa") { ForEach(rows("waiting").map { DisplayRecord($0) }) { item in taskRow(item.value) } } }
            if !rows("done").isEmpty {
                Section("Completate") {
                    ForEach(rows("done").map { DisplayRecord($0) }) { item in taskRow(item.value) }
                    Button("Elimina tutte le completate", role: .destructive) { confirmDelete = true }
                }
            }
        }
        .modifier(NativeListAppearance())
        .environment(\.editMode, $editMode)
        .confirmationDialog("Eliminare le attività completate di questa categoria?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Elimina completate", role: .destructive) { Task { await store.run("deleteCompletedTasks", ["category": .string(category)]) } }
        }
        
        .onAppear { router.taskCategory = category }
        .onChange(of: category) { _, value in router.taskCategory = value }
        .onChange(of: store.categories.map { $0.text("key") }) { _, keys in if !keys.contains(category) { category = keys.first ?? "action" } }
    }
    @State private var confirmDelete = false
    private func taskRow(_ r: Record) -> some View {
        HStack(alignment: .center, spacing: 8) {
            Button {
                Task { await store.run("setTaskStatus", ["id": .int(r.integer("id")), "status": .string(r.text("status") == "done" ? "todo" : "done")]) }
            } label: { Image(systemName: r.text("status") == "done" ? "checkmark.circle.fill" : "circle").font(.system(size: 22, weight: .light)).foregroundStyle(r.text("status") == "done" ? NativeDesign.accent : Color.secondary).frame(width: 36, height: 44) }.buttonStyle(.borderless).accessibilityLabel("Cambia completamento")
            Button { router.sheet = .task(r) } label: {
                VStack(alignment: .leading, spacing: 4) {
                    Text(r.text("title")).font(.subheadline).strikethrough(r.text("status") == "done")
                    if !r.text("notes").isEmpty { Text(r.text("notes")).font(.caption).foregroundStyle(Color.secondary).lineLimit(2) }
                    if !r.text("due_date").isEmpty { NativeDueBadge(day: r.text("due_date")) }
                }.frame(maxWidth: .infinity, alignment: .leading).multilineTextAlignment(.leading).foregroundStyle(Color.primary)
            }.buttonStyle(.borderless)
            Image(systemName: "chevron.right").font(.caption2).foregroundStyle(Color.secondary).accessibilityHidden(true)
        }.padding(.vertical, 2)
        .listRowInsets(EdgeInsets(top: 3, leading: 12, bottom: 3, trailing: 12))
        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
            Button("Elimina", role: .destructive) { Task { await store.run("deleteTask", args: [.int(r.integer("id"))]) } }
            Button(r.text("status") == "waiting" ? "Riattiva" : "In attesa") {
                Task { await store.run("setTaskStatus", ["id": .int(r.integer("id")), "status": .string(r.text("status") == "waiting" ? "todo" : "waiting")]) }
            }.tint(.orange)
        }.disabled(store.busy)
    }
}
struct TaskEditor: View {
    @EnvironmentObject var store: NativeStore
    @Environment(\.dismiss) private var dismiss
    let record: Record
    @State private var title = ""
    @State private var notes = ""
    @State private var category = "action"
    @State private var due = Date()
    @State private var scheduled = Date()
    @State private var hasDue = false
    @State private var hasScheduled = false
    @State private var saving = false
    @State private var error: String?
    var body: some View {
        Form {
            Section { TextField("Titolo", text: $title); Picker("Categoria", selection: $category) { ForEach(store.categories.map { DisplayRecord($0, key: "key") }) { item in Text(item.value.text("label")).tag(item.value.text("key")) } } }
            Section("Date") {
                Toggle("Scadenza", isOn: $hasDue)
                if hasDue { DatePicker("Scade il", selection: $due, displayedComponents: .date) }
                Toggle("Mostra nel calendario", isOn: $hasScheduled)
                if hasScheduled { DatePicker("Giorno", selection: $scheduled, displayedComponents: .date) }
            }
            Section("Note") { TextEditor(text: $notes).frame(minHeight: 120) }
            if let error { Text(error).foregroundStyle(.red) }
        }.navigationTitle(record.integer("id") > 0 ? "Modifica attività" : "Nuova attività").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() }.disabled(saving) }
            ToolbarItem(placement: .confirmationAction) { Button("Salva") { Task { await save() } }.disabled(saving || store.busy || title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
        }.onAppear {
            title = record.text("title"); notes = record.text("notes"); category = record.text("list_kind", fallback: store.categories.first?.text("key") ?? "action")
            hasDue = !record.text("due_date").isEmpty; hasScheduled = !record.text("scheduled_date").isEmpty
            if hasDue { due = CivilDate.date(record.text("due_date")) }; if hasScheduled { scheduled = CivilDate.date(record.text("scheduled_date")) }
        }
    }
    private func save() async {
        saving = true; defer { saving = false }
        do {
            try await store.perform("saveTask", ["id": .int(record.integer("id")), "title": .string(title), "notes": .string(notes), "list_kind": .string(category), "due_date": hasDue ? .string(CivilDate.day(due)) : .null, "scheduled_date": hasScheduled ? .string(CivilDate.day(scheduled)) : .null])
            dismiss()
        } catch { self.error = error.localizedDescription }
    }
}
struct CategoriesEditor: View {
    @EnvironmentObject var store: NativeStore
    @State private var name = ""
    @State private var rename: Record?
    @State private var deleting: Record?
    @State private var destination = "action"
    @State private var showRename = false
    @State private var showDelete = false
    var body: some View {
        List {
            Section {
                ForEach(store.categories.map { DisplayRecord($0, key: "key") }) { item in
                    HStack { Text(item.value.text("label")); Spacer(); Button { rename = item.value; name = item.value.text("label"); showRename = true } label: { Image(systemName: "pencil") }.buttonStyle(.borderless) }
                        .swipeActions { Button("Elimina", role: .destructive) { deleting = item.value; destination = store.categories.first(where: { $0.text("key") != item.value.text("key") })?.text("key") ?? ""; showDelete = true } }
                }.onMove { offsets, to in
                    var rows = store.categories; rows.move(fromOffsets: offsets, toOffset: to)
                    Task { await store.run("reorderCategories", ["keys": .array(rows.map { .string($0.text("key")) })]) }
                }
            }
            Section("Nuova categoria") {
                TextField("Nome", text: $name)
                Button("Aggiungi") { Task { await store.run("addCategory", ["label": .string(name)]); name = "" } }.disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || store.busy)
            }
            if showDelete, let deleting {
                Section("Conserva le attività") {
                    Picker("Sposta in", selection: $destination) { ForEach(store.categories.filter { $0.text("key") != deleting.text("key") }.map { DisplayRecord($0, key: "key") }) { item in Text(item.value.text("label")).tag(item.value.text("key")) } }
                    Button("Elimina categoria e sposta le attività", role: .destructive) { Task { await store.run("deleteCategory", ["key": .string(deleting.text("key")), "destination": .string(destination)]); showDelete = false } }.disabled(destination.isEmpty || store.busy)
                    Button("Annulla") { showDelete = false }
                }
            }
        }.navigationTitle("Categorie").toolbar { DoneButton(); ToolbarItem(placement: .topBarLeading) { EditButton() } }
        .alert("Rinomina categoria", isPresented: $showRename) {
            TextField("Nome", text: $name)
            Button("Salva") { if let rename { Task { await store.run("renameCategory", ["key": .string(rename.text("key")), "label": .string(name)]); name = "" } } }
            Button("Annulla", role: .cancel) { name = "" }
        }
    }
}
struct RoutinesEditor: View {
    @EnvironmentObject var store: NativeStore
    @State private var name = ""
    @State private var editingID = 0
    var body: some View {
        Form {
            Section("Routine giornaliere") {
                ForEach(store.routines.map { DisplayRecord($0) }) { item in
                    Button(item.value.text("title")) { editingID = item.value.integer("id"); name = item.value.text("title") }
                        .swipeActions { Button("Elimina", role: .destructive) { Task { await store.run("deleteRoutine", args: [.int(item.value.integer("id"))]) } } }
                }
            }
            Section(editingID == 0 ? "Aggiungi routine" : "Modifica routine") {
                TextField("Nome", text: $name)
                Button("Salva") { Task { await store.run("saveRoutine", ["id": .int(editingID), "title": .string(name)]); editingID = 0; name = "" } }.disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || store.busy)
                if editingID != 0 { Button("Annulla modifica") { editingID = 0; name = "" } }
            }
            Text("Massimo otto routine. Ogni giorno ha i propri completamenti.").font(.caption).foregroundStyle(Color.secondary)
        }.navigationTitle("Routine").toolbar { DoneButton() }
    }
}
