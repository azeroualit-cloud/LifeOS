import Foundation
import Security

// Session credentials stay in the device Keychain, never in JSON exports or UserDefaults.
enum SessionVault {
    private struct Cookie: Codable {
        let name: String
        let value: String
        let domain: String
        let path: String
        let expires: Date?
        init(_ cookie: HTTPCookie) { name = cookie.name; value = cookie.value; domain = cookie.domain; path = cookie.path; expires = cookie.expiresDate }
        var restored: HTTPCookie? {
            if let expires, expires <= Date() { return nil }
            var properties: [HTTPCookiePropertyKey: Any] = [.name: name, .value: value, .domain: domain, .path: path, .secure: "TRUE"]
            if let expires { properties[.expires] = expires }
            return HTTPCookie(properties: properties)
        }
    }
    private static func key(_ origin: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "LifeOS.session.v1", kSecAttrAccount as String: origin]
    }
    @discardableResult static func save(_ cookies: [HTTPCookie], origin: String) -> Bool {
        let session = cookies.filter { $0.name == "liquidita_session" && $0.isSecure }
        guard !session.isEmpty, let data = try? JSONEncoder().encode(session.map(Cookie.init)) else { return false }
        let query = key(origin), values: [String: Any] = [kSecValueData as String: data, kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
        let status = SecItemUpdate(query as CFDictionary, values as CFDictionary)
        if status == errSecItemNotFound {
            var item = query; item.merge(values) { _, new in new }; return SecItemAdd(item as CFDictionary, nil) == errSecSuccess
        }
        return status == errSecSuccess
    }
    static func load(origin: String) -> [HTTPCookie] {
        var query = key(origin); query[kSecReturnData as String] = true; query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data, let entries = try? JSONDecoder().decode([Cookie].self, from: data) else { return [] }
        return entries.compactMap(\.restored)
    }
}
