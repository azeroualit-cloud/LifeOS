import XCTest
import UIKit

final class NativeInterfaceTests: XCTestCase {
    private func launch(_ extra: [String] = []) -> XCUIApplication {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--visual-test", "-AppleLanguages", "(it)", "-AppleLocale", "it_IT"] + extra
        app.launch()
        XCTAssertTrue(app.tabBars.buttons["Dashboard"].waitForExistence(timeout: 30))
        return app
    }
    private func capture(_ name: String) {
        let shot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        shot.name = name; shot.lifetime = .keepAlways; add(shot)
    }
    func testFourSectionsInBothThemes() {
        for dark in [false, true] {
            let app = launch(dark ? ["--dark"] : [])
            for tab in ["Dashboard", "Attività", "Calendario", "Finanza"] {
                app.tabBars.buttons[tab].tap()
                XCTAssertTrue(app.navigationBars[tab].waitForExistence(timeout: 10))
                if tab == "Finanza" {
                    let reserved = app.staticTexts["Accantonati"]
                    XCTAssertTrue(reserved.exists)
                    let fullWidth = ("Accantonati" as NSString).size(withAttributes: [.font: UIFont.preferredFont(forTextStyle: .caption2)]).width
                    XCTAssertGreaterThanOrEqual(reserved.frame.width, fullWidth - 1, "La legenda deve mostrare la parola completa")
                }
                capture((dark ? "dark-" : "light-") + tab)
            }
            app.terminate()
        }
    }
    func testWeatherTilesStayAlignedInBothThemes() {
        for dark in [false, true] {
            let app = launch(dark ? ["--dark"] : [])
            let condition = app.otherElements["today-condition"]
            let temperature = app.otherElements["today-temperature"]
            XCTAssertTrue(condition.waitForExistence(timeout: 10))
            XCTAssertTrue(temperature.exists)
            XCTAssertEqual(condition.frame.minY, temperature.frame.minY, accuracy: 1)
            XCTAssertEqual(condition.frame.height, temperature.frame.height, accuracy: 1)
            XCTAssertEqual(condition.frame.width, temperature.frame.width, accuracy: 1)
            XCTAssertGreaterThan(condition.frame.width, 70)
            XCTAssertLessThan(temperature.frame.maxX, app.frame.maxX)
            let eventTitle = app.staticTexts["Allenamento"]
            let taskTitle = app.staticTexts["Organizzare la settimana"]
            XCTAssertTrue(eventTitle.exists)
            XCTAssertTrue(taskTitle.exists)
            XCTAssertEqual(eventTitle.frame.minX, taskTitle.frame.minX, accuracy: 1)
            capture(dark ? "platinum-weather-dark" : "platinum-weather-light")
            app.terminate()
        }
    }
    func testKeyboardAndLocalMovementFlow() {
        let app = launch()
        app.buttons["Aggiungi spesa"].tap()
        let description = app.textFields["Descrizione"]
        XCTAssertTrue(description.waitForExistence(timeout: 10))
        description.tap(); description.typeText("Verifica interfaccia")
        capture("movement-keyboard")
        let amount = app.textFields["Importo €"]
        amount.tap(); amount.typeText("2")
        app.buttons["Salva"].tap()
        XCTAssertTrue(app.tabBars.buttons["Finanza"].waitForExistence(timeout: 10))
        app.tabBars.buttons["Finanza"].tap()
        let all = app.buttons["all-movements"]
        for _ in 0..<8 { if all.isHittable { break }; app.collectionViews.firstMatch.swipeUp() }
        XCTAssertTrue(all.isHittable); all.tap()
        XCTAssertTrue(app.buttons.containing(.staticText, identifier: "Verifica interfaccia").firstMatch.waitForExistence(timeout: 10))
        capture("movement-saved-locally")
    }
    func testLargeTextAndSixWeekCalendar() {
        let app = launch(["--large-text", "--six-weeks"])
        capture("accessibility-dashboard")
        app.tabBars.buttons["Calendario"].tap()
        XCTAssertTrue(app.staticTexts["Marzo 2026"].waitForExistence(timeout: 10))
        capture("accessibility-six-weeks")
        app.terminate()
    }
    func testNativeSignInKeyboard() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--visual-test", "--signin-preview", "--dark", "-AppleLanguages", "(it)", "-AppleLocale", "it_IT"]
        app.launch()
        let password = app.secureTextFields["Password"]
        XCTAssertTrue(password.waitForExistence(timeout: 30))
        password.tap(); password.typeText("demo-only")
        capture("native-signin-keyboard")
        app.terminate()
    }
    func testRepeatedBoundaryScrollingKeepsNavigationStable() {
        let app = launch(["--stress-content", "--dark"])
        for tab in ["Dashboard", "Attività", "Calendario", "Finanza"] {
            app.tabBars.buttons[tab].tap()
            let tabs = app.tabBars.firstMatch
            let before = tabs.frame
            let surface = (tab == "Attività" || tab == "Finanza") ? app.collectionViews.firstMatch : app.scrollViews[tab == "Dashboard" ? "dashboard-scroll" : "calendar-scroll"]
            XCTAssertTrue(surface.waitForExistence(timeout: 10))
            for _ in 0..<4 { surface.swipeUp(velocity: .fast) }
            for _ in 0..<3 { surface.swipeUp(velocity: .fast) }
            for _ in 0..<7 { surface.swipeDown(velocity: .fast) }
            XCTAssertTrue(app.tabBars.buttons["Dashboard"].isHittable)
            XCTAssertTrue(app.tabBars.buttons["Calendario"].isHittable)
            XCTAssertEqual(before.height, tabs.frame.height, accuracy: 2)
            capture("boundary-" + tab)
        }
    }
    func testCalendarEventCanBeCreatedAfterBoundaryScroll() {
        let app = launch(["--dark"])
        app.tabBars.buttons["Calendario"].tap()
        let scroll = app.scrollViews["calendar-scroll"]
        XCTAssertTrue(scroll.waitForExistence(timeout: 10))
        for _ in 0..<4 { scroll.swipeUp(velocity: .fast) }
        let add = app.buttons["calendar-add-event"]
        XCTAssertTrue(add.isHittable)
        XCTAssertLessThan(add.frame.maxY, app.tabBars.firstMatch.frame.minY - 4)
        add.tap()
        let title = app.textFields["Titolo"]
        XCTAssertTrue(title.waitForExistence(timeout: 10))
        title.tap(); title.typeText("Evento dopo scorrimento")
        app.buttons["Salva"].tap()
        XCTAssertTrue(app.tabBars.buttons["Calendario"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.staticTexts["Evento dopo scorrimento"].waitForExistence(timeout: 10))
        capture("calendar-event-after-scroll")
        for _ in 0..<4 { scroll.swipeDown(velocity: .fast) }
        app.navigationBars.buttons["Aggiungi evento"].tap()
        XCTAssertTrue(app.textFields["Titolo"].waitForExistence(timeout: 10))
        app.buttons["Annulla"].tap()
    }
    func testLongTaskOpensAfterScrollingWithoutTriggeringCompletion() {
        let app = launch(["--stress-content"])
        app.tabBars.buttons["Attività"].tap()
        let title = "Attività lunga di verifica 1: pianificare e organizzare gli impegni della settimana"
        XCTAssertTrue(app.staticTexts[title].waitForExistence(timeout: 10))
        app.staticTexts[title].tap()
        XCTAssertTrue(app.navigationBars["Modifica attività"].waitForExistence(timeout: 10))
        capture("long-task-editor")
        app.buttons["Annulla"].tap()
        XCTAssertTrue(app.staticTexts[title].exists)
    }
    func testDashboardDayRestoresCalendarMonthAndSelection() {
        let app = launch()
        app.tabBars.buttons["Calendario"].tap()
        app.buttons["Mese precedente"].tap()
        app.tabBars.buttons["Dashboard"].tap()
        let formatter = DateFormatter(); formatter.locale = Locale(identifier: "en_US_POSIX"); formatter.timeZone = TimeZone(identifier: "Europe/Rome"); formatter.dateFormat = "yyyy-MM-dd"
        let day = formatter.string(from: Date())
        app.buttons["dashboard-day-" + day].tap()
        let selected = app.buttons["calendar-day-" + day]
        XCTAssertTrue(selected.waitForExistence(timeout: 10))
        XCTAssertTrue(selected.isSelected)
    }
    func testNegativeBudgetAndGroupedAmounts() {
        let app = launch(["--stress-money", "--dark"])
        app.tabBars.buttons["Finanza"].tap()
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "1.234,56")).firstMatch.waitForExistence(timeout: 10))
        XCTAssertTrue((app.buttons["savings-ring"].value as? String ?? "").contains("12.345,67"))
        capture("negative-budget-and-grouped-amounts")
    }
    func testFinanceMonthButtonsMoveIndependentlyInBothDirections() {
        let app = launch(["--dark"])
        app.tabBars.buttons["Finanza"].tap()
        app.segmentedControls.buttons["Extra"].tap()
        let formatter = DateFormatter(); formatter.locale = Locale(identifier: "it_IT"); formatter.timeZone = TimeZone(identifier: "Europe/Rome"); formatter.dateFormat = "MMMM yyyy"
        var calendar = Calendar(identifier: .gregorian); calendar.timeZone = formatter.timeZone
        let current = formatter.string(from: Date()).capitalized
        let previous = formatter.string(from: calendar.date(byAdding: .month, value: -1, to: Date())!).capitalized
        app.buttons["Mese precedente"].tap()
        XCTAssertTrue(app.staticTexts[previous].waitForExistence(timeout: 10))
        app.buttons["Mese successivo"].tap()
        XCTAssertTrue(app.staticTexts[current].waitForExistence(timeout: 10))
        capture("extra-month-navigation")
    }
    func testVisibleShiftBrushPaintsAndUndoRestoresDay() {
        let app = launch(["--dark"])
        app.tabBars.buttons["Calendario"].tap()
        app.buttons["toggle-shift-paint"].tap()
        let brush = app.buttons["shift-brush-afternoon"]
        XCTAssertTrue(brush.waitForExistence(timeout: 10)); brush.tap()
        let formatter = DateFormatter(); formatter.locale = Locale(identifier: "en_US_POSIX"); formatter.timeZone = TimeZone(identifier: "Europe/Rome"); formatter.dateFormat = "yyyy-MM-dd"
        let day = app.buttons["calendar-day-" + formatter.string(from: Date())]
        day.tap()
        XCTAssertTrue(day.label.contains("Pomeriggio"))
        capture("calendar-paint-palette")
        app.buttons["Annulla"].tap()
        XCTAssertTrue(day.label.contains("Mattina"))
        app.buttons["toggle-shift-paint"].tap()
    }
    func testSavingsBreakdownAndDirectTaskReorder() {
        let app = launch(["--dark"])
        app.tabBars.buttons["Finanza"].tap()
        app.buttons["savings-ring"].tap()
        XCTAssertTrue(app.navigationBars["Risparmi"].waitForExistence(timeout: 10))
        capture("savings-breakdown")
        app.buttons["Fine"].tap()
        app.tabBars.buttons["Attività"].tap()
        XCTAssertTrue(app.buttons["Desideri"].exists)
        app.buttons["reorder-tasks"].tap()
        capture("task-categories-and-reorder")
        app.buttons["reorder-tasks"].tap()
    }
    func testExtraActualPaymentUsesSavingsAndKeepsMonthlyBudget() {
        let app = launch(["--stress-money", "--dark"])
        app.tabBars.buttons["Finanza"].tap()
        app.segmentedControls.buttons["Extra"].tap()
        app.staticTexts["Manutenzione auto"].tap()
        XCTAssertTrue(app.navigationBars["Spesa extra"].waitForExistence(timeout: 10))
        let payment = app.textFields["Importo pagato €"]
        for _ in 0..<6 { if payment.isHittable { break }; app.collectionViews.firstMatch.swipeUp() }
        XCTAssertTrue(payment.isHittable)
        payment.tap()
        let old = payment.value as? String ?? ""
        payment.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: old.count) + "550,01")
        let done = app.buttons["extra-keyboard-done"]
        XCTAssertTrue(done.waitForExistence(timeout: 10)); done.tap()
        XCTAssertFalse(app.keyboards.firstMatch.exists)
        let pay = app.buttons["extra-pay-savings"]
        for _ in 0..<6 { if pay.isHittable { break }; app.collectionViews.firstMatch.swipeUp() }
        XCTAssertTrue(pay.isHittable)
        capture("extra-before-actual-payment")
        pay.tap()
        XCTAssertTrue(app.staticTexts["Pagata"].waitForExistence(timeout: 10))
        capture("extra-closed-with-actual-payment")
        app.segmentedControls.buttons["Panoramica"].tap()
        XCTAssertTrue((app.buttons["savings-ring"].value as? String ?? "").contains("11.795,66"))
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "1.234,56")).firstMatch.exists)
    }
    func testDetailedChartsHaveReadableCategoryBreakdown() {
        let app = launch(["--stress-money", "--dark"])
        app.tabBars.buttons["Finanza"].tap()
        let details = app.buttons["Analisi e storico"]
        for _ in 0..<8 { if details.isHittable { break }; app.collectionViews.firstMatch.swipeUp() }
        XCTAssertTrue(details.isHittable); details.tap()
        XCTAssertTrue(app.navigationBars["Analisi"].waitForExistence(timeout: 10))
        let bars = app.staticTexts["Entrate e uscite"]
        for _ in 0..<6 { if bars.isHittable { break }; app.collectionViews.firstMatch.swipeUp() }
        XCTAssertTrue(bars.isHittable)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.78)).press(forDuration: 0.05, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)))
        capture("finance-dense-bars")
        let categories = app.staticTexts["Spese per categoria"]
        for _ in 0..<6 { if categories.isHittable { break }; app.collectionViews.firstMatch.swipeUp() }
        XCTAssertTrue(categories.isHittable)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.78)).press(forDuration: 0.05, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)))
        capture("finance-category-breakdown")
    }
    func testGoalsAreIndependentlyEditableAndReloadAfterSave() {
        let app = launch(["--dark"])
        app.tabBars.buttons["Finanza"].tap()
        let edit = app.buttons["Obiettivo e fondo emergenza"]
        for _ in 0..<4 { if edit.isHittable { break }; app.collectionViews.firstMatch.swipeUp() }
        XCTAssertTrue(edit.isHittable); edit.tap()
        XCTAssertTrue(app.navigationBars["Obiettivo e fondo"].waitForExistence(timeout: 10))
        for (id, value) in [("emergency-input", "6000,00"), ("savings-target-input", "15000,00")] {
            let field = app.textFields[id]; XCTAssertTrue(field.exists); field.tap()
            let old = field.value as? String ?? ""
            field.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: old.count) + value)
        }
        app.navigationBars.buttons["Salva"].tap()
        XCTAssertTrue(app.navigationBars["Finanza"].waitForExistence(timeout: 10))
        edit.tap()
        XCTAssertEqual(app.textFields["emergency-input"].value as? String, "6000,00")
        XCTAssertEqual(app.textFields["savings-target-input"].value as? String, "15000,00")
        capture("independent-goals-saved")
    }
    func testFinanceHasTwoTabsAndForecastAndDirectMovements() {
        let app = launch(["--dark"])
        XCTAssertFalse(app.buttons["savings-ring"].exists)
        app.tabBars.buttons["Attività"].tap()
        XCTAssertFalse(app.textFields["Cerca attività"].exists)
        app.tabBars.buttons["Finanza"].tap()
        XCTAssertFalse(app.segmentedControls.buttons["Movimenti"].exists)
        let chart = app.otherElements["wealth-forecast-chart"]
        for _ in 0..<6 { if chart.isHittable { break }; app.collectionViews.firstMatch.swipeUp() }
        XCTAssertTrue(chart.exists)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.78)).press(forDuration: 0.05, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.52)))
        capture("wealth-six-month-forecast")
        let all = app.buttons["all-movements"]
        for _ in 0..<6 { if all.isHittable { break }; app.collectionViews.firstMatch.swipeUp() }
        XCTAssertTrue(all.isHittable); all.tap()
        XCTAssertTrue(app.navigationBars["Movimenti"].waitForExistence(timeout: 10))
        capture("all-movements-direct")
    }

}
