import XCTest

final class NativeInterfaceTests: XCTestCase {
    private func launch(_ extra: [String] = []) -> XCUIApplication {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--visual-test", "-AppleLanguages", "(it)", "-AppleLocale", "it_IT"] + extra
        app.launch()
        XCTAssertTrue(app.tabBars.buttons["Dashboard"].waitForExistence(timeout: 30))
        return app
    }
    private func capture(_ name: String) {
        let shot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        shot.name = name; shot.lifetime = .keepAlways; add(shot)
    }
    func testFourSectionsInBothThemes() {
        for dark in [false, true] {
            let app = launch(dark ? ["--dark"] : [])
            for tab in ["Dashboard", "Attività", "Calendario", "Finanza"] {
                app.tabBars.buttons[tab].tap()
                XCTAssertTrue(app.navigationBars[tab].waitForExistence(timeout: 10))
                capture((dark ? "dark-" : "light-") + tab)
            }
            app.terminate()
        }
    }
    func testKeyboardAndLocalMovementFlow() {
        let app = launch()
        app.buttons["Aggiungi spesa"].tap()
        let description = app.textFields["Descrizione"]
        XCTAssertTrue(description.waitForExistence(timeout: 10))
        description.tap(); description.typeText("Verifica interfaccia")
        capture("movement-keyboard")
        let amount = app.textFields["Importo €"]
        amount.tap(); amount.typeText("2")
        app.buttons["Salva"].tap()
        XCTAssertTrue(app.tabBars.buttons["Finanza"].waitForExistence(timeout: 10))
        app.tabBars.buttons["Finanza"].tap()
        app.segmentedControls.buttons["Movimenti"].tap()
        XCTAssertTrue(app.buttons.containing(.staticText, identifier: "Verifica interfaccia").firstMatch.waitForExistence(timeout: 10))
        capture("movement-saved-locally")
    }
    func testLargeTextAndSixWeekCalendar() {
        let app = launch(["--large-text", "--six-weeks"])
        capture("accessibility-dashboard")
        app.tabBars.buttons["Calendario"].tap()
        XCTAssertTrue(app.staticTexts["Marzo 2026"].waitForExistence(timeout: 10))
        capture("accessibility-six-weeks")
        app.terminate()
    }
    func testNativeSignInKeyboard() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--visual-test", "--signin-preview", "--dark", "-AppleLanguages", "(it)", "-AppleLocale", "it_IT"]
        app.launch()
        let password = app.secureTextFields["Password"]
        XCTAssertTrue(password.waitForExistence(timeout: 30))
        password.tap(); password.typeText("demo-only")
        capture("native-signin-keyboard")
        app.terminate()
    }
    func testRepeatedBoundaryScrollingKeepsNavigationStable() {
        let app = launch(["--stress-content", "--dark"])
        for tab in ["Dashboard", "Attività", "Calendario", "Finanza"] {
            app.tabBars.buttons[tab].tap()
            let tabs = app.tabBars.firstMatch
            let before = tabs.frame
            let surface = (tab == "Attività" || tab == "Finanza") ? app.collectionViews.firstMatch : app.scrollViews[tab == "Dashboard" ? "dashboard-scroll" : "calendar-scroll"]
            XCTAssertTrue(surface.waitForExistence(timeout: 10))
            for _ in 0..<4 { surface.swipeUp(velocity: .fast) }
            for _ in 0..<3 { surface.swipeUp(velocity: .fast) }
            for _ in 0..<7 { surface.swipeDown(velocity: .fast) }
            XCTAssertTrue(app.tabBars.buttons["Dashboard"].isHittable)
            XCTAssertTrue(app.tabBars.buttons["Calendario"].isHittable)
            XCTAssertEqual(before.height, tabs.frame.height, accuracy: 2)
            capture("boundary-" + tab)
        }
    }
    func testCalendarEventCanBeCreatedAfterBoundaryScroll() {
        let app = launch(["--dark"])
        app.tabBars.buttons["Calendario"].tap()
        let scroll = app.scrollViews["calendar-scroll"]
        XCTAssertTrue(scroll.waitForExistence(timeout: 10))
        for _ in 0..<4 { scroll.swipeUp(velocity: .fast) }
        let add = app.buttons["calendar-add-event"]
        XCTAssertTrue(add.isHittable)
        XCTAssertLessThan(add.frame.maxY, app.tabBars.firstMatch.frame.minY - 4)
        add.tap()
        let title = app.textFields["Titolo"]
        XCTAssertTrue(title.waitForExistence(timeout: 10))
        title.tap(); title.typeText("Evento dopo scorrimento")
        app.buttons["Salva"].tap()
        XCTAssertTrue(app.tabBars.buttons["Calendario"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.staticTexts["Evento dopo scorrimento"].waitForExistence(timeout: 10))
        capture("calendar-event-after-scroll")
        for _ in 0..<4 { scroll.swipeDown(velocity: .fast) }
        app.navigationBars.buttons["Aggiungi evento"].tap()
        XCTAssertTrue(app.textFields["Titolo"].waitForExistence(timeout: 10))
        app.buttons["Annulla"].tap()
    }
    func testLongTaskOpensAfterScrollingWithoutTriggeringCompletion() {
        let app = launch(["--stress-content"])
        app.tabBars.buttons["Attività"].tap()
        let title = "Attività lunga di verifica 1: pianificare e organizzare gli impegni della settimana"
        XCTAssertTrue(app.staticTexts[title].waitForExistence(timeout: 10))
        app.staticTexts[title].tap()
        XCTAssertTrue(app.navigationBars["Modifica attività"].waitForExistence(timeout: 10))
        capture("long-task-editor")
        app.buttons["Annulla"].tap()
        XCTAssertTrue(app.staticTexts[title].exists)
    }
    func testDashboardDayRestoresCalendarMonthAndSelection() {
        let app = launch()
        app.tabBars.buttons["Calendario"].tap()
        app.buttons["Mese precedente"].tap()
        app.tabBars.buttons["Dashboard"].tap()
        let formatter = DateFormatter(); formatter.locale = Locale(identifier: "en_US_POSIX"); formatter.timeZone = TimeZone(identifier: "Europe/Rome"); formatter.dateFormat = "yyyy-MM-dd"
        let day = formatter.string(from: Date())
        app.buttons["dashboard-day-" + day].tap()
        let selected = app.buttons["calendar-day-" + day]
        XCTAssertTrue(selected.waitForExistence(timeout: 10))
        XCTAssertTrue(selected.isSelected)
    }
    func testNegativeBudgetAndGroupedAmounts() {
        let app = launch(["--stress-money", "--dark"])
        app.tabBars.buttons["Finanza"].tap()
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "1.234,56")).firstMatch.waitForExistence(timeout: 10))
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "12.345,67")).firstMatch.exists)
        capture("negative-budget-and-grouped-amounts")
    }
}
