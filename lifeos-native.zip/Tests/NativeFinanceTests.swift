import XCTest
@testable import LifeOSProbe
final class NativeFinanceTests: XCTestCase {
    func testBudgetBarReconcilesPaidFixedBillsWithoutDoubleCounting() {
        let x = NativeBudgetSegments(["monthlySalary": .number(2000), "monthlyCommitted": .number(1000), "monthlySpent": .number(200), "monthlyRemaining": .number(800), "monthlyFixedSettlements": .array([.object(["paid": .number(550), "estimate": .number(500)])])])
        XCTAssertEqual(x.spent, 700); XCTAssertEqual(x.reserved, 500); XCTAssertEqual(x.adjustment, 0)
    }
    func testBudgetOverspendingIsNotHiddenByBarScale() {
        let x = NativeBudgetSegments(["monthlySalary": .number(1000), "monthlyCommitted": .number(800), "monthlySpent": .number(400), "monthlyRemaining": .number(-200)])
        XCTAssertEqual(x.remaining, -200); XCTAssertEqual(x.adjustment, 0); XCTAssertEqual(x.scale, 1200)
    }
    func testIndependentGoalsPersistAndDoNotAdvanceAutomatically() throws {
        var state = DemoData.make()
        try DemoActions.apply("savePlanningSettings", [:], args: [.number(6000), .number(400), .number(15000)], state: &state)
        let decoded = try JSONDecoder().decode(NativeArchive.self, from: JSONEncoder().encode(state))
        let p = NativeSavingsProgress(summary: ["budget": .number(7000)], planning: decoded.finance.record("planning"))
        XCTAssertEqual(p.emergency, 6000); XCTAssertEqual(p.target, 15000); XCTAssertEqual(p.missing, 8000)
        XCTAssertEqual(NativeSavingsProgress(summary: ["budget": .number(16000)], planning: decoded.finance.record("planning")).target, 15000)
    }
    private func finance(_ nets: [Double]) -> Record {
        let rows = nets.enumerated().map { index, n in JSONValue.object(["month": .string(String(format: "2026-%02d", index + 4)), "observed": .bool(true), "ordinaryNet": .number(n)]) }
        return ["summary": .object(["budget": .number(10000)]), "forecastHistory": .array(rows)]
    }
    func testNewGoalIsIncludedInForecastAndPaidRecoveryDoesNotBecomeAnotherFutureExpense() {
        var f = finance(Array(repeating: 100, count: 6))
        let goal: Record = ["id": .string("new-goal"), "kind": .string("goal"), "status": .string("active"), "endMonth": .string("2026-12"), "amountCents": .int(60000)]
        let recovery: Record = ["id": .string("new-recovery"), "kind": .string("recovery"), "status": .string("active"), "endMonth": .string("2026-12"), "amountCents": .int(30000)]
        f["plansV2"] = .object(["plans": .array([.object(goal), .object(recovery)])])
        let forecast = NativeWealthForecast(finance: f, plan: [:], day: "2026-10-14")
        XCTAssertEqual(forecast.knownExtra, 600)
        XCTAssertEqual(forecast.prediction.last?.value, 10000)
    }
    func testIncompleteHistoryDoesNotProduceInventedForecast() {
        var f = finance([100, 100, 100]); f["forecastHistory"] = .array(f.records("forecastHistory").map(JSONValue.object) + [.object(["month": .string("2026-10"), "observed": .bool(true), "ordinaryNet": .number(9000)])])
        let x = NativeWealthForecast(finance: f, plan: [:], day: "2026-10-14")
        XCTAssertEqual(x.samples, 3); XCTAssertTrue(x.prediction.isEmpty)
    }
    func testExtraIsDeductedOnceAtDueDateAndNetOfPreviousPayments() {
        let row: Record = ["cycle_id": .int(1), "kind": .string("expense"), "status": .string("Programmato"), "end_month": .string("2026-12"), "total_cents": .int(60000)]
        let plan: Record = ["allocations": .array(Array(repeating: .object(row), count: 6)), "links": .array([.object(["cycle_id": .int(1), "role": .string("payment"), "attributed_cents": .int(10000)])])]
        let x = NativeWealthForecast(finance: finance(Array(repeating: 100, count: 6)), plan: plan, day: "2026-10-14")
        XCTAssertEqual(x.prediction.count, 7); XCTAssertEqual(x.knownExtra, 500)
        XCTAssertEqual(x.prediction[2].value, 10200); XCTAssertEqual(x.prediction[3].value, 9800); XCTAssertEqual(x.prediction.last!.value, 10100)
    }
    func testPaidAndCancelledPlansDoNotReduceForecast() {
        let rows: [JSONValue] = ["Pagato", "Annullato"].map { .object(["cycle_id": .int(1), "kind": .string("expense"), "status": .string($0), "end_month": .string("2026-12"), "total_cents": .int(60000)]) }
        let x = NativeWealthForecast(finance: finance(Array(repeating: 100, count: 6)), plan: ["allocations": .array(rows)], day: "2026-10-14")
        XCTAssertEqual(x.knownExtra, 0); XCTAssertEqual(x.prediction.last!.value, 10600)
    }
    func testOutlierIsLimitedAndBandIsReproducible() {
        let f = finance([100, 110, 120, 130, 140, -20000])
        let a = NativeWealthForecast(finance: f, plan: [:], day: "2026-10-14"), b = NativeWealthForecast(finance: f, plan: [:], day: "2026-10-14")
        XCTAssertGreaterThan(a.normalizedNet, 0); XCTAssertEqual(a.prediction.last!.lower, b.prediction.last!.lower)
        for p in a.prediction { XCTAssertLessThanOrEqual(p.lower, p.value); XCTAssertGreaterThanOrEqual(p.upper, p.value) }
        XCTAssertLessThan(a.prediction.last!.lower, a.prediction.last!.upper)
    }
    func testForecastUsesActualExtraPriceWithOldAndNewGatewayWithoutDoubleCorrection() {
        var f = finance([1850, 1900, 1950, 2000, 2050, 1950])
        var rows = f.records("forecastHistory"); rows[5]["extraPaid"] = .number(600); f["forecastHistory"] = .array(rows.map(JSONValue.object))
        let link: Record = ["cycle_id": .int(1), "movement_source_row": .int(9), "role": .string("payment"), "account": .string("Trade Republic"), "actual_date": .string("2026-09-20"), "amount": .number(-650), "attributed_cents": .int(60000)]
        let plan: Record = ["links": .array([.object(link)]), "settlements": .array([.object(["cycle_id": .int(1), "movement_source_row": .int(9), "actual_cents": .int(65000)])])]
        let old = NativeWealthForecast(finance: f, plan: plan, day: "2026-10-14")
        let reference = NativeWealthForecast(finance: finance([1850, 1900, 1950, 2000, 2050, 2000]), plan: [:], day: "2026-10-14")
        XCTAssertEqual(old.normalizedNet, reference.normalizedNet, accuracy: 0.001)
        rows[5]["extraPaid"] = .number(650); rows[5]["ordinaryNet"] = .number(2000); f["forecastHistory"] = .array(rows.map(JSONValue.object))
        XCTAssertEqual(NativeWealthForecast(finance: f, plan: plan, day: "2026-10-14").normalizedNet, reference.normalizedNet, accuracy: 0.001)
    }

    func testForecastUsesWorkerMeasuredAndEstimatedBalanceHistory() {
        var data = finance([100, 100, 100, 100, 100, 100])
        data["wealthHistory"] = .array([
            .object(["month": .string("2026-08"), "measured": .number(8000), "estimated": .number(7900)]),
            .object(["month": .string("2026-09"), "measured": .null, "estimated": .number(9000)]),
            .object(["month": .string("2026-11"), "estimated": .number(12000)])])
        let model = NativeWealthForecast(finance: data, plan: [:], day: "2026-10-17")
        XCTAssertEqual(model.history.map(\.value), [8000, 9000, 10000])
        XCTAssertEqual(model.history.map(\.day), ["2026-08-31", "2026-09-30", "2026-10-17"])
    }
    func testForecastKeepsPriorYearHistoryAndFallsBackWhenDetailIsNull() {
        var data = finance([100, 100, 100, 100, 100, 100])
        data["lifetime"] = .object(["series": .array([
            .object(["month": .string("2025-12"), "wealth": .number(8000)]),
            .object(["month": .string("2026-01"), "wealth": .number(9000)])])])
        data["wealthHistory"] = .array([.object(["month": .string("2026-01"), "measured": .null, "estimated": .null])])
        let model = NativeWealthForecast(finance: data, plan: [:], day: "2026-02-17")
        XCTAssertEqual(model.history.map(\.value), [8000, 9000, 10000])
    }
    func testOverviewKeepsHistoricalBudgetSeparateFromCurrentBalance() {
        let summary: Record = ["budget": .number(7553.59), "monthlyRemaining": .number(72.19)]
        let old = NativeFinanceOverview(summary: summary, month: "2026-09", day: "2026-10-16")
        XCTAssertEqual(old.balance, 7553.59); XCTAssertEqual(old.remaining, 72.19)
        XCTAssertEqual(old.days, 0); XCTAssertTrue(old.periodLabel.contains("Mese concluso"))
        let current = NativeFinanceOverview(summary: summary, month: "2026-10", day: "2026-10-16")
        XCTAssertEqual(current.days, 16); XCTAssertEqual(current.daily, 72.19 / 16, accuracy: 0.00001)
        XCTAssertTrue(current.periodLabel.contains("incluso oggi"))
        let future = NativeFinanceOverview(summary: summary, month: "2028-02", day: "2026-10-16")
        XCTAssertEqual(future.days, 29); XCTAssertFalse(future.periodLabel.contains("incluso oggi"))
    }
    func testOverviewPreservesNegativeMoneyAndDistinguishesMissingFromZero() {
        let negative = NativeFinanceOverview(summary: ["budget": .number(-15), "monthlyRemaining": .number(-1234.56)], month: "2026-10", day: "2026-10-16")
        XCTAssertEqual(negative.balance, -15); XCTAssertLessThan(negative.daily, 0)
        let missing = NativeFinanceOverview(summary: [:], month: "2026-10", day: "2026-10-16")
        XCTAssertNil(missing.balance); XCTAssertNil(missing.remaining)
        let zero = NativeFinanceOverview(summary: ["budget": .number(0), "monthlyRemaining": .number(0)], month: "2026-10", day: "2026-10-16")
        XCTAssertEqual(zero.balance, 0); XCTAssertEqual(zero.remaining, 0)
        let invalid = NativeFinanceOverview(summary: ["budget": .number(.nan), "monthlyRemaining": .number(.infinity)], month: "2026-10", day: "2026-10-16")
        XCTAssertNil(invalid.balance); XCTAssertNil(invalid.remaining)
    }

}
