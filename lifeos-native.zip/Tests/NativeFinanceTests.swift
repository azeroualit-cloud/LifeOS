import XCTest
@testable import LifeOSProbe
final class NativeFinanceTests: XCTestCase {
    func testBudgetBarReconcilesPaidFixedBillsWithoutDoubleCounting() {
        let x = NativeBudgetSegments(["monthlySalary": .number(2000), "monthlyCommitted": .number(1000), "monthlySpent": .number(200), "monthlyRemaining": .number(800), "monthlyFixedSettlements": .array([.object(["paid": .number(550), "estimate": .number(500)])])])
        XCTAssertEqual(x.spent, 700); XCTAssertEqual(x.reserved, 500); XCTAssertEqual(x.adjustment, 0)
    }
    func testBudgetOverspendingIsNotHiddenByBarScale() {
        let x = NativeBudgetSegments(["monthlySalary": .number(1000), "monthlyCommitted": .number(800), "monthlySpent": .number(400), "monthlyRemaining": .number(-200)])
        XCTAssertEqual(x.remaining, -200); XCTAssertEqual(x.adjustment, 0); XCTAssertEqual(x.scale, 1200)
    }
    func testIndependentGoalsPersistAndDoNotAdvanceAutomatically() throws {
        var state = DemoData.make()
        try DemoActions.apply("savePlanningSettings", [:], args: [.number(6000), .number(400), .number(15000)], state: &state)
        let decoded = try JSONDecoder().decode(NativeArchive.self, from: JSONEncoder().encode(state))
        let p = NativeSavingsProgress(summary: ["budget": .number(7000)], planning: decoded.finance.record("planning"))
        XCTAssertEqual(p.emergency, 6000); XCTAssertEqual(p.target, 15000); XCTAssertEqual(p.missing, 8000)
        XCTAssertEqual(NativeSavingsProgress(summary: ["budget": .number(16000)], planning: decoded.finance.record("planning")).target, 15000)
    }
    private func finance(_ nets: [Double]) -> Record {
        let rows = nets.enumerated().map { index, n in JSONValue.object(["month": .string(String(format: "2026-%02d", index + 4)), "observed": .bool(true), "ordinaryNet": .number(n)]) }
        return ["summary": .object(["budget": .number(10000)]), "forecastHistory": .array(rows)]
    }
    func testIncompleteHistoryDoesNotProduceInventedForecast() {
        var f = finance([100, 100, 100]); f["forecastHistory"] = .array(f.records("forecastHistory").map(JSONValue.object) + [.object(["month": .string("2026-10"), "observed": .bool(true), "ordinaryNet": .number(9000)])])
        let x = NativeWealthForecast(finance: f, plan: [:], day: "2026-10-14")
        XCTAssertEqual(x.samples, 3); XCTAssertTrue(x.prediction.isEmpty)
    }
    func testExtraIsDeductedOnceAtDueDateAndNetOfPreviousPayments() {
        let row: Record = ["cycle_id": .int(1), "kind": .string("expense"), "status": .string("Programmato"), "end_month": .string("2026-12"), "total_cents": .int(60000)]
        let plan: Record = ["allocations": .array(Array(repeating: .object(row), count: 6)), "links": .array([.object(["cycle_id": .int(1), "role": .string("payment"), "attributed_cents": .int(10000)])])]
        let x = NativeWealthForecast(finance: finance(Array(repeating: 100, count: 6)), plan: plan, day: "2026-10-14")
        XCTAssertEqual(x.prediction.count, 7); XCTAssertEqual(x.knownExtra, 500)
        XCTAssertEqual(x.prediction[2].value, 10200); XCTAssertEqual(x.prediction[3].value, 9800); XCTAssertEqual(x.prediction.last!.value, 10100)
    }
    func testPaidAndCancelledPlansDoNotReduceForecast() {
        let rows: [JSONValue] = ["Pagato", "Annullato"].map { .object(["cycle_id": .int(1), "kind": .string("expense"), "status": .string($0), "end_month": .string("2026-12"), "total_cents": .int(60000)]) }
        let x = NativeWealthForecast(finance: finance(Array(repeating: 100, count: 6)), plan: ["allocations": .array(rows)], day: "2026-10-14")
        XCTAssertEqual(x.knownExtra, 0); XCTAssertEqual(x.prediction.last!.value, 10600)
    }
    func testOutlierIsLimitedAndBandIsReproducible() {
        let f = finance([100, 110, 120, 130, 140, -20000])
        let a = NativeWealthForecast(finance: f, plan: [:], day: "2026-10-14"), b = NativeWealthForecast(finance: f, plan: [:], day: "2026-10-14")
        XCTAssertGreaterThan(a.normalizedNet, 0); XCTAssertEqual(a.prediction.last!.lower, b.prediction.last!.lower)
        for p in a.prediction { XCTAssertLessThanOrEqual(p.lower, p.value); XCTAssertGreaterThanOrEqual(p.upper, p.value) }
        XCTAssertLessThan(a.prediction.last!.lower, a.prediction.last!.upper)
    }
}
