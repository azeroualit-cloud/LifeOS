import XCTest
@testable import LifeOSProbe

final class NativeRoutineScheduleTests: XCTestCase {
    func testLegacyHabitsRemainDailyAndIntervalsUseCivilDaysAcrossDST() throws {
        XCTAssertTrue(try NativeRoutineSchedule(nil).isDue(on: "2026-10-18"))
        let schedule = try NativeRoutineSchedule(.object(["mode": .string("interval"), "intervalDays": .int(2), "startDate": .string("2026-10-24")]))
        XCTAssertTrue(schedule.isDue(on: "2026-10-24")); XCTAssertFalse(schedule.isDue(on: "2026-10-25")); XCTAssertTrue(schedule.isDue(on: "2026-10-26"))
        XCTAssertFalse(schedule.isDue(on: "2026-10-23")); XCTAssertTrue(schedule.isDue(on: "2026-10-28"))
    }
    func testWeekdaysStartDateAndInvalidInput() throws {
        let schedule = try NativeRoutineSchedule(.object(["mode": .string("weekdays"), "weekdays": .array([.int(7), .int(1), .int(1)]), "startDate": .string("2026-10-19")]))
        XCTAssertEqual(schedule.days, [1, 7]); XCTAssertFalse(schedule.isDue(on: "2026-10-18")); XCTAssertTrue(schedule.isDue(on: "2026-10-19")); XCTAssertFalse(schedule.isDue(on: "2026-10-20")); XCTAssertTrue(schedule.isDue(on: "2026-10-25"))
        XCTAssertThrowsError(try NativeRoutineSchedule(.object(["mode": .string("weekdays"), "weekdays": .array([]), "startDate": .string("2026-10-19")])))
        XCTAssertThrowsError(try NativeRoutineSchedule(.object(["mode": .string("interval"), "intervalDays": .int(0), "startDate": .string("2026-10-19")])))
        XCTAssertFalse(NativeRoutineSchedule.validDay("2026-02-30")); XCTAssertTrue(NativeRoutineSchedule.validDay("2028-02-29"))
    }
    func testDemoScheduleEditingPreservesCompletionAndRejectsOffDayCheck() throws {
        var state = DemoData.make()
        let schedule: JSONValue = .object(["mode": .string("weekdays"), "weekdays": .array([.int(1)]), "startDate": .string(CivilDate.adding(1, to: CivilDate.day()))])
        try DemoActions.apply("setRoutineCheck", ["id": .int(1), "day": .string(CivilDate.day()), "checked": .bool(true)], args: nil, state: &state)
        try DemoActions.apply("saveRoutine", ["id": .int(1), "title": .string("Lettura"), "schedule": schedule], args: nil, state: &state)
        XCTAssertTrue(state.life.records("routines")[0].flag("checked"))
        XCTAssertThrowsError(try DemoActions.apply("setRoutineCheck", ["id": .int(1), "day": .string(CivilDate.day()), "checked": .bool(true)], args: nil, state: &state))
        try DemoActions.apply("saveRoutine", ["id": .int(1), "title": .string("Altro nome")], args: nil, state: &state)
        XCTAssertEqual(state.life.records("routines")[0]["schedule"], try NativeRoutineSchedule(schedule).value)
    }
}
