import Foundation
import XCTest
@testable import LifeOSProbe

final class ShiftCalendarLinkTests: XCTestCase {
    private let path = "/calendar/turni/" + String(repeating: "a", count: 64) + ".ics"
    func testSubscriptionUsesTheConfiguredServerWithoutForwardingCredentials() {
        let server = URL(string: "https://user:password@lifeos.example/old?key=private#fragment")
        XCTAssertEqual(ShiftCalendarLink.subscription(server: server, path: path)?.absoluteString, "webcal://lifeos.example" + path)
    }
    func testSubscriptionRejectsExternalMalformedAndInsecureLinks() {
        for candidate in ["https://external.example" + path, path + "?extra=1", path + "/extra", "/calendar/turni/short.ics", "//external.example/feed.ics"] {
            XCTAssertNil(ShiftCalendarLink.subscription(server: URL(string: "https://lifeos.example"), path: candidate))
        }
        XCTAssertNil(ShiftCalendarLink.subscription(server: nil, path: path))
        XCTAssertNil(ShiftCalendarLink.subscription(server: URL(string: "http://lifeos.example"), path: path))
    }
}
