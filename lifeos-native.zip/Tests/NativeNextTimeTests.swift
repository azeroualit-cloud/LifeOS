import XCTest
@testable import LifeOSProbe

final class NativeNextTimeTests: XCTestCase {
    private func date(_ day: String, hour: Int, minute: Int) -> Date {
        CivilDate.calendar.date(bySettingHour: hour, minute: minute, second: 0, of: CivilDate.date(day))!
    }
    func testFiveNeutralTimesExcludeSunriseAndHaveValidClockValues() {
        for day in ["2026-03-29", "2026-06-21", "2026-10-25", "2026-12-21"] {
            let times = NativeNextTime.schedule(day: day)
            XCTAssertEqual(times.count, 5)
            XCTAssertFalse(times.contains { $0.label == "Alba" })
            XCTAssertEqual(Set(times.map(\.label)), Set(["Prima dell’alba", "Mezzogiorno", "Pomeriggio", "Tramonto", "Notte"]))
            for time in times { XCTAssertNotNil(time.time.range(of: #"^([01]\d|2[0-3]):[0-5]\d$"#, options: .regularExpression)) }
        }
    }
    func testNextTimeSkipsPassedEntriesAndExactMinute() {
        let day = "2026-10-16", times = NativeNextTime.schedule(day: "2026-10-16")
        let first = times[0], parts = first.time.split(separator: ":").map { Int($0)! }
        let next = NativeNextTime.next(now: date(day, hour: parts[0], minute: parts[1]))
        XCTAssertEqual(next?.label, times[1].label)
        XCTAssertEqual(next?.time, times[1].time); XCTAssertEqual(next?.tomorrow, false)
    }
    func testTomorrowRolloverUsesNextDateAndExplicitLabel() {
        for day in ["2026-12-31", "2028-02-28", "2026-03-28", "2026-10-24"] {
            let next = NativeNextTime.next(now: date(day, hour: 23, minute: 59))
            let tomorrow = CivilDate.adding(1, to: day)
            XCTAssertEqual(next?.day, tomorrow); XCTAssertEqual(next?.tomorrow, true)
            XCTAssertEqual(next?.time, NativeNextTime.schedule(day: tomorrow).first?.time)
            XCTAssertTrue(next?.displayTime.hasPrefix("Domani · ") == true)
        }
    }
}
