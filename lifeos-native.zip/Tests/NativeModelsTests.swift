import XCTest
@testable import LifeOSProbe

final class NativeModelsTests: XCTestCase {
    func testSnapshotChoiceMatchesTheBankDateAndIsNeverOfferedForTransfers() {
        let summary: Record = ["assetDate": .string("2026-10-10"), "balanceDate": .string("2026-09-01")]
        XCTAssertTrue(NativeValidation.canIncludeInSnapshot(summary, account: "Trade Republic", type: "Spesa", day: "2026-10-10", editing: false))
        XCTAssertFalse(NativeValidation.canIncludeInSnapshot(summary, account: "Trade Republic", type: "Spesa", day: "2026-10-11", editing: false))
        XCTAssertFalse(NativeValidation.canIncludeInSnapshot(summary, account: "Trade Republic", type: "Trasferimento", day: "2026-10-01", editing: false))
        XCTAssertFalse(NativeValidation.canIncludeInSnapshot(summary, account: "Trade Republic", type: "Spesa", day: "2026-10-01", editing: true))
        XCTAssertFalse(NativeValidation.canIncludeInSnapshot([:], account: "Trade Republic", type: "Spesa", day: "2026-10-01", editing: false))
    }
    func testLargeNetworkResponseDoesNotUseImportFileSizeLimit() throws {
        let response: JSONValue = .object([
            "summary": .object(["budget": .number(100), "committedCurrent": .number(20), "remainingFree": .number(80)]),
            "transactions": .array([]),
            "history": .string(String(repeating: "x", count: 5_100_000))
        ])
        XCTAssertEqual(try NativeValidation.financeResponse(response).record("summary").amount("budget"), 100)
        XCTAssertThrowsError(try NativeValidation.snapshot(JSONEncoder().encode(response)), "Local import size protection stays in place")
        XCTAssertThrowsError(try NativeValidation.financeResponse(.object(["transactions": .array([])])))
    }
    func testNetworkFinanceValidationStillRejectsInvalidAndDuplicateMovements() {
        let transaction: Record = ["row": .number(1), "name": .string("Esempio"), "date": .string("2026-02-10"), "amount": .number(-10)]
        var response: Record = ["summary": .object(["budget": .number(100), "committedCurrent": .number(20), "remainingFree": .number(80)]), "transactions": .array([.object(transaction), .object(transaction)])]
        XCTAssertThrowsError(try NativeValidation.financeResponse(.object(response)))
        var invalid = transaction; invalid["date"] = .string("2026-02-31")
        response["transactions"] = .array([.object(invalid)])
        XCTAssertThrowsError(try NativeValidation.financeResponse(.object(response)))
    }
    func testArchiveBeforeMonthPersistencePreservesQueueAndRejectsBrokenRequiredData() throws {
        let initial = NativeArchive(pending: [PendingWrite(id: "old-queue", method: "saveTransaction", payload: ["amount": .number(2)])], demo: false)
        var object = try JSONDecoder().decode(JSONValue.self, from: JSONEncoder().encode(initial)).object
        object.removeValue(forKey: "financeMonth"); object.removeValue(forKey: "calendarMonth")
        let restored = try JSONDecoder().decode(NativeArchive.self, from: JSONEncoder().encode(object))
        XCTAssertEqual(restored.financeMonth, CivilDate.month())
        XCTAssertEqual(restored.calendarMonth, CivilDate.month())
        XCTAssertEqual(restored.pending.first?.id, "old-queue")
        XCTAssertFalse(restored.demo)
        object["pending"] = .string("invalid")
        XCTAssertThrowsError(try JSONDecoder().decode(NativeArchive.self, from: JSONEncoder().encode(object)))
    }
    func testSnapshotRejectsMissingSummaryWrongTypeAndDuplicateRows() throws {
        let valid = #"{"summary":{"budget":1000,"committedCurrent":200,"remainingFree":800},"transactions":[{"row":2,"name":"Spesa","date":"2026-10-13","amount":-2}]}"#
        XCTAssertEqual(try NativeValidation.snapshot(Data(valid.utf8)).record("summary").amount("budget"), 1000)
        for bad in [#"{"transactions":[]}"#, valid.replacingOccurrences(of: "1000", with: "\"1000\""), valid.replacingOccurrences(of: "\"row\":2", with: "\"row\":1e300")] {
            XCTAssertThrowsError(try NativeValidation.snapshot(Data(bad.utf8)))
        }
        let duplicate = #"{"summary":{"budget":1,"committedCurrent":0,"remainingFree":1},"transactions":[{"row":2,"name":"A","date":"2026-10-13","amount":-1},{"row":2,"name":"B","date":"2026-10-13","amount":-2}]}"#
        XCTAssertThrowsError(try NativeValidation.snapshot(Data(duplicate.utf8)))
    }
    func testMonthlyRecurrenceClampsWithoutDriftingOriginalDay() {
        XCTAssertEqual(CivilDate.occurrenceDays(start: "2026-01-31", frequency: "monthly", until: "", low: "2026-01-01", high: "2026-04-01"), ["2026-01-31", "2026-02-28", "2026-03-31"])
        XCTAssertEqual(CivilDate.occurrenceDays(start: "2024-02-29", frequency: "yearly", until: "", low: "2024-01-01", high: "2026-01-01"), ["2024-02-29", "2025-02-28"])
    }
    func testCalendarUsesMondayAndSixWeeksWhenNecessary() {
        let grid = CivilDate.grid("2026-03")
        XCTAssertEqual(grid.count, 42)
        XCTAssertEqual(grid.first, "2026-02-23")
        XCTAssertEqual(grid.last, "2026-04-05")
    }
    func testRomeDayDoesNotFollowDeviceTimeZone() {
        let formatter = ISO8601DateFormatter()
        XCTAssertEqual(CivilDate.day(formatter.date(from: "2026-10-13T22:30:00Z")!), "2026-10-14")
    }
    func testDailyBudgetUsesMonthlyWorkerFieldsAndIncludesLastDay() {
        let summary: Record = ["monthlyRemaining": .number(-20), "monthlySalary": .number(1800), "monthlySpent": .number(200), "budget": .number(9999)]
        let range = NativeValidation.dailyBudget(summary, day: "2026-10-31")
        XCTAssertEqual(range.days, 1); XCTAssertEqual(range.low, -20); XCTAssertEqual(range.high, 1600)
    }
    func testAllocationConservesEveryCent() {
        let shares = NativeValidation.shares(cents: 10001, months: 12)
        XCTAssertEqual(shares.reduce(0, +), 10001)
        XCTAssertEqual((shares.max() ?? 0) - (shares.min() ?? 0), 1)
        XCTAssertTrue(NativeValidation.shares(cents: 10, months: 0).isEmpty)
    }
    func testDemoTaskStateAndStableCategoryRename() throws {
        var state = DemoData.make()
        try DemoActions.apply("renameCategory", ["key": .string("action"), "label": .string("Priorità")], args: nil, state: &state)
        XCTAssertTrue(state.life.records("categories").contains { $0.text("key") == "action" && $0.text("label") == "Priorità" })
        try DemoActions.apply("setTaskStatus", ["id": .int(1), "status": .string("waiting")], args: nil, state: &state)
        XCTAssertEqual(state.life.records("tasks").first { $0.integer("id") == 1 }?.text("status"), "waiting")
    }
    func testDemoExpenseEditDeleteRestoresBalanceExactly() throws {
        var state = DemoData.make()
        let initial = state.finance.record("summary").amount("budget")
        var payload: Record = ["name": .string("Prova"), "amount": .number(12.34), "account": .string("Trade Republic"), "type": .string("Spesa"), "category": .string("Altro"), "date": .string(CivilDate.day()), "budgetTreatment": .string("ordinary")]
        try DemoActions.apply("saveTransaction", payload, args: nil, state: &state)
        let row = state.finance.records("transactions").last!.integer("row")
        XCTAssertEqual(state.finance.record("summary").amount("budget"), initial - 12.34, accuracy: 0.0001)
        payload["row"] = .int(row); payload["amount"] = .number(20)
        try DemoActions.apply("editMovement", payload, args: nil, state: &state)
        XCTAssertEqual(state.finance.record("summary").amount("budget"), initial - 20, accuracy: 0.0001)
        try DemoActions.apply("deleteMovement", [:], args: [.int(row)], state: &state)
        XCTAssertEqual(state.finance.record("summary").amount("budget"), initial, accuracy: 0.0001)
    }
    func testPendingWriteIdentifierAndUnknownAPIFieldsSurvivePersistence() throws {
        let payload: Record = ["requestId": .string("12345678-1234"), "name": .string("Da conservare"), "futureWorkerField": .object(["keep": .bool(true)])]
        let state = NativeArchive(pending: [PendingWrite(id: "12345678-1234", method: "saveTransaction", payload: payload)])
        let restored = try JSONDecoder().decode(NativeArchive.self, from: JSONEncoder().encode(state))
        XCTAssertEqual(restored.pending.first?.id, state.pending.first?.id)
        XCTAssertEqual(restored.pending.first?.payload, payload)
    }
    func testLinkingExistingMovementNeverCreatesSecondCashMovement() throws {
        var state = DemoData.make()
        let count = state.finance.records("transactions").count, balance = state.finance.record("summary").amount("budget")
        let month = CivilDate.month()
        try DemoActions.apply("saveExtra", ["name": .string("Piano prova"), "amount": .number(100), "month": .string(month), "endMonth": .string(month), "status": .string("Programmato")], args: nil, state: &state)
        let cycle = state.plan.records("allocations").last!.integer("cycle_id")
        try DemoActions.apply("linkExtraMovement", ["cycleId": .int(cycle), "movementId": .int(2), "amount": .number(12.34)], args: nil, state: &state)
        XCTAssertEqual(state.finance.records("transactions").count, count)
        XCTAssertEqual(state.finance.record("summary").amount("budget"), balance)
        XCTAssertThrowsError(try DemoActions.apply("updateExtraPlan", ["cycleId": .int(cycle), "name": .string("Piano prova"), "amount": .number(1), "month": .string(month), "endMonth": .string(month)], args: nil, state: &state))
    }
    func testDemoTransferMovesTwoBalancesAndDeletionRestoresBoth() throws {
        var state = DemoData.make()
        let initial = state.finance.record("summary")
        let count = state.finance.records("transactions").count
        let payload: Record = ["name": .string("Chiusura conto"), "amount": .number(10), "account": .string("Revolut"), "counterpart": .string("Trade Republic"), "type": .string("Trasferimento"), "date": .string(CivilDate.day())]
        try DemoActions.apply("saveTransaction", payload, args: nil, state: &state)
        XCTAssertEqual(state.finance.records("transactions").count, count + 2)
        XCTAssertEqual(state.finance.record("summary").amount("budget"), initial.amount("budget") + 10)
        XCTAssertEqual(state.finance.record("summary").amount("revolutBalance"), initial.amount("revolutBalance") - 10)
        let row = state.finance.records("transactions").last!.integer("row")
        try DemoActions.apply("deleteMovement", [:], args: [.int(row)], state: &state)
        XCTAssertEqual(state.finance.record("summary").amount("budget"), initial.amount("budget"))
        XCTAssertEqual(state.finance.record("summary").amount("revolutBalance"), initial.amount("revolutBalance"))
    }
    func testRepeatedSaveWithSameRequestDoesNotDuplicateDemoExpense() throws {
        var state = DemoData.make()
        let count = state.finance.records("transactions").count, balance = state.finance.record("summary").amount("budget")
        let payload: Record = ["requestId": .string("double-tap-123456"), "name": .string("Prova"), "amount": .number(2), "type": .string("Spesa"), "account": .string("Trade Republic"), "date": .string(CivilDate.day())]
        try DemoActions.apply("saveTransaction", payload, args: nil, state: &state)
        try DemoActions.apply("saveTransaction", payload, args: nil, state: &state)
        XCTAssertEqual(state.finance.records("transactions").count, count + 1)
        XCTAssertEqual(state.finance.record("summary").amount("budget"), balance - 2)
    }
    func testDailyBudgetRespectsSelectedMonthAndLeapYear() {
        let summary: Record = ["monthlyRemaining": .number(310), "monthlySalary": .number(1000), "monthlySpent": .number(380)]
        let current = NativeValidation.dailyBudget(summary, day: "2026-10-14", month: "2026-10")
        XCTAssertEqual(current.days, 18)
        XCTAssertEqual(current.low, 310 / 18, accuracy: 0.0001)
        XCTAssertEqual(NativeValidation.dailyBudget(summary, day: "2026-10-14", month: "2026-06").days, 0)
        XCTAssertEqual(NativeValidation.dailyBudget(summary, day: "2026-10-14", month: "2026-11").days, 30)
        XCTAssertEqual(NativeValidation.dailyBudget(summary, day: "2024-01-31", month: "2024-02").days, 29)
    }
    func testSavingsRingDoesNotDoubleCountEmergencyAndUsesNextGoal() {
        let p = NativeSavingsProgress(summary: ["budget": .number(7000)], planning: ["goal": .number(6000)], day: "2026-10-14")
        XCTAssertEqual(p.target, 10000); XCTAssertEqual(p.reserved, 6000); XCTAssertEqual(p.other, 1000)
        XCTAssertEqual(p.reserved + p.other, p.assets)
        XCTAssertEqual(p.missing, 3000); XCTAssertEqual(p.monthly, 1000)
        XCTAssertEqual(NativeSavingsProgress(summary: ["budget": .number(-10)], planning: [:], day: "2026-12-31").months, 1)
    }
    func testPaidExtraUsesActualTotalAcrossEveryMonthWithoutLosingCents() throws {
        var state = DemoData.make()
        let template = state.plan.records("allocations")[0]
        state.plan["allocations"] = .array((0..<12).map { index in
            var row = template; row["month"] = .string(String(CivilDate.adding(index, to: template.text("start_month") + "-01", component: .month).prefix(7))); return .object(row)
        })
        let before = state.finance.record("summary")
        try DemoActions.apply("recordExtraPayment", ["cycleId": .int(1), "amount": .number(550.01), "date": .string(CivilDate.day()), "account": .string("Trade Republic"), "name": .string("Manutenzione effettiva")], args: nil, state: &state)
        let rows = state.plan.records("allocations")
        XCTAssertTrue(rows.allSatisfy { $0.text("status") == "Pagato" })
        XCTAssertEqual(rows.reduce(0) { $0 + NativeExtraState.displayedCents($1, plan: state.plan) }, 55001)
        XCTAssertEqual(state.finance.record("summary").amount("budget"), before.amount("budget") - 550.01, accuracy: 0.001)
        XCTAssertEqual(state.finance.record("summary").amount("monthlyRemaining"), before.amount("monthlyRemaining"))
        try DemoActions.apply("recordExtraPayment", ["cycleId": .int(1), "amount": .number(550.01)], args: nil, state: &state)
        XCTAssertEqual(state.finance.record("summary").amount("budget"), before.amount("budget") - 550.01, accuracy: 0.001)
    }
    func testWeatherFindsNextChangeAndHandlesTomorrow() {
        let data: Record = ["current": .object(["temperature_2m": .number(18), "weather_code": .int(0), "time": .string("2026-10-14T22:15")]), "daily": .object(["temperature_2m_min": .array([.number(12)]), "temperature_2m_max": .array([.number(22)])]), "hourly": .object(["time": .array([.string("2026-10-14T22:00"), .string("2026-10-14T23:00"), .string("2026-10-15T00:00")]), "weather_code": .array([.int(0), .int(0), .int(61)])])]
        XCTAssertEqual(NativeWeather.parse(data)?.change, "Pioggia domani alle 00:00")
        XCTAssertNil(NativeWeather.parse([:]))
    }
    func testExtraSettlementIncludesPaymentsAlreadyLinkedBeforeFinalPayment() {
        let row: Record = ["cycle_id": .int(4), "status": .string("Pagato"), "start_month": .string("2026-01"), "end_month": .string("2026-02"), "month": .string("2026-01"), "total_cents": .int(10000)]
        let plan: Record = ["settlements": .array([.object(["cycle_id": .int(4), "planned_cents": .int(7000), "actual_cents": .int(6501)])])]
        XCTAssertEqual(NativeExtraState.displayedCents(row, plan: plan), 4751)
        var second = row; second["month"] = .string("2026-02")
        XCTAssertEqual(NativeExtraState.displayedCents(row, plan: plan) + NativeExtraState.displayedCents(second, plan: plan), 9501)
    }
}
