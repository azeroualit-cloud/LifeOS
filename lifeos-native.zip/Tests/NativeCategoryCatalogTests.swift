import XCTest
@testable import LifeOSProbe

final class NativeCategoryCatalogTests: XCTestCase {
    func testUnknownNamesDoNotAcquireAMeaningFromSubstrings() {
        for name in ["Barbiere", "Gastronomia speciale", "Categoria personale", ""] {
            XCTAssertEqual(NativeCategoryCatalog.symbol(for: name), "tag", name)
        }
    }
    func testPresentationRecognizesAccentsCaseAndWordSeparators() {
        XCTAssertEqual(NativeCategoryCatalog.symbol(for: "  CAFFÈ  "), "cup.and.saucer")
        XCTAssertEqual(NativeCategoryCatalog.symbol(for: "Luce 09/26"), "bolt")
        XCTAssertEqual(NativeCategoryCatalog.symbol(for: "ACQUA–casa"), "drop")
    }
    func testSpecificExpenseMeaningPrecedesBroadWords() {
        XCTAssertEqual(NativeCategoryCatalog.symbol(for: "Spesa Extra"), "tag")
        XCTAssertEqual(NativeCategoryCatalog.symbol(for: "Imposta di Bollo"), "building.columns")
        XCTAssertEqual(NativeCategoryCatalog.symbol(for: "Bollo auto"), "car")
    }
    func testPickerKeepsCustomCategoriesWithoutDuplicatingKnownValues() {
        let original = "  Categoria mia  "
        let choices = NativeCategoryCatalog.choices(type: "Spesa", current: original)
        XCTAssertEqual(choices.last, original)
        XCTAssertEqual(choices.filter { $0 == original }.count, 1)
        XCTAssertEqual(NativeCategoryCatalog.choices(type: "Spesa", current: "Casa").filter { $0 == "Casa" }.count, 1)
        let income = NativeCategoryCatalog.choices(type: "Entrata", current: original)
        XCTAssertTrue(income.contains("Stipendio")); XCTAssertTrue(income.contains(original))
        XCTAssertFalse(income.contains("Alimentari"))
    }
}
