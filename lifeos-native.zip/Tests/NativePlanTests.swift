import XCTest
@testable import LifeOSProbe

final class NativePlanTests: XCTestCase {
    private let today = "2026-10-17"
    private func draft(_ kind: NativePlanKind, amount: String = "250") -> NativePlanDraft {
        var result = NativePlanDraft(); result.kind = kind; result.name = "Esempio"; result.amount = amount
        result.startMonth = "2026-11"; result.endMonth = "2026-12"; result.beneficiaryMonth = "2026-10"; result.paymentDate = today
        return result
    }
    func testAdvance250AddsToOctoberAndSubtractsExactlyFromSelectedFutureMonths() throws {
        var plan = draft(.advance)
        let preview = try plan.preview(today: today)
        XCTAssertEqual(preview.map { $0.text("month") }, ["2026-10", "2026-11", "2026-12"])
        XCTAssertEqual(preview.map { $0.integer("deltaCents") }, [25000, -12500, -12500])
        XCTAssertEqual(preview.reduce(0) { $0 + $1.integer("deltaCents") }, 0)
        plan.endMonth = "2026-11"
        XCTAssertEqual(try plan.preview(today: today).map { $0.integer("deltaCents") }, [25000, -25000])
    }
    func testPreviewCrossesYearBoundaryAndPreservesEveryCent() throws {
        var plan = draft(.goal, amount: "250,01"); plan.endMonth = "2027-01"
        let rows = try plan.preview(today: today)
        XCTAssertEqual(rows.map { $0.integer("deltaCents") }, [-8334, -8334, -8333])
        XCTAssertEqual(rows.map { $0.text("month") }, ["2026-11", "2026-12", "2027-01"])
    }
    func testContinuousFundHasNoEndMonthAndPreviewIsOnlyAnIllustration() throws {
        let plan = draft(.fund, amount: "50")
        let payload = try plan.payload(requestID: "fund-000001", today: today)
        XCTAssertNil(payload["endMonth"])
        XCTAssertEqual(try plan.preview(today: today).count, 3)
        XCTAssertEqual(NativePlanRules.contribution(payload, month: "2055-12"), 5000)
    }
    func testDraftRejectsClosedMonthsInvalidBeneficiaryAndReversedRange() {
        var plan = draft(.advance); plan.beneficiaryMonth = "2026-11"
        XCTAssertThrowsError(try plan.payload(requestID: "test-0000001", today: today))
        plan = draft(.goal); plan.startMonth = "2026-09"
        XCTAssertThrowsError(try plan.payload(requestID: "test-0000002", today: today))
        plan = draft(.goal); plan.endMonth = "2026-10"
        XCTAssertThrowsError(try plan.payload(requestID: "test-0000003", today: today))
    }
    func testRecoveryNeedsActualPaymentDateAndCannotBePaidAgain() {
        var plan = draft(.recovery); plan.paymentDate = "2026-10-18"
        XCTAssertThrowsError(try plan.payload(requestID: "test-0000004", today: today))
        plan.paymentDate = "2026-02-31"
        XCTAssertThrowsError(try plan.payload(requestID: "test-0000005", today: today))
        XCTAssertFalse(NativePlanKind.recovery.payable); XCTAssertFalse(NativePlanKind.advance.payable)
    }
    private func state() -> NativeArchive {
        var result = DemoData.make(); result.financeMonth = "2026-10"; return result
    }
    func testDemoGoalPaymentIsOnceOnlyAndOnlyOverageIsRecovered() throws {
        var state = state(), plan = draft(.goal, amount: "600"); plan.startMonth = "2026-10"
        let originalCash = state.finance.record("summary").amount("budget")
        try NativePlanDemo.apply("saveFinancePlan", payload: plan.payload(requestID: "goal-000001", today: today), state: &state, today: today)
        let payment: Record = ["requestId": .string("payment-0001"), "planId": .string("goal-000001"), "amountCents": .int(70000), "date": .string(today), "recoverDifference": .bool(true), "recoveryStartMonth": .string("2026-11"), "recoveryEndMonth": .string("2026-12")]
        try NativePlanDemo.apply("recordFinancePlanPayment", payload: payment, state: &state, today: today)
        try NativePlanDemo.apply("recordFinancePlanPayment", payload: payment, state: &state, today: today)
        XCTAssertEqual(state.finance.record("summary").amount("budget"), originalCash - 700, accuracy: 0.001)
        let plans = state.finance.record("plansV2").records("plans")
        XCTAssertEqual(plans.first { $0.text("id") == "goal-000001" }?.text("status"), "closed")
        let recovery = try XCTUnwrap(plans.first { $0.text("kind") == "recovery" })
        XCTAssertEqual(NativePlanRules.contribution(recovery, month: "2026-11"), 5000)
        XCTAssertEqual(state.finance.record("plansV2").records("payments").count, 1)
    }
    func testDemoFundPaymentKeepsPlanActiveAndStopDoesNotCreateCashExpense() throws {
        var state = state(), plan = draft(.fund, amount: "50"); plan.startMonth = "2026-10"
        try NativePlanDemo.apply("saveFinancePlan", payload: plan.payload(requestID: "fund-000002", today: today), state: &state, today: today)
        try NativePlanDemo.apply("recordFinancePlanPayment", payload: ["requestId": .string("payment-0002"), "planId": .string("fund-000002"), "amountCents": .int(3000), "date": .string(today)], state: &state, today: today)
        XCTAssertEqual(state.finance.record("plansV2").records("plans").first?.integer("fundCents"), 2000)
        XCTAssertEqual(state.finance.record("plansV2").records("plans").first?.text("status"), "active")
        let cash = state.finance.record("summary").amount("budget")
        try NativePlanDemo.apply("stopFinancePlan", payload: ["requestId": .string("stop-0000001"), "planId": .string("fund-000002")], state: &state, today: today)
        XCTAssertEqual(state.finance.record("summary").amount("budget"), cash)
        XCTAssertEqual(state.finance.record("plansV2").records("plans").first?.integer("fundCents"), 0)
        XCTAssertEqual(NativePlanRules.contribution(state.finance.record("plansV2").records("plans")[0], month: "2026-11"), 0)
    }
    func testEstimatedRateChangesOnlyApplyToFutureMonths() {
        let plan: Record = ["kind": .string("estimated"), "amountCents": .int(8000), "startMonth": .string("2026-10"), "status": .string("active"), "rateChanges": .array([.object(["fromMonth": .string("2026-11"), "amountCents": .int(10000)])])]
        XCTAssertEqual(NativePlanRules.contribution(plan, month: "2026-10"), 8000)
        XCTAssertEqual(NativePlanRules.contribution(plan, month: "2026-11"), 10000)
    }
    func testProjectionIsIdempotentAndSwitchingMonthsDoesNotAccumulateAdjustments() throws {
        var state = state()
        let payload = try draft(.advance).payload(requestID: "advance-0001", today: today)
        let initial = state.finance.record("summary").amount("monthlyRemaining")
        try NativePlanDemo.apply("saveFinancePlan", payload: payload, state: &state, today: today)
        XCTAssertEqual(state.finance.record("summary").amount("monthlyRemaining"), initial + 250, accuracy: 0.001)
        NativePlanDemo.project(month: "2026-11", state: &state, today: today)
        XCTAssertEqual(state.finance.record("summary").amount("monthlyRemaining"), initial - 125, accuracy: 0.001)
        NativePlanDemo.project(month: "2026-10", state: &state, today: today)
        NativePlanDemo.project(month: "2026-10", state: &state, today: today)
        XCTAssertEqual(state.finance.record("summary").amount("monthlyRemaining"), initial + 250, accuracy: 0.001)
    }
}
