import XCTest
@testable import LifeOSProbe

final class NativeBudgetFlowTests: XCTestCase {
    func testSalaryWaterfallCreditsAdvancesAndKeepsStoppedHistoryWithoutDuplicates() {
        let month = "2026-10"
        func plan(_ id: String, _ amount: Int, _ start: String = "2026-10", _ status: String = "active") -> Record {
            ["id": .string(id), "name": .string(id), "contributionCents": .int(amount), "startMonth": .string(start), "status": .string(status)]
        }
        let plans = [plan("rent", 55000), plan("advance", -10001, "2026-11"), plan("stopped", 2000, "2026-01", "stopped"), plan("zero", 0), plan("future", 0, "2026-11")]
        let summary: Record = ["monthlySalary": .number(1800), "monthlySpent": .number(123.45), "monthlyRemaining": .number(1206.56), "monthlyBudgetBreakdown": .array([.object(["name": .string("rent"), "amount": .number(550), "planId": .string("rent")])])]
        let flow = NativeBudgetFlow(summary: summary, plans: plans, month: month)
        XCTAssertEqual(flow.rows.map(\.remainingCents), [125000, 135001, 133001, 133001])
        XCTAssertEqual(flow.planIDs, Set(["rent", "advance", "stopped", "zero"]))
        XCTAssertEqual(flow.rows.last!.remainingCents - flow.spentCents, flow.remainingCents)
        XCTAssertEqual(flow.remainingCents, 120656)
    }
    func testLegacyCommitmentsAndRefundsReconcileWithNegativeBudget() {
        let summary: Record = ["monthlySalary": .number(100), "monthlySpent": .number(-10.01), "monthlyRemaining": .number(-9.99), "monthlyBudgetBreakdown": .array([.object(["name": .string("Impegno precedente"), "amount": .number(120)])])]
        let flow = NativeBudgetFlow(summary: summary, plans: [], month: "2026-10")
        XCTAssertEqual(flow.rows.count, 1)
        XCTAssertEqual(flow.rows.last!.remainingCents - flow.spentCents, -999)
    }
}
