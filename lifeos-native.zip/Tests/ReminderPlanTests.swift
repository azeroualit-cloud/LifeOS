import XCTest
@testable import LifeOSProbe

final class ReminderPlanTests: XCTestCase {
    private let day = "2026-10-26"
    func testPlanUsesRomeAndExcludesDoneTasksAndRestDays() throws {
        let life: Record = [
            "tasks": .array([.object(["id": .int(1), "title": .string("Scadenza demo"), "status": .string("todo"), "due_date": .string(day)]), .object(["id": .int(2), "status": .string("done"), "due_date": .string(day)])]),
            "shifts": .array([.object(["day": .string(day), "kind": .string("morning")]), .object(["day": .string("2026-10-27"), "kind": .string("rest")])]),
            "upcomingEvents": .array([.object(["id": .int(3), "title": .string("Evento demo"), "day": .string(day), "start_time": .string("14:30")])])]
        let plan = ReminderPlan.make(life: life, now: CivilDate.date("2026-10-25"))
        XCTAssertEqual(plan.map(\.id), ["shift-2026-10-26", "task-1", "event-3-2026-10-26"])
        XCTAssertEqual(plan.map { CivilDate.calendar.component(.hour, from: $0.date) }, [5, 9, 14])
        XCTAssertEqual(CivilDate.calendar.component(.minute, from: plan[2].date), 15)
        XCTAssertTrue(ReminderPlan.make(life: life, now: CivilDate.date("2026-10-28")).isEmpty)
    }
    func testPlanLimitsTo48AndDeduplicates() {
        let tasks = (1...70).map { id in JSONValue.object(["id": .int(id), "status": .string("todo"), "due_date": .string(day)]) }
        let plan = ReminderPlan.make(life: ["tasks": .array(tasks + tasks)], now: CivilDate.date("2026-10-25"))
        XCTAssertEqual(plan.count, 48)
        XCTAssertEqual(Set(plan.map(\.id)).count, 48)
    }
}
