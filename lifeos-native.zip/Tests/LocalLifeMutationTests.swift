import XCTest
@testable import LifeOSProbe

final class LocalLifeMutationTests: XCTestCase {
    func testOnlyStableAbsoluteSettersCanBeQueued() {
        for method in ["saveTask", "saveEvent", "saveRoutine", "deleteMovement", "recordExtraPayment"] { XCTAssertFalse(LocalLifeMutation.supports(method)) }
    }
    func testShiftReplayAndEraseAreIdempotent() throws {
        var life: Record = [:]
        let payload: Record = ["day": .string(CivilDate.day()), "kind": .string("night")]
        try LocalLifeMutation.apply("paintShift", payload, to: &life)
        let once = life
        try LocalLifeMutation.apply("paintShift", payload, to: &life)
        XCTAssertEqual(life, once)
        XCTAssertEqual(life.records("shifts").count, 1)
        try LocalLifeMutation.apply("paintShift", ["day": payload["day"]!, "kind": .string("erase")], to: &life)
        XCTAssertTrue(life.records("shifts").isEmpty)
    }
    func testHealthUpsertPreservesOmittedFieldsAndUsesReadSchema() throws {
        var life: Record = ["health": .array([.object(["day": .string(CivilDate.day()), "calories": .int(2100)])])]
        let payload = try HealthMeasurement.payload(day: CivilDate.day(), weight: "78,4", calories: "")
        try LocalLifeMutation.apply("saveHealthEntry", payload, to: &life)
        try LocalLifeMutation.apply("saveHealthEntry", payload, to: &life)
        XCTAssertEqual(life.records("health").count, 1)
        XCTAssertEqual(life.records("health")[0].amount("weight_kg"), 78.4)
        XCTAssertEqual(life.records("health")[0].integer("calories"), 2100)
        XCTAssertThrowsError(try LocalLifeMutation.apply("saveHealthEntry", ["day": .string(CivilDate.day()), "calories": .number(1.5)], to: &life))
    }
    func testPastRoutineCheckNeverChangesToday() throws {
        var life: Record = ["routines": .array([.object(["id": .int(1), "checked": .bool(false)])])]
        try LocalLifeMutation.apply("setRoutineCheck", ["id": .int(1), "day": .string(CivilDate.adding(-1, to: CivilDate.day())), "checked": .bool(true)], to: &life)
        XCTAssertFalse(life.records("routines")[0].flag("checked"))
        try LocalLifeMutation.apply("setRoutineCheck", ["id": .int(1), "day": .string(CivilDate.day()), "checked": .bool(true)], to: &life)
        XCTAssertTrue(life.records("routines")[0].flag("checked"))
    }
    func testCompletedEventUpdatesOnlyItsOccurrenceAndStopsReminder() throws {
        let day = CivilDate.adding(1, to: CivilDate.day())
        var life: Record = ["upcomingEvents": .array([.object(["id": .int(1), "title": .string("Evento demo"), "day": .string(day), "start_time": .string("14:00")])])]
        XCTAssertEqual(ReminderPlan.make(life: life).count, 1)
        try LocalLifeMutation.apply("setEventOccurrence", ["id": .int(1), "day": .string(day), "status": .string("done")], to: &life)
        XCTAssertTrue(ReminderPlan.make(life: life).isEmpty)
        XCTAssertEqual(life.record("occurrences").text("1:" + day), "done")
        try LocalLifeMutation.apply("setEventOccurrence", ["id": .int(1), "day": .string(day), "status": .string("open")], to: &life)
        XCTAssertEqual(ReminderPlan.make(life: life).count, 1)
    }
    func testRoutesCannotInjectDataOrExternalDestinations() {
        for route in ["task", "activities", "weight", "calendar", "dashboard"] { XCTAssertNotNil(LifeOSRoute(URL(string: "lifeos://" + route)!)) }
        for url in ["https://calendar", "lifeos://weight?weight=10", "lifeos://task/extra", "lifeos://user@calendar", "lifeos://delete"] { XCTAssertNil(LifeOSRoute(URL(string: url)!)) }
    }
}
