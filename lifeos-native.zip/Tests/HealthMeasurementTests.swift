import XCTest
@testable import LifeOSProbe

final class HealthMeasurementTests: XCTestCase {
    func testManualPayloadAcceptsItalianDecimalsAndZeroCalories() throws {
        let value = try HealthMeasurement.payload(day: "2026-10-23", weight: "78,4", calories: "0", today: "2026-10-23")
        XCTAssertEqual(value.amount("weightKg"), 78.4)
        XCTAssertEqual(value["calories"], .number(0))
    }
    func testMissingMeasurementsStayMissing() throws {
        let value = try HealthMeasurement.payload(day: "2026-10-23", weight: "78", calories: "", today: "2026-10-23")
        XCTAssertNil(value["calories"])
        let sample = HealthMeasurement(["day": .string("2026-10-23"), "weight_kg": .number(78), "calories": .null])
        XCTAssertNil(sample?.calories)
        XCTAssertEqual(sample?.weight, 78)
    }
    func testInvalidAndFutureMeasurementsAreRejected() {
        for (weight, calories) in [("", ""), ("nan", ""), ("19", ""), ("78", "1.5"), ("78", "15001")] {
            XCTAssertThrowsError(try HealthMeasurement.payload(day: "2026-10-23", weight: weight, calories: calories, today: "2026-10-23"))
        }
        XCTAssertThrowsError(try HealthMeasurement.payload(day: "2026-02-30", weight: "78", calories: "", today: "2026-10-23"))
        XCTAssertThrowsError(try HealthMeasurement.payload(day: "2026-10-24", weight: "78", calories: "", today: "2026-10-23"))
    }
    func testDemoUpdatesOneDayAndPreservesOtherData() throws {
        var state = NativeArchive(); state.demo = true
        state.life = ["shifts": .array([.object(["day": .string(CivilDate.day()), "kind": .string("morning")])])]
        let day = CivilDate.day()
        try DemoActions.apply("saveHealthEntry", ["day": .string(day), "weightKg": .number(78.4), "calories": .number(2100)], args: nil, state: &state)
        try DemoActions.apply("saveHealthEntry", ["day": .string(day), "weightKg": .number(78.1)], args: nil, state: &state)
        XCTAssertEqual(state.life.records("health").count, 1)
        XCTAssertEqual(state.life.records("health")[0].amount("weight_kg"), 78.1)
        XCTAssertEqual(state.life.records("health")[0].amount("calories"), 2100)
        XCTAssertEqual(state.life.records("shifts").count, 1)
    }
    func testDashboardSummaryDoesNotReadLegacyAppointments() {
        let summary = NativeHomeSummary(now: CivilDate.date("2026-10-23"), todayShift: .morning, tomorrowShift: .rest, events: [["id": .int(1), "day": .string("2026-10-23"), "title": .string("Evento precedente")]], weather: nil, weatherDate: nil, includeEvents: false)
        XCTAssertFalse(summary.text.contains("Evento precedente"))
        XCTAssertFalse(summary.text.contains("appuntamento"))
        XCTAssertTrue(summary.text.contains("mattina"))
    }
}
