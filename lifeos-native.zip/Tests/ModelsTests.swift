import XCTest
@testable import LifeOSProbe

final class ModelsTests: XCTestCase {
    func testEuroGroupingIncludesFourDigitsAndNegativeAmounts() {
        XCTAssertTrue(1000.0.euro.contains("1.000,00"))
        XCTAssertTrue((-1234.56).euro.contains("-1.234,56"))
        XCTAssertTrue(12345.67.euro.contains("12.345,67"))
    }
    func testItalianAmountsAndInvalidInput() {
        XCTAssertEqual(Input.cents("12,34"), 1234)
        XCTAssertEqual(Input.cents("0.01"), 1)
        for raw in ["0", "-1", "1.234", "1,2,3", "NaN", "1000000.01"] { XCTAssertNil(Input.cents(raw)) }
    }
    func testRetryKeepsIdentifierAcrossPersistence() throws {
        let expense = try Input.expense(amount: "12,34", name: "Spesa", category: "Alimentari", date: Date(), months: 1, treatment: "auto")
        let archive = Archive(queue: [expense])
        let restored = try JSONDecoder().decode(Archive.self, from: JSONEncoder().encode(archive))
        XCTAssertEqual(restored.queue.first?.requestId, expense.requestId)
        XCTAssertEqual(restored.queue.first?.account, "Trade Republic")
        XCTAssertEqual(restored.queue.first?.amount, 12.34)
    }
    func testRejectsFutureAndBlankDescription() {
        XCTAssertThrowsError(try Input.expense(amount: "1", name: " ", category: "Altro", date: Date(), months: 1, treatment: "auto"))
        XCTAssertThrowsError(try Input.expense(amount: "1", name: "x", category: "Altro", date: Date().addingTimeInterval(172800), months: 1, treatment: "auto"))
    }
    func testBackendSnapshotContract() throws {
        let data = Data(#"{"summary":{"budget":1000,"committedCurrent":200,"remainingFree":800,"account":"Trade Republic"},"transactions":[{"row":3,"date":"2026-10-12","name":"Test","amount":-10,"account":"Trade Republic","category":"Altro"}]}"#.utf8)
        let f = try JSONDecoder().decode(Finance.self, from: data)
        XCTAssertEqual(f.summary.remainingFree, 800)
        XCTAssertEqual(f.transactions.first?.id, 3)
    }
}
