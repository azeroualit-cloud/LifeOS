import XCTest
@testable import LifeOSProbe

final class NativeHomeTests: XCTestCase {
    private let now = CivilDate.calendar.date(bySettingHour: 12, minute: 30, second: 0, of: CivilDate.date("2026-10-16"))!
    private func event(_ id: Int, _ day: String, _ time: String = "", status: String = "open", title: String = "Dentista") -> Record {
        ["id": .int(id), "day": .string(day), "start_time": .string(time), "occurrence_status": .string(status), "title": .string(title)]
    }
    private func summary(_ rows: [Record] = [], current: ShiftKind? = .night, next: ShiftKind? = .night) -> NativeHomeSummary {
        NativeHomeSummary(now: now, todayShift: current, tomorrowShift: next, events: rows, weather: nil, weatherDate: nil)
    }
    func testRollingDaysCenterTodayAcrossYearAndLeapMonth() {
        XCTAssertEqual(NativeHomeSummary.rollingDays("2027-01-01"), ["2026-12-29", "2026-12-30", "2026-12-31", "2027-01-01", "2027-01-02", "2027-01-03", "2027-01-04"])
        XCTAssertEqual(NativeHomeSummary.rollingDays("2028-03-01")[2], "2028-02-29")
    }
    func testEmptyCalendarAndUnknownShiftsAreExplicit() {
        let s = summary(current: nil, next: nil)
        XCTAssertTrue(s.events.isEmpty)
        XCTAssertTrue(s.text.contains("Turni non disponibili"))
        XCTAssertTrue(s.text.contains("Nessun appuntamento"))
        XCTAssertFalse(s.text.contains("riposo"))
    }
    func testMissingCalendarDoesNotClaimThereAreNoEvents() {
        let s = NativeHomeSummary(now: now, todayShift: nil, tomorrowShift: nil, events: [], weather: nil, weatherDate: nil, calendarAvailable: false)
        XCTAssertTrue(s.text.contains("Calendario da aggiornare")); XCTAssertFalse(s.text.contains("Nessun appuntamento"))
    }
    func testRepeatedShiftIsOneNaturalSentence() {
        let s = summary()
        XCTAssertTrue(s.text.contains("Oggi e domani lavori di notte, dalle 22 alle 6."))
        XCTAssertEqual(s.phrases.filter { $0.text.contains("lavori") }.count, 1)
    }
    func testDifferentShiftsAndMissingTomorrowDoNotInventWork() {
        let s = summary(current: .rest, next: .morning)
        XCTAssertTrue(s.text.contains("Oggi sei di riposo.")); XCTAssertTrue(s.text.contains("Domani lavori dalle 6 alle 14."))
        XCTAssertFalse(summary(current: .holiday, next: nil).text.contains("Domani"))
        XCTAssertTrue(summary(current: .erase, next: .rest).text.contains("Domani sei di riposo"))
    }
    func testOnlyRelevantOccurrencesAreKeptAndSortedWithoutDuplicates() {
        let first = event(4, "2026-10-17", "15:00")
        let s = summary([event(1, "2026-10-16", "09:00"), event(2, "2026-10-17", status: "done"), event(3, "2026-10-17", status: "skipped"), first, first, event(5, "2026-10-23"), event(6, "2026-10-16", "18:00")])
        XCTAssertEqual(s.events.map { $0.integer("id") }, [6, 4])
    }
    func testAllDayEventNeverShowsAnInventedTime() {
        let s = summary([event(1, "2026-10-16")])
        XCTAssertTrue(s.text.contains("Oggi: Dentista.")); XCTAssertFalse(s.text.contains("Dentista alle"))
    }
    func testManyEventsRemainAccessibleButSummaryMentionsOnlyFirst() {
        let rows = (1...20).map { event($0, "2026-10-17", title: "Evento \($0)") }
        let s = summary(rows)
        XCTAssertEqual(s.events.count, 20)
        XCTAssertTrue(s.text.contains("Evento 1.")); XCTAssertFalse(s.text.contains("Evento 2."))
    }
    func testLongMultilineEventTitleIsBoundedAndFullRecordIsPreserved() {
        let title = String(repeating: "Appuntamento\n", count: 100)
        let s = summary([event(1, "2026-10-17", title: title)])
        XCTAssertLessThan(s.text.count, 230); XCTAssertFalse(s.text.contains("\n")); XCTAssertEqual(s.events.first?.text("title"), title)
    }
    func testWeatherIsNaturalOnlyWhenFreshAndFinite() {
        let weather = NativeWeather(temperature: 18, low: 12, high: 22, code: 0, change: "")
        let s = NativeHomeSummary(now: now, todayShift: nil, tomorrowShift: nil, events: [], weather: weather, weatherDate: now)
        XCTAssertTrue(s.text.contains("A Empoli, 18° e sereno."))
        let stale = NativeHomeSummary(now: now, todayShift: nil, tomorrowShift: nil, events: [], weather: weather, weatherDate: now.addingTimeInterval(-7200))
        XCTAssertFalse(stale.text.contains("18°"))
        let invalid = NativeHomeSummary(now: now, todayShift: nil, tomorrowShift: nil, events: [], weather: NativeWeather(temperature: 1e100, low: 0, high: 0, code: 0, change: ""), weatherDate: now)
        XCTAssertFalse(invalid.text.contains("Empoli"))
    }
    func testOvernightCarryAndGreetingFollowRomeTime() {
        let night = CivilDate.calendar.date(bySettingHour: 3, minute: 0, second: 0, of: now)!
        let s = NativeHomeSummary(now: night, todayShift: .rest, tomorrowShift: nil, previousShift: .night, events: [], weather: nil, weatherDate: nil)
        XCTAssertTrue(s.text.contains("Termini la notte alle 6.")); XCTAssertTrue(s.greeting.hasPrefix("Buongiorno"))
    }
    func testTodosDoNotDependOnEventCountAndExcludeOtherListsAndStates() {
        let rows: [Record] = (1...8).map { ["id": .int($0), "list_kind": .string($0 == 8 ? "wish" : "action"), "status": .string($0 == 7 ? "waiting" : $0 == 6 ? "done" : "todo"), "sort_order": .int($0), "due_date": .string($0 == 5 ? "2026-10-16" : "")] }
        XCTAssertEqual(NativeHomeSummary.todos(rows).map { $0.integer("id") }, [5, 1, 2, 3, 4])
        XCTAssertTrue(NativeHomeSummary.todos([]).isEmpty)
    }
}
