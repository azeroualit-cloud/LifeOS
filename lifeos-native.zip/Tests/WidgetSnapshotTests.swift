import XCTest
@testable import LifeOSProbe

final class WidgetSnapshotTests: XCTestCase {
    private let now = CivilDate.date("2026-10-30").addingTimeInterval(12 * 3600)
    private func archive() -> NativeArchive {
        var a = NativeArchive()
        a.demo = false; a.lifeRefreshedAt = now
        a.life = ["today": .string("2026-10-30"), "tasks": .array([]), "routines": .array([]), "shifts": .array([])]
        return a
    }
    func testSevenDaysCrossMonthAndDSTInRome() {
        let s = WidgetSnapshot(archive: archive())
        XCTAssertEqual(s.days(at: now), ["2026-10-30", "2026-10-31", "2026-11-01", "2026-11-02", "2026-11-03", "2026-11-04", "2026-11-05"])
        let dst = CivilDate.date("2026-10-24")
        XCTAssertEqual(s.days(at: dst).count, Set(s.days(at: dst)).count)
        XCTAssertEqual(s.days(at: dst)[2], "2026-10-26")
    }
    func testTomorrowDoesNotReuseRealRoutineChecks() {
        var a = archive()
        a.life["routines"] = .array([.object(["checked": .bool(true)])])
        let s = WidgetSnapshot(archive: a)
        XCTAssertEqual(s.routineChecks(at: now), [true])
        XCTAssertNil(s.routineChecks(at: CivilDate.date("2026-10-31")))
        XCTAssertTrue(s.isStale(at: CivilDate.date("2026-10-31")))
    }
    func testTodayAndOverdueAreDisjointAndExcludeFutureUndatedAndDone() {
        var a = archive()
        func task(_ due: String, _ scheduled: String = "", _ status: String = "todo", _ kind: String = "action") -> JSONValue {
            .object(["due_date": .string(due), "scheduled_date": .string(scheduled), "status": .string(status), "list_kind": .string(kind)])
        }
        a.life["tasks"] = .array([task("2026-10-29", "2026-10-30"), task("2026-10-30"), task("", "2026-10-30"), task("2026-11-01"), task(""), task("2026-10-30", "", "done"), task("2026-10-30", "", "todo", "ideas")])
        let counts = WidgetSnapshot(archive: a).counts(at: now)
        XCTAssertEqual(counts.today, 2); XCTAssertEqual(counts.overdue, 1)
    }
    func testMissingShiftsNeverBecomeRestAndEraseIsNotARealShift() {
        var a = archive()
        a.life["shifts"] = .array([.object(["day": .string("2026-10-30"), "kind": .string("night")]), .object(["day": .string("2026-10-31"), "kind": .string("erase")])])
        let s = WidgetSnapshot(archive: a)
        XCTAssertEqual(s.shifts["2026-10-30"], "night")
        XCTAssertNil(s.shifts["2026-10-31"])
        XCTAssertNil(s.shifts["2026-11-01"])
    }
    func testProjectionExcludesPrivateDataAndRoundTrips() throws {
        var a = archive()
        a.endpoint = "https://private.invalid"
        a.life["routines"] = .array([.object(["title": .string("PRIVATE_TITLE"), "checked": .int(1)])])
        a.finance = ["private": .string("PRIVATE_FINANCE")]
        let s = WidgetSnapshot(archive: a), data = try JSONEncoder().encode(s)
        let text = String(decoding: data, as: UTF8.self)
        for forbidden in ["private.invalid", "PRIVATE_TITLE", "PRIVATE_FINANCE"] { XCTAssertFalse(text.contains(forbidden)) }
        XCTAssertEqual(try JSONDecoder().decode(WidgetSnapshot.self, from: data), s)
    }
    func testFinanceRefreshDoesNotMakeOldLifeDataFresh() {
        var a = archive()
        a.lifeRefreshedAt = now.addingTimeInterval(-7 * 3600); a.financeRefreshedAt = now; a.refreshedAt = now
        XCTAssertTrue(WidgetSnapshot(archive: a).isStale(at: now))
    }
    func testUnavailableIsDifferentFromEmpty() {
        XCTAssertFalse(WidgetSnapshot.empty.available)
        XCTAssertNil(WidgetSnapshot.empty.routineChecks(at: now))
        let empty = WidgetSnapshot(archive: archive())
        XCTAssertTrue(empty.available); XCTAssertEqual(empty.routineChecks(at: now), [])
    }
}
