import Foundation
import XCTest
@testable import LifeOSProbe

private final class QueueMockAPI: URLProtocol {
    static let lock = NSLock()
    static var writes = 0
    static var failAfterWrite = false
    static var failAll = false
    static var calls: [String] = []
    static var timeoutOnce: String?
    static var rejectMethod: String?
    static var pauseMethod: String?
    static var paused: QueueMockAPI?
    private var deferredResponse: (HTTPURLResponse, String)?
    override class func canInit(with request: URLRequest) -> Bool { request.url?.host == "lifeos-test.invalid" }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        Self.lock.lock()
        let method = request.url!.lastPathComponent
        Self.calls.append(method)
        if Self.timeoutOnce == method {
            Self.timeoutOnce = nil; Self.lock.unlock()
            client?.urlProtocol(self, didFailWithError: URLError(.timedOut)); return
        }
        var status = 200
        var text = "{}"
        if Self.failAll { status = 401; text = "Sessione scaduta" }
        else if Self.rejectMethod == method { status = 400; text = "Modifica rifiutata" }
        else if ["setTaskStatus", "setRoutineCheck", "paintShift", "saveHealthEntry", "setEventOccurrence"].contains(method) { text = "true" }
        else if method == "saveTransaction" { Self.writes += 1; text = "true" }
        else if ["getShiftCalendar", "publishShiftCalendar", "rotateShiftCalendarLink"].contains(method) { text = #"{"path":"/calendar/turni/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.ics","publishedAt":"2026-10-23T12:00:00Z"}"# }
        else if method == "getLifeData" { text = #"{"tasks":[],"categories":[],"routines":[],"events":[],"shifts":[],"upcomingEvents":[]}"# }
        else if method == "getExtraPlan" { text = #"{"allocations":[],"links":[]}"# }
        else if method == "getFinanceData" || method == "getFinanceOverview" {
            if Self.failAfterWrite && Self.writes > 0 { Self.failAfterWrite = false; status = 500; text = "Aggiornamento temporaneamente non disponibile" }
            else { text = #"{"summary":{"budget":1000,"committedCurrent":200,"remainingFree":800},"transactions":[],"extraPlan":{"allocations":[],"links":[]}}"# }
        }
        Self.lock.unlock()
        let response = HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: nil, headerFields: ["Content-Type": status == 200 ? "application/json" : "text/plain", "Set-Cookie": method == "login" && status == 200 ? "liquidita_session=mock-session; Path=/; Max-Age=3600; Secure; HttpOnly; SameSite=Strict" : "", "X-LifeOS-Data-Source": "shared"])!
        Self.lock.lock()
        if Self.pauseMethod == method {
            deferredResponse = (response, text); Self.paused = self; Self.lock.unlock(); return
        }
        Self.lock.unlock()
        deliver(response, text)
    }
    static func resume() {
        lock.lock(); let request = paused; paused = nil; pauseMethod = nil; lock.unlock()
        if let request, let (response, text) = request.deferredResponse { request.deliver(response, text) }
    }
    private func deliver(_ response: HTTPURLResponse, _ text: String) {
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(text.utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

@MainActor final class NativeQueueTests: XCTestCase {
    func testShiftPublicationDoesNotRefreshFinanceOrRetryWrites() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        let result = try await store.updateShiftCalendar("publishShiftCalendar", month: "2026-10")
        XCTAssertFalse(result.text("path").isEmpty)
        XCTAssertEqual(QueueMockAPI.calls, ["publishShiftCalendar"])
        XCTAssertFalse(store.busy)
        QueueMockAPI.timeoutOnce = "publishShiftCalendar"
        do {
            _ = try await store.updateShiftCalendar("publishShiftCalendar", month: "2026-10")
            XCTFail("Un timeout deve restare visibile")
        } catch { XCTAssertEqual((error as? URLError)?.code, .timedOut) }
        XCTAssertEqual(QueueMockAPI.calls.filter { $0 == "publishShiftCalendar" }.count, 2)
        XCTAssertFalse(store.busy)
        _ = try await store.updateShiftCalendar("publishShiftCalendar", month: "2026-10")
        XCTAssertEqual(QueueMockAPI.calls.count, 3)
    }
    func testCalendarStatusReadDoesNotBlockLocalPaintingAndUnsentShiftsCannotPublish() async throws {
        let (directory, session) = try setup(); defer { QueueMockAPI.resume(); try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        QueueMockAPI.pauseMethod = "getShiftCalendar"
        let status = Task { try await store.updateShiftCalendar("getShiftCalendar", month: CivilDate.month()) }
        for _ in 0..<100 { if QueueMockAPI.paused != nil { break }; try await Task.sleep(nanoseconds: 10_000_000) }
        XCTAssertNotNil(QueueMockAPI.paused)
        XCTAssertFalse(store.busy)
        try await store.perform("paintShift", ["day": .string(CivilDate.day()), "kind": .string("night")])
        XCTAssertEqual(store.shift(CivilDate.day()), .night)
        QueueMockAPI.resume()
        _ = try await status.value
        do { _ = try await store.updateShiftCalendar("publishShiftCalendar", month: CivilDate.month()); XCTFail("Non pubblicare una bozza remota obsoleta") } catch {}
        XCTAssertFalse(QueueMockAPI.calls.contains("publishShiftCalendar"))
    }
    func testConnectedArchiveRollsHabitsToTodayOfflineWithoutMovingYesterdayCheck() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let yesterday = CivilDate.adding(-1, to: CivilDate.day())
        var archive = NativeArchive()
        archive.demo = false; archive.endpoint = "https://lifeos-test.invalid"
        archive.life = ["today": .string(yesterday), "routines": .array([.object(["id": .int(1), "checked": .bool(true)])])]
        archive.pending = [PendingWrite(id: "old-check", method: "setRoutineCheck", payload: ["id": .int(1), "day": .string(yesterday), "checked": .bool(true)])]
        try JSONEncoder().encode(archive).write(to: directory.appendingPathComponent("lifeos-native-v2.json"))
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        XCTAssertFalse(store.routines[0].flag("checked"))
        XCTAssertEqual(store.life.text("today"), CivilDate.day())
        XCTAssertEqual(store.state.pending[0].payload.text("day"), yesterday)
        try await store.perform("setRoutineCheck", ["id": .int(1), "day": .string(CivilDate.day()), "checked": .bool(true)])
        let restored = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        XCTAssertTrue(restored.routines[0].flag("checked"))
        XCTAssertTrue(QueueMockAPI.calls.isEmpty)
    }
    func testRejectedSetterPreservesOrderForSameKeyButDoesNotBlockFinance() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        for kind in ["morning", "night"] { try await store.perform("paintShift", ["day": .string(CivilDate.day()), "kind": .string(kind)]) }
        try await store.perform("saveTransaction", payload)
        QueueMockAPI.rejectMethod = "paintShift"
        await store.sync()
        XCTAssertEqual(QueueMockAPI.calls.filter { $0 == "paintShift" }.count, 1)
        XCTAssertEqual(QueueMockAPI.writes, 1)
        XCTAssertEqual(store.state.pending.map(\.method), ["paintShift", "paintShift"])
        XCTAssertEqual(store.shift(CivilDate.day()), .night)
        QueueMockAPI.rejectMethod = nil
        await store.sync()
        XCTAssertTrue(store.state.pending.isEmpty)
        XCTAssertEqual(QueueMockAPI.calls.filter { $0 == "paintShift" }.count, 3)
        XCTAssertEqual(QueueMockAPI.writes, 1)
    }
    func testLocalWriteDuringSlowRefreshIsImmediateAndCannotBeOverwritten() async throws {
        let (directory, session) = try setup(); defer { QueueMockAPI.resume(); try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        QueueMockAPI.pauseMethod = "getLifeData"
        let refresh = Task { await store.sync() }
        for _ in 0..<100 {
            if QueueMockAPI.paused != nil { break }
            try await Task.sleep(nanoseconds: 10_000_000)
        }
        XCTAssertNotNil(QueueMockAPI.paused)
        XCTAssertTrue(store.syncing)
        XCTAssertFalse(store.busy)
        let payload = try HealthMeasurement.payload(day: CivilDate.day(), weight: "81.2", calories: "")
        try await store.perform("saveHealthEntry", payload)
        XCTAssertEqual(store.life.records("health").first?.amount("weight_kg"), 81.2)
        XCTAssertFalse(QueueMockAPI.calls.contains("saveHealthEntry"))
        QueueMockAPI.resume()
        await refresh.value
        XCTAssertEqual(store.life.records("health").first?.amount("weight_kg"), 81.2)
        XCTAssertEqual(store.state.pending.count, 1)
        await store.sync()
        XCTAssertTrue(store.state.pending.isEmpty)
        XCTAssertEqual(QueueMockAPI.calls.filter { $0 == "saveHealthEntry" }.count, 0)
    }
    func testQueuedHealthIsVisibleAndDurableBeforeAnyNetworkCall() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        let payload = try HealthMeasurement.payload(day: CivilDate.day(), weight: "78.4", calories: "2100")
        try await store.perform("saveHealthEntry", payload)
        XCTAssertTrue(QueueMockAPI.calls.isEmpty)
        XCTAssertFalse(store.busy)
        XCTAssertEqual(store.life.records("health").first?.amount("weight_kg"), 78.4)
        XCTAssertEqual(store.state.pending.count, 1)
        let restored = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        XCTAssertEqual(restored.state.pending.first?.payload, payload)
        XCTAssertEqual(restored.life.records("health").first?.integer("calories"), 2100)
        await restored.sync()
        XCTAssertTrue(restored.state.pending.isEmpty)
        XCTAssertEqual(QueueMockAPI.calls.filter { $0 == "saveHealthEntry" }.count, 0)
    }
    func testRapidShiftChangesStayOrderedAndSurviveAuthenticationFailure() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        for kind in ["morning", "night", "erase", "afternoon"] {
            try await store.perform("paintShift", ["day": .string(CivilDate.day()), "kind": .string(kind)])
        }
        XCTAssertEqual(store.shift(CivilDate.day()), .afternoon)
        XCTAssertEqual(store.state.pending.map { $0.payload.text("kind") }, ["morning", "night", "erase", "afternoon"])
        XCTAssertTrue(QueueMockAPI.calls.isEmpty)
        QueueMockAPI.failAll = true
        await store.sync(automatic: true)
        XCTAssertEqual(store.state.pending.count, 4)
        XCTAssertTrue(store.financialPending.isEmpty)
        XCTAssertEqual(store.shift(CivilDate.day()), .afternoon)
        XCTAssertNil(store.error)
        XCTAssertNotNil(store.notice)
        XCTAssertFalse(store.syncing)
    }
    func testUnacceptedLocalWriteCanOnlyBeDiscardedAfterServerRead() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        try await store.perform("paintShift", ["day": .string(CivilDate.day()), "kind": .string("night")])
        let id = try XCTUnwrap(store.state.pending.first?.id)
        QueueMockAPI.failAll = true
        do { try await store.discardLocalWrite(id); XCTFail("Serve una lettura confermata") } catch {}
        XCTAssertEqual(store.state.pending.count, 1)
        QueueMockAPI.failAll = false
        try await store.discardLocalWrite(id)
        XCTAssertTrue(store.state.pending.isEmpty)
        XCTAssertNil(store.shift(CivilDate.day()))
    }
    func testDemoCannotPublishShifts() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        do { _ = try await store.updateShiftCalendar("publishShiftCalendar", month: "2026-10"); XCTFail("La demo non può pubblicare") }
        catch { XCTAssertTrue(QueueMockAPI.calls.isEmpty) }
    }
    private func setup() throws -> (URL, URLSession) {
        QueueMockAPI.lock.lock(); QueueMockAPI.writes = 0; QueueMockAPI.failAfterWrite = false; QueueMockAPI.failAll = false; QueueMockAPI.calls = []; QueueMockAPI.timeoutOnce = nil; QueueMockAPI.pauseMethod = nil; QueueMockAPI.paused = nil; QueueMockAPI.rejectMethod = nil; QueueMockAPI.lock.unlock()
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let config = URLSessionConfiguration.ephemeral; config.protocolClasses = [QueueMockAPI.self]
        return (directory, URLSession(configuration: config))
    }
    private var payload: Record { ["requestId": .string("queue-finance-12345678"), "amount": .number(2), "name": .string("Test"), "category": .string("Altro"), "date": .string(CivilDate.day())] }
}
