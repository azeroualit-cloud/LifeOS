import XCTest
@testable import LifeOSProbe

final class NativeHealthLegacyTests: XCTestCase {
    func testLocalRecordsPreserveMissingFieldsAndRejectInvalidDates() {
        let rows: [Record] = [
            ["day": .string("2026-10-20"), "weight_kg": .number(81.2)],
            ["day": .string("2026-10-20"), "calories": .number(0)],
            ["day": .string("2026-02-30"), "weight_kg": .number(80)],
            ["day": .string("2026-10-21"), "weight_kg": .number(-1)]
        ]
        let result = NativeHealthLegacy.days(rows)
        XCTAssertEqual(result.count, 1)
        XCTAssertEqual(result.first?.weight, 81.2)
        XCTAssertEqual(result.first?.calories, 0)
    }
    @MainActor func testLocalMeasurementsRemainVisibleWithoutHealthKitAccess() {
        let health = NativeHealthStore()
        health.setLegacyRecords([["day": .string("2026-10-20"), "weight_kg": .number(81.2)]])
        XCTAssertEqual(health.days.first?.weight, 81.2)
        XCTAssertEqual(health.localDays, health.days)
        health.setLegacyRecords([])
        XCTAssertTrue(health.days.isEmpty)
    }
}
