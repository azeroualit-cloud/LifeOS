import XCTest
@testable import LifeOSProbe

final class NativeShiftProgressTests: XCTestCase {
    private func time(_ value: String) -> Date { ISO8601DateFormatter().date(from: value)! }
    func testTwoHourSectionsAndOnlyLatestCelebrationOnce() {
        let now = time("2026-10-30T11:00:00+01:00")
        let span = NativeShiftSpan.active(now: now, today: .morning, previous: nil)!
        XCTAssertEqual(span.count, 4)
        XCTAssertEqual(span.fraction(2, now: now), 0.5, accuracy: 0.001)
        let suite = "shift-test-" + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        XCTAssertEqual(span.celebration(now: now, defaults: defaults), 1)
        XCTAssertNil(span.celebration(now: now, defaults: defaults))
    }
    func testNightContinuesIntoRestDayAndEndsAtSix() {
        XCTAssertNotNil(NativeShiftSpan.active(now: time("2026-10-30T05:00:00+01:00"), today: .rest, previous: .night))
        XCTAssertNil(NativeShiftSpan.active(now: time("2026-10-30T06:00:00+01:00"), today: .rest, previous: .night))
        XCTAssertNil(NativeShiftSpan.active(now: time("2026-10-30T12:00:00+01:00"), today: .holiday, previous: nil))
    }
    func testClockChangeKeepsSixAMEndAndProportionalLastSection() {
        let span = NativeShiftSpan.active(now: time("2026-10-25T04:00:00+01:00"), today: .rest, previous: .night)!
        XCTAssertEqual(span.duration, 9 * 3600)
        XCTAssertEqual(span.count, 5)
        XCTAssertEqual(CivilDate.calendar.component(.hour, from: span.end), 6)
    }
}
