import Foundation
import XCTest
@testable import LifeOSProbe

final class NativeWeightTransferTests: XCTestCase {
    private let id = "646EF0F9-DB18-4082-AF8C-E6CC20CE9958"
    func testLinkPreparesExactWeightAndTimestampWithStableIdentity() throws {
        let now = Date(timeIntervalSince1970: 1_792_224_000)
        let url = try XCTUnwrap(URL(string: "lifeos://weight?id=\(id)&kg=80.235&at=1792220000000"))
        let first = try NativeWeightTransfer(url: url, now: now), second = try NativeWeightTransfer(url: url, now: now)
        XCTAssertEqual(first.id, second.id); XCTAssertEqual(first.kilograms, 80.235)
        XCTAssertEqual(first.date.timeIntervalSince1970, 1_792_220_000)
    }
    func testRejectsMalformedDuplicateAndFutureInputsBeforeOpeningTheEditor() {
        for value in ["https://weight?id=\(id)&kg=80&at=1", "lifeos://weight?id=\(id)&id=\(id)&kg=80&at=1", "lifeos://weight?id=\(id)&kg=NaN&at=1", "lifeos://weight?id=\(id)&kg=501&at=1", "lifeos://weight?id=\(id)&kg=0&at=1", "lifeos://weight?id=\(id)&kg=80&at=999999999999999", "lifeos://weight?id=bad&kg=80&at=1", "lifeos://weight/path?id=\(id)&kg=80&at=1"] {
            XCTAssertThrowsError(try NativeWeightTransfer(url: URL(string: value)!), value)
        }
    }
}
