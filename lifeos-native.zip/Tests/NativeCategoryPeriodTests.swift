import XCTest
@testable import LifeOSProbe

final class NativeCategoryPeriodTests: XCTestCase {
    func testDedicatedPeriodRequiresEveryMonthAndStoresAtomically() throws {
        var cache = NativeCategoryPeriodCache()
        let months = NativeCategoryPeriod.months(ending: "2026-10", count: 12)
        let values = months.map { month in JSONValue.object(["month": .string(month), "categories": .array([.object(["name": .string("Palestra"), "amount": .number(30)])])]) }
        XCTAssertThrowsError(try cache.storePeriod(.object(["months": .array(Array(values.dropLast()))]), ending: "2026-10", count: 12))
        XCTAssertEqual(cache.missing(in: months).count, 12)
        try cache.storePeriod(.object(["months": .array(values)]), ending: "2026-10", count: 12)
        XCTAssertEqual(try cache.aggregate(months: months).first?.amount("amount"), 360)
    }
    private func row(_ name: String, _ amount: Double) -> Record { ["name": .string(name), "amount": .number(amount)] }
    func testRetryRetainsSuccessfulMonthsAndLoadsOnlyMissingOnes() throws {
        var cache = NativeCategoryPeriodCache(); cache.prepare(scope: "server-A|revision-1")
        let months = ["2026-01", "2026-02", "2026-03"]
        try cache.store([row("Casa", 100)], month: months[0])
        XCTAssertThrowsError(try cache.store(response: .object([:]), month: months[1]))
        XCTAssertEqual(cache.missing(in: months), [months[1], months[2]])
        XCTAssertThrowsError(try cache.aggregate(months: months), "Never display a partial period as complete")
        try cache.store([row("Casa", -20)], month: months[1])
        try cache.store([], month: months[2])
        XCTAssertEqual(try cache.aggregate(months: months).first?.amount("amount"), 80)
        cache.prepare(scope: "server-A|revision-1")
        XCTAssertTrue(cache.missing(in: months).isEmpty)
        cache.prepare(scope: "server-B|revision-1")
        XCTAssertEqual(cache.missing(in: months), months)
    }
    func testCategoryValidationIgnoresLargeUnrelatedSnapshotFields() throws {
        let response: JSONValue = .object([
            "categories": .array([.object(row("Casa", 20))]),
            "unrelatedHistory": .string(String(repeating: "x", count: 5_100_000))
        ])
        var cache = NativeCategoryPeriodCache()
        try cache.store(response: response, month: "2026-01")
        XCTAssertEqual(try cache.aggregate(months: ["2026-01"]).first?.amount("amount"), 20)
        XCTAssertThrowsError(try cache.store(response: .object(["categories": .array([.object(row(" ", 1))])]), month: "2026-02"))
        XCTAssertEqual(cache.missing(in: ["2026-01", "2026-02"]), ["2026-02"])
    }
    func testMonthAxisShowsMonthAndShortYearAcrossYearBoundary() {
        let months = NativeCategoryPeriod.months(ending: "2026-04", count: 12)
        let ticks = NativeFinanceMonthAxis.ticks(months)
        XCTAssertTrue(ticks.contains("2026-01"))
        XCTAssertTrue(ticks.contains(months.first!))
        XCTAssertTrue(ticks.contains(months.last!))
        XCTAssertLessThan(ticks.count, 12)
        XCTAssertEqual(NativeFinanceMonthAxis.label("2025-12"), "dic\n25")
        XCTAssertEqual(NativeFinanceMonthAxis.label("2026-01"), "gen\n26")
        XCTAssertEqual(NativeFinanceMonthAxis.label("2026-13"), "—")
        XCTAssertEqual(NativeFinanceMonthAxis.ticks(["2026-02", "2026-01", "2026-01"]), ["2026-01", "2026-02"])
    }
    func testWindowsIncludeSelectedMonthAndCrossYear() {
        XCTAssertEqual(NativeCategoryPeriod.months(ending: "2026-01", count: 3), ["2025-11", "2025-12", "2026-01"])
        XCTAssertEqual(NativeCategoryPeriod.months(ending: "2026-01", count: 6).first, "2025-08")
        XCTAssertEqual(NativeCategoryPeriod.months(ending: "2026-01", count: 12).first, "2025-02")
        XCTAssertTrue(NativeCategoryPeriod.months(ending: "2026-13", count: 3).isEmpty)
        XCTAssertTrue(NativeCategoryPeriod.months(ending: "2026-01", count: 1).isEmpty)
    }
    func testAddsSameCategoryAcrossMonthsInCentsAndIgnoresOutsideWindow() throws {
        let months = ["2026-01", "2026-02", "2026-03"]
        let snapshots = [months[0]: [row(" Casa ", 0.10)], months[1]: [row("Casa", 0.20)], months[2]: [row("Casa", 12.34), row("Cibo", 100)], "2025-12": [row("Casa", 9000)]]
        let result = try NativeCategoryPeriod.aggregate(snapshots, months: months)
        XCTAssertEqual(result.map { $0.text("name") }, ["Cibo", "Casa"])
        XCTAssertEqual(result[1].amount("amount"), 12.64, accuracy: 0.000001)
    }
    func testSignedMonthlyAdjustmentsAreNettedBeforeFiltering() throws {
        let result = try NativeCategoryPeriod.aggregate(["2026-01": [row("Casa", 100), row("Auto", 10)], "2026-02": [row("Casa", -20), row("Auto", -10)]], months: ["2026-01", "2026-02"])
        XCTAssertEqual(result.count, 1); XCTAssertEqual(result[0].amount("amount"), 80)
    }
    func testMissingMonthIsDifferentFromCompleteEmptyMonths() throws {
        XCTAssertThrowsError(try NativeCategoryPeriod.aggregate(["2026-01": []], months: ["2026-01", "2026-02"]))
        XCTAssertEqual(try NativeCategoryPeriod.aggregate(["2026-01": [], "2026-02": []], months: ["2026-01", "2026-02"]), [])
        XCTAssertThrowsError(try NativeCategoryPeriod.aggregate(["2026-01": []], months: ["2026-01", "2026-01"]))
    }
    func testRejectsNonfiniteOverflowAndInvalidCategoryValues() {
        for amount in [Double.nan, .infinity, 1e300] {
            XCTAssertThrowsError(try NativeCategoryPeriod.aggregate(["2026-01": [row("Casa", amount)]], months: ["2026-01"]))
        }
        XCTAssertThrowsError(try NativeCategoryPeriod.aggregate(["2026-01": [row(" ", 1)]], months: ["2026-01"]))
        XCTAssertThrowsError(try NativeCategoryPeriod.aggregate(["2026-01": [["name": .string("Casa"), "amount": .string("12")]]], months: ["2026-01"]))
    }
}
