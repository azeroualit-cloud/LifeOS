import XCTest
@testable import LifeOSProbe

final class NativeCategoryPeriodTests: XCTestCase {
    private func row(_ name: String, _ amount: Double) -> Record { ["name": .string(name), "amount": .number(amount)] }
    func testWindowsIncludeSelectedMonthAndCrossYear() {
        XCTAssertEqual(NativeCategoryPeriod.months(ending: "2026-01", count: 3), ["2025-11", "2025-12", "2026-01"])
        XCTAssertEqual(NativeCategoryPeriod.months(ending: "2026-01", count: 6).first, "2025-08")
        XCTAssertEqual(NativeCategoryPeriod.months(ending: "2026-01", count: 12).first, "2025-02")
        XCTAssertTrue(NativeCategoryPeriod.months(ending: "2026-13", count: 3).isEmpty)
        XCTAssertTrue(NativeCategoryPeriod.months(ending: "2026-01", count: 1).isEmpty)
    }
    func testAddsSameCategoryAcrossMonthsInCentsAndIgnoresOutsideWindow() throws {
        let months = ["2026-01", "2026-02", "2026-03"]
        let snapshots = [months[0]: [row(" Casa ", 0.10)], months[1]: [row("Casa", 0.20)], months[2]: [row("Casa", 12.34), row("Cibo", 100)], "2025-12": [row("Casa", 9000)]]
        let result = try NativeCategoryPeriod.aggregate(snapshots, months: months)
        XCTAssertEqual(result.map { $0.text("name") }, ["Cibo", "Casa"])
        XCTAssertEqual(result[1].amount("amount"), 12.64, accuracy: 0.000001)
    }
    func testSignedMonthlyAdjustmentsAreNettedBeforeFiltering() throws {
        let result = try NativeCategoryPeriod.aggregate(["2026-01": [row("Casa", 100), row("Auto", 10)], "2026-02": [row("Casa", -20), row("Auto", -10)]], months: ["2026-01", "2026-02"])
        XCTAssertEqual(result.count, 1); XCTAssertEqual(result[0].amount("amount"), 80)
    }
    func testMissingMonthIsDifferentFromCompleteEmptyMonths() throws {
        XCTAssertThrowsError(try NativeCategoryPeriod.aggregate(["2026-01": []], months: ["2026-01", "2026-02"]))
        XCTAssertEqual(try NativeCategoryPeriod.aggregate(["2026-01": [], "2026-02": []], months: ["2026-01", "2026-02"]), [])
        XCTAssertThrowsError(try NativeCategoryPeriod.aggregate(["2026-01": []], months: ["2026-01", "2026-01"]))
    }
    func testRejectsNonfiniteOverflowAndInvalidCategoryValues() {
        for amount in [Double.nan, .infinity, 1e300] {
            XCTAssertThrowsError(try NativeCategoryPeriod.aggregate(["2026-01": [row("Casa", amount)]], months: ["2026-01"]))
        }
        XCTAssertThrowsError(try NativeCategoryPeriod.aggregate(["2026-01": [row(" ", 1)]], months: ["2026-01"]))
        XCTAssertThrowsError(try NativeCategoryPeriod.aggregate(["2026-01": [["name": .string("Casa"), "amount": .string("12")]]], months: ["2026-01"]))
    }
}
