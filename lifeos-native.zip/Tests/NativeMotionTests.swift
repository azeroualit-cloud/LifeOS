import SwiftUI
import XCTest
@testable import LifeOSProbe

final class NativeMotionTests: XCTestCase {
    func testNormalLaunchUsesSystemPreference() {
        let values = EnvironmentValues()
        XCTAssertFalse(values.nativeForceReduceMotion)
        XCTAssertEqual(values.nativeReduceMotion, values.accessibilityReduceMotion)
    }

    func testOverrideIsAdditiveAndCanBeReset() {
        var values = EnvironmentValues()
        values.nativeForceReduceMotion = true
        #if DEBUG
        XCTAssertTrue(values.nativeReduceMotion)
        #else
        XCTAssertEqual(values.nativeReduceMotion, values.accessibilityReduceMotion)
        #endif
        values.nativeForceReduceMotion = false
        XCTAssertEqual(values.nativeReduceMotion, values.accessibilityReduceMotion)
    }
}
