import Foundation
import XCTest
@testable import LifeOSProbe

private final class MockAPI: URLProtocol {
    static let lock = NSLock()
    static var writes = 0
    static var failAfterWrite = false
    static var failAll = false
    static var calls: [String] = []
    static var timeoutOnce: String?
    static var rejectMethod: String?
    static var pauseMethod: String?
    static var paused: MockAPI?
    private var deferredResponse: (HTTPURLResponse, String)?
    override class func canInit(with request: URLRequest) -> Bool { request.url?.host == "lifeos-test.invalid" }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        Self.lock.lock()
        let method = request.url!.lastPathComponent
        Self.calls.append(method)
        if Self.timeoutOnce == method {
            Self.timeoutOnce = nil; Self.lock.unlock()
            client?.urlProtocol(self, didFailWithError: URLError(.timedOut)); return
        }
        var status = 200
        var text = "{}"
        if Self.failAll { status = 401; text = "Sessione scaduta" }
        else if Self.rejectMethod == method { status = 400; text = "Modifica rifiutata" }
        else if ["setTaskStatus", "setRoutineCheck", "paintShift", "saveHealthEntry", "setEventOccurrence"].contains(method) { text = "true" }
        else if method == "saveTransaction" { Self.writes += 1; text = "true" }
        else if ["getShiftCalendar", "publishShiftCalendar", "rotateShiftCalendarLink"].contains(method) { text = #"{"path":"/calendar/turni/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.ics","publishedAt":"2026-10-23T12:00:00Z"}"# }
        else if method == "getLifeData" { text = #"{"tasks":[],"categories":[],"routines":[],"events":[],"shifts":[],"upcomingEvents":[]}"# }
        else if method == "getExtraPlan" { text = #"{"allocations":[],"links":[]}"# }
        else if method == "getFinanceData" || method == "getFinanceOverview" {
            if Self.failAfterWrite && Self.writes > 0 { Self.failAfterWrite = false; status = 500; text = "Aggiornamento temporaneamente non disponibile" }
            else { text = #"{"summary":{"budget":1000,"committedCurrent":200,"remainingFree":800},"transactions":[],"extraPlan":{"allocations":[],"links":[]}}"# }
        }
        Self.lock.unlock()
        let response = HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: nil, headerFields: ["Content-Type": status == 200 ? "application/json" : "text/plain", "Set-Cookie": method == "login" && status == 200 ? "liquidita_session=mock-session; Path=/; Max-Age=3600; Secure; HttpOnly; SameSite=Strict" : "", "X-LifeOS-Data-Source": "shared"])!
        Self.lock.lock()
        if Self.pauseMethod == method {
            deferredResponse = (response, text); Self.paused = self; Self.lock.unlock(); return
        }
        Self.lock.unlock()
        deliver(response, text)
    }
    static func resume() {
        lock.lock(); let request = paused; paused = nil; pauseMethod = nil; lock.unlock()
        if let request, let (response, text) = request.deferredResponse { request.deliver(response, text) }
    }
    private func deliver(_ response: HTTPURLResponse, _ text: String) {
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(text.utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

@MainActor final class NativeStoreTests: XCTestCase {
    func testShiftPublicationDoesNotRefreshFinanceOrRetryWrites() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        let result = try await store.updateShiftCalendar("publishShiftCalendar", month: "2026-10")
        XCTAssertFalse(result.text("path").isEmpty)
        XCTAssertEqual(MockAPI.calls, ["publishShiftCalendar"])
        XCTAssertFalse(store.busy)
        MockAPI.timeoutOnce = "publishShiftCalendar"
        do {
            _ = try await store.updateShiftCalendar("publishShiftCalendar", month: "2026-10")
            XCTFail("Un timeout deve restare visibile")
        } catch { XCTAssertEqual((error as? URLError)?.code, .timedOut) }
        XCTAssertEqual(MockAPI.calls.filter { $0 == "publishShiftCalendar" }.count, 2)
        XCTAssertFalse(store.busy)
        _ = try await store.updateShiftCalendar("publishShiftCalendar", month: "2026-10")
        XCTAssertEqual(MockAPI.calls.count, 3)
    }
    func testRejectedSetterPreservesOrderForSameKeyButDoesNotBlockFinance() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        for kind in ["morning", "night"] { try await store.perform("paintShift", ["day": .string(CivilDate.day()), "kind": .string(kind)]) }
        try await store.perform("saveTransaction", payload)
        MockAPI.rejectMethod = "paintShift"
        await store.sync()
        XCTAssertEqual(MockAPI.calls.filter { $0 == "paintShift" }.count, 1)
        XCTAssertEqual(MockAPI.writes, 1)
        XCTAssertEqual(store.state.pending.map(\.method), ["paintShift", "paintShift"])
        XCTAssertEqual(store.shift(CivilDate.day()), .night)
        MockAPI.rejectMethod = nil
        await store.sync()
        XCTAssertTrue(store.state.pending.isEmpty)
        XCTAssertEqual(MockAPI.calls.filter { $0 == "paintShift" }.count, 3)
        XCTAssertEqual(MockAPI.writes, 1)
    }
    func testLocalWriteDuringSlowRefreshIsImmediateAndCannotBeOverwritten() async throws {
        let (directory, session) = try setup(); defer { MockAPI.resume(); try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        MockAPI.pauseMethod = "getLifeData"
        let refresh = Task { await store.sync() }
        for _ in 0..<100 {
            if MockAPI.paused != nil { break }
            try await Task.sleep(nanoseconds: 10_000_000)
        }
        XCTAssertNotNil(MockAPI.paused)
        XCTAssertTrue(store.syncing)
        XCTAssertFalse(store.busy)
        let payload = try HealthMeasurement.payload(day: CivilDate.day(), weight: "81.2", calories: "")
        try await store.perform("saveHealthEntry", payload)
        XCTAssertEqual(store.life.records("health").first?.amount("weight_kg"), 81.2)
        XCTAssertFalse(MockAPI.calls.contains("saveHealthEntry"))
        MockAPI.resume()
        await refresh.value
        XCTAssertEqual(store.life.records("health").first?.amount("weight_kg"), 81.2)
        XCTAssertEqual(store.state.pending.count, 1)
        await store.sync()
        XCTAssertTrue(store.state.pending.isEmpty)
        XCTAssertEqual(MockAPI.calls.filter { $0 == "saveHealthEntry" }.count, 1)
    }
    func testQueuedHealthIsVisibleAndDurableBeforeAnyNetworkCall() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        let payload = try HealthMeasurement.payload(day: CivilDate.day(), weight: "78.4", calories: "2100")
        try await store.perform("saveHealthEntry", payload)
        XCTAssertTrue(MockAPI.calls.isEmpty)
        XCTAssertFalse(store.busy)
        XCTAssertEqual(store.life.records("health").first?.amount("weight_kg"), 78.4)
        XCTAssertEqual(store.state.pending.count, 1)
        let restored = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        XCTAssertEqual(restored.state.pending.first?.payload, payload)
        XCTAssertEqual(restored.life.records("health").first?.integer("calories"), 2100)
        await restored.sync()
        XCTAssertTrue(restored.state.pending.isEmpty)
        XCTAssertEqual(MockAPI.calls.filter { $0 == "saveHealthEntry" }.count, 1)
    }
    func testRapidShiftChangesStayOrderedAndSurviveAuthenticationFailure() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        for kind in ["morning", "night", "erase", "afternoon"] {
            try await store.perform("paintShift", ["day": .string(CivilDate.day()), "kind": .string(kind)])
        }
        XCTAssertEqual(store.shift(CivilDate.day()), .afternoon)
        XCTAssertEqual(store.state.pending.map { $0.payload.text("kind") }, ["morning", "night", "erase", "afternoon"])
        XCTAssertTrue(MockAPI.calls.isEmpty)
        MockAPI.failAll = true
        await store.sync(automatic: true)
        XCTAssertEqual(store.state.pending.count, 4)
        XCTAssertTrue(store.financialPending.isEmpty)
        XCTAssertEqual(store.shift(CivilDate.day()), .afternoon)
        XCTAssertNil(store.error)
        XCTAssertNotNil(store.notice)
        XCTAssertFalse(store.syncing)
    }
    func testUnacceptedLocalWriteCanOnlyBeDiscardedAfterServerRead() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        try await store.perform("paintShift", ["day": .string(CivilDate.day()), "kind": .string("night")])
        let id = try XCTUnwrap(store.state.pending.first?.id)
        MockAPI.failAll = true
        do { try await store.discardLocalWrite(id); XCTFail("Serve una lettura confermata") } catch {}
        XCTAssertEqual(store.state.pending.count, 1)
        MockAPI.failAll = false
        try await store.discardLocalWrite(id)
        XCTAssertTrue(store.state.pending.isEmpty)
        XCTAssertNil(store.shift(CivilDate.day()))
    }
    func testDemoCannotPublishShifts() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        do { _ = try await store.updateShiftCalendar("publishShiftCalendar", month: "2026-10"); XCTFail("La demo non può pubblicare") }
        catch { XCTAssertTrue(MockAPI.calls.isEmpty) }
    }
    private func setup() throws -> (URL, URLSession) {
        MockAPI.lock.lock(); MockAPI.writes = 0; MockAPI.failAfterWrite = false; MockAPI.failAll = false; MockAPI.calls = []; MockAPI.timeoutOnce = nil; MockAPI.pauseMethod = nil; MockAPI.paused = nil; MockAPI.rejectMethod = nil; MockAPI.lock.unlock()
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let config = URLSessionConfiguration.ephemeral; config.protocolClasses = [MockAPI.self]
        return (directory, URLSession(configuration: config))
    }
    func testDashboardCapsHighlightsAtThreeAndPrioritizesSevenDayEvents() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        store.seedVisualTasks()
        XCTAssertLessThanOrEqual(store.highlights.count, 3)
        XCTAssertEqual(store.highlights.first?.text("highlightKind"), "event")
        XCTAssertTrue(store.highlights.filter { $0.text("highlightKind") == "task" }.allSatisfy { $0.text("status") == "todo" })
    }
    private var payload: Record { ["requestId": .string("regression-12345678"), "type": .string("Spesa"), "name": .string("Spesa da conservare"), "amount": .number(2), "account": .string("Trade Republic"), "category": .string("Altro"), "date": .string(CivilDate.day())] }
    func testNativeSignInReceivesSecureCookieWithoutLoadingWebPage() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        try await store.signIn(password: "not-a-real-password-for-unit-tests")
        XCTAssertEqual(MockAPI.calls, ["login"])
        XCTAssertTrue(store.sharedDatabase)
        let backup = String(decoding: try store.backupData(), as: UTF8.self)
        XCTAssertFalse(backup.contains("not-a-real-password"))
        XCTAssertFalse(backup.contains("mock-session"))
    }
    func testRefreshUsesOneLightFinanceReadAndEmbeddedPlan() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        await store.sync()
        XCTAssertNil(store.error)
        XCTAssertEqual(MockAPI.calls.filter { $0 == "getLifeData" }.count, 1)
        XCTAssertEqual(MockAPI.calls.filter { $0 == "getFinanceOverview" }.count, 1)
        XCTAssertFalse(MockAPI.calls.contains("getFinanceData"))
        XCTAssertFalse(MockAPI.calls.contains("getExtraPlan"))
    }
    func testLifeMutationDoesNotFetchFinanceOrAnalytics() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        await store.sync()
        let financeDate = store.state.financeRefreshedAt
        MockAPI.calls = []
        try await store.perform("setTaskStatus", ["id": .int(1), "status": .string("done")])
        await store.sync(scope: .life)
        XCTAssertEqual(MockAPI.calls, ["setTaskStatus", "getLifeData"])
        XCTAssertEqual(store.state.financeRefreshedAt, financeDate)
    }
    func testTransientReadTimeoutRetriesOnceButMutationIsNeverRetriedAutomatically() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        MockAPI.timeoutOnce = "getLifeData"
        _ = try await store.read("getLifeData")
        XCTAssertEqual(MockAPI.calls.filter { $0 == "getLifeData" }.count, 2)
        MockAPI.timeoutOnce = "saveTransaction"
        do { _ = try await store.read("saveTransaction", args: [.object(payload)]); XCTFail("Expected timeout") }
        catch { XCTAssertEqual((error as? URLError)?.code, .timedOut) }
        XCTAssertEqual(MockAPI.calls.filter { $0 == "saveTransaction" }.count, 1)
    }
    func testAutomaticAuthenticationFailureKeepsCacheAndQueueWithoutModalError() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        MockAPI.failAll = true
        try await store.perform("saveTransaction", payload)
        await store.sync(automatic: true)
        XCTAssertNil(store.error)
        XCTAssertNotNil(store.notice)
        XCTAssertEqual(store.state.pending.first?.payload, payload)
        XCTAssertFalse(store.state.pending.first!.accepted)
    }
    func testFirstConnectionPreservesLocalTwoEuroWriteAcrossRelaunchThenSendsOnce() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let initial = NativeArchive(pending: [PendingWrite(id: "regression-12345678", method: "saveTransaction", payload: payload)], demo: false)
        try JSONEncoder().encode(initial).write(to: directory.appendingPathComponent("lifeos-native-v2.json"))
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        XCTAssertEqual(store.state.pending.first?.payload, payload)
        XCTAssertEqual(MockAPI.writes, 0)
        let relaunched = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        XCTAssertEqual(relaunched.state.endpoint, "https://lifeos-test.invalid")
        XCTAssertEqual(relaunched.state.pending.first?.id, "regression-12345678")
        XCTAssertEqual(relaunched.state.pending.first?.payload.amount("amount"), 2)
        await relaunched.sync()
        XCTAssertNil(relaunched.error)
        XCTAssertTrue(relaunched.state.pending.isEmpty)
        await relaunched.sync()
        XCTAssertEqual(MockAPI.writes, 1)
    }
    func testConfirmedWriteWithoutKnownServerCannotBeAssignedElsewhere() throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let initial = NativeArchive(pending: [PendingWrite(id: "regression-12345678", method: "saveTransaction", payload: payload, accepted: true)], demo: false)
        let file = directory.appendingPathComponent("lifeos-native-v2.json")
        try JSONEncoder().encode(initial).write(to: file)
        let original = try Data(contentsOf: file)
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        XCTAssertThrowsError(try store.configure("https://lifeos-test.invalid"))
        XCTAssertEqual(try Data(contentsOf: file), original)
    }
    func testConfiguringServerResetsDisplayedMonthsToTheNewArchive() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        await store.changeMonth(-1, finance: true)
        await store.changeMonth(1, finance: false)
        try store.configure("https://lifeos-test.invalid")
        XCTAssertEqual(store.financeMonth, store.state.financeMonth)
        XCTAssertEqual(store.calendarMonth, store.state.calendarMonth)
        XCTAssertEqual(store.financeMonth, CivilDate.month())
    }
    func testConfirmedWriteSurvivesFailedRefreshAndRelaunchWithoutResending() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        MockAPI.failAfterWrite = true
        try await store.perform("saveTransaction", payload)
        await store.sync(automatic: true)
        XCTAssertEqual(store.state.pending.count, 1)
        XCTAssertEqual(store.state.pending.first?.accepted, true)
        XCTAssertNotNil(store.notice)
        let relaunched = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        await relaunched.sync()
        XCTAssertTrue(relaunched.state.pending.isEmpty)
        XCTAssertNil(relaunched.error)
        XCTAssertEqual(MockAPI.writes, 1)
    }
    func testDemoSwitchAndRestoreKeepUnsentWriteAndEndpoint() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        try store.configure("https://lifeos-test.invalid")
        MockAPI.failAll = true
        try await store.perform("saveTransaction", payload)
        await store.sync(automatic: true)
        XCTAssertEqual(store.state.pending.count, 1)
        XCTAssertThrowsError(try store.configure("https://different-test.invalid"))
        try store.configure("https://lifeos-test.invalid/")
        try store.useDemo()
        XCTAssertTrue(store.isDemo)
        XCTAssertTrue(store.state.pending.isEmpty)
        let backup = try JSONDecoder().decode(JSONValue.self, from: store.backupData()).object
        XCTAssertEqual(backup.record("previous").records("pending").count, 1)
        try store.restoreConnection()
        XCTAssertFalse(store.isDemo)
        XCTAssertEqual(store.state.pending.first?.id, "regression-12345678")
        XCTAssertEqual(store.state.endpoint, "https://lifeos-test.invalid")
    }
    func testSnapshotImportPreservesExistingUnsentWrite() throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let initial = NativeArchive(pending: [PendingWrite(id: "regression-12345678", method: "saveTransaction", payload: payload)], demo: false)
        try JSONEncoder().encode(initial).write(to: directory.appendingPathComponent("lifeos-native-v2.json"))
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        let data = Data(#"{"summary":{"budget":1000,"committedCurrent":200,"remainingFree":800},"transactions":[]}"#.utf8)
        try store.importFinance(data)
        XCTAssertEqual(store.state.pending.first?.id, "regression-12345678")
        XCTAssertEqual(store.summary.amount("budget"), 1000)
    }
    func testMigrationKeepsLegacyQueueUUIDAndOriginalSQLite() throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let expense = try Input.expense(amount: "2", name: "Spesa del prototipo", category: "Altro", date: Date(), months: 1, treatment: "auto")
        let legacy = try Storage(folder: directory)
        try legacy.save(Archive(queue: [expense]))
        let store = NativeStore(directory: directory, session: session)
        XCTAssertFalse(store.isDemo)
        XCTAssertEqual(store.state.pending.first?.id, expense.requestId)
        XCTAssertEqual(store.state.pending.first?.payload.amount("amount"), 2)
        XCTAssertEqual(try legacy.load().queue.first?.requestId, expense.requestId)
    }
    func testCorruptArchiveIsNeverReplacedByDemoOrServerConfiguration() throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let file = directory.appendingPathComponent("lifeos-native-v2.json"), original = Data("JSON incompleto".utf8)
        try original.write(to: file)
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false, automaticallySyncsWrites: false)
        XCTAssertNotNil(store.error)
        XCTAssertThrowsError(try store.useDemo())
        XCTAssertThrowsError(try store.configure("https://lifeos-test.invalid"))
        XCTAssertEqual(try Data(contentsOf: file), original)
    }
}
