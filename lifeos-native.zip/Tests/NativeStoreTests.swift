import Foundation
import XCTest
@testable import LifeOSProbe

private final class MockAPI: URLProtocol {
    static let lock = NSLock()
    static var writes = 0
    static var failAfterWrite = false
    static var failAll = false
    override class func canInit(with request: URLRequest) -> Bool { request.url?.host == "lifeos-test.invalid" }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        Self.lock.lock()
        let method = request.url!.lastPathComponent
        var status = 200
        var text = "{}"
        if Self.failAll { status = 401; text = "Sessione scaduta" }
        else if method == "saveTransaction" { Self.writes += 1; text = "true" }
        else if method == "getLifeData" { text = #"{"tasks":[],"categories":[],"routines":[],"events":[],"shifts":[],"upcomingEvents":[]}"# }
        else if method == "getExtraPlan" { text = #"{"allocations":[],"links":[]}"# }
        else if method == "getFinanceData" {
            if Self.failAfterWrite && Self.writes > 0 { Self.failAfterWrite = false; status = 500; text = "Aggiornamento temporaneamente non disponibile" }
            else { text = #"{"summary":{"budget":1000,"committedCurrent":200,"remainingFree":800},"transactions":[]}"# }
        }
        Self.lock.unlock()
        let response = HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: nil, headerFields: ["Content-Type": status == 200 ? "application/json" : "text/plain"])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(text.utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

@MainActor final class NativeStoreTests: XCTestCase {
    private func setup() throws -> (URL, URLSession) {
        MockAPI.lock.lock(); MockAPI.writes = 0; MockAPI.failAfterWrite = false; MockAPI.failAll = false; MockAPI.lock.unlock()
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let config = URLSessionConfiguration.ephemeral; config.protocolClasses = [MockAPI.self]
        return (directory, URLSession(configuration: config))
    }
    private var payload: Record { ["requestId": .string("regression-12345678"), "type": .string("Spesa"), "name": .string("Spesa da conservare"), "amount": .number(2), "account": .string("Trade Republic"), "category": .string("Altro"), "date": .string(CivilDate.day())] }
    func testFirstConnectionPreservesLocalTwoEuroWriteAcrossRelaunchThenSendsOnce() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let initial = NativeArchive(pending: [PendingWrite(id: "regression-12345678", method: "saveTransaction", payload: payload)], demo: false)
        try JSONEncoder().encode(initial).write(to: directory.appendingPathComponent("lifeos-native-v2.json"))
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false)
        try store.configure("https://lifeos-test.invalid")
        XCTAssertEqual(store.state.pending.first?.payload, payload)
        XCTAssertEqual(MockAPI.writes, 0)
        let relaunched = NativeStore(directory: directory, session: session, migrateLegacy: false)
        XCTAssertEqual(relaunched.state.endpoint, "https://lifeos-test.invalid")
        XCTAssertEqual(relaunched.state.pending.first?.id, "regression-12345678")
        XCTAssertEqual(relaunched.state.pending.first?.payload.amount("amount"), 2)
        await relaunched.sync()
        XCTAssertNil(relaunched.error)
        XCTAssertTrue(relaunched.state.pending.isEmpty)
        await relaunched.sync()
        XCTAssertEqual(MockAPI.writes, 1)
    }
    func testConfirmedWriteWithoutKnownServerCannotBeAssignedElsewhere() throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let initial = NativeArchive(pending: [PendingWrite(id: "regression-12345678", method: "saveTransaction", payload: payload, accepted: true)], demo: false)
        let file = directory.appendingPathComponent("lifeos-native-v2.json")
        try JSONEncoder().encode(initial).write(to: file)
        let original = try Data(contentsOf: file)
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false)
        XCTAssertThrowsError(try store.configure("https://lifeos-test.invalid"))
        XCTAssertEqual(try Data(contentsOf: file), original)
    }
    func testConfiguringServerResetsDisplayedMonthsToTheNewArchive() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false)
        await store.changeMonth(-1, finance: true)
        await store.changeMonth(1, finance: false)
        try store.configure("https://lifeos-test.invalid")
        XCTAssertEqual(store.financeMonth, store.state.financeMonth)
        XCTAssertEqual(store.calendarMonth, store.state.calendarMonth)
        XCTAssertEqual(store.financeMonth, CivilDate.month())
    }
    func testConfirmedWriteSurvivesFailedRefreshAndRelaunchWithoutResending() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false)
        try store.configure("https://lifeos-test.invalid")
        MockAPI.failAfterWrite = true
        try await store.perform("saveTransaction", payload)
        XCTAssertEqual(store.state.pending.count, 1)
        XCTAssertEqual(store.state.pending.first?.accepted, true)
        XCTAssertNotNil(store.error)
        let relaunched = NativeStore(directory: directory, session: session, migrateLegacy: false)
        await relaunched.sync()
        XCTAssertTrue(relaunched.state.pending.isEmpty)
        XCTAssertNil(relaunched.error)
        XCTAssertEqual(MockAPI.writes, 1)
    }
    func testDemoSwitchAndRestoreKeepUnsentWriteAndEndpoint() async throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false)
        try store.configure("https://lifeos-test.invalid")
        MockAPI.failAll = true
        try await store.perform("saveTransaction", payload)
        XCTAssertEqual(store.state.pending.count, 1)
        XCTAssertThrowsError(try store.configure("https://different-test.invalid"))
        try store.configure("https://lifeos-test.invalid/")
        try store.useDemo()
        XCTAssertTrue(store.isDemo)
        XCTAssertTrue(store.state.pending.isEmpty)
        let backup = try JSONDecoder().decode(JSONValue.self, from: store.backupData()).object
        XCTAssertEqual(backup.record("previous").records("pending").count, 1)
        try store.restoreConnection()
        XCTAssertFalse(store.isDemo)
        XCTAssertEqual(store.state.pending.first?.id, "regression-12345678")
        XCTAssertEqual(store.state.endpoint, "https://lifeos-test.invalid")
    }
    func testSnapshotImportPreservesExistingUnsentWrite() throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let initial = NativeArchive(pending: [PendingWrite(id: "regression-12345678", method: "saveTransaction", payload: payload)], demo: false)
        try JSONEncoder().encode(initial).write(to: directory.appendingPathComponent("lifeos-native-v2.json"))
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false)
        let data = Data(#"{"summary":{"budget":1000,"committedCurrent":200,"remainingFree":800},"transactions":[]}"#.utf8)
        try store.importFinance(data)
        XCTAssertEqual(store.state.pending.first?.id, "regression-12345678")
        XCTAssertEqual(store.summary.amount("budget"), 1000)
    }
    func testMigrationKeepsLegacyQueueUUIDAndOriginalSQLite() throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let expense = try Input.expense(amount: "2", name: "Spesa del prototipo", category: "Altro", date: Date(), months: 1, treatment: "auto")
        let legacy = try Storage(folder: directory)
        try legacy.save(Archive(queue: [expense]))
        let store = NativeStore(directory: directory, session: session)
        XCTAssertFalse(store.isDemo)
        XCTAssertEqual(store.state.pending.first?.id, expense.requestId)
        XCTAssertEqual(store.state.pending.first?.payload.amount("amount"), 2)
        XCTAssertEqual(try legacy.load().queue.first?.requestId, expense.requestId)
    }
    func testCorruptArchiveIsNeverReplacedByDemoOrServerConfiguration() throws {
        let (directory, session) = try setup(); defer { try? FileManager.default.removeItem(at: directory); session.invalidateAndCancel() }
        let file = directory.appendingPathComponent("lifeos-native-v2.json"), original = Data("JSON incompleto".utf8)
        try original.write(to: file)
        let store = NativeStore(directory: directory, session: session, migrateLegacy: false)
        XCTAssertNotNil(store.error)
        XCTAssertThrowsError(try store.useDemo())
        XCTAssertThrowsError(try store.configure("https://lifeos-test.invalid"))
        XCTAssertEqual(try Data(contentsOf: file), original)
    }
}
