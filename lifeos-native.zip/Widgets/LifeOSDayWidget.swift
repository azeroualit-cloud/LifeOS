import SwiftUI
import WidgetKit

struct DayEntry: TimelineEntry {
    let date: Date
    let snapshot: WidgetSnapshot
}
struct DayProvider: TimelineProvider {
    func placeholder(in context: Context) -> DayEntry { DayEntry(date: Date(), snapshot: .empty) }
    func getSnapshot(in context: Context, completion: @escaping (DayEntry) -> Void) {
        completion(DayEntry(date: Date(), snapshot: WidgetStorage.load()))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<DayEntry>) -> Void) {
        let now = Date(), snapshot = WidgetStorage.load()
        let today = CivilDate.day(now)
        // Midnight entries roll the seven days forward, even if the app stays closed.
        let entries = [DayEntry(date: now, snapshot: snapshot)] + (1...7).map {
            DayEntry(date: CivilDate.date(CivilDate.adding($0, to: today)), snapshot: snapshot)
        }
        completion(Timeline(entries: entries, policy: .after(now.addingTimeInterval(3600))))
    }
}

struct DayWidgetView: View {
    let entry: DayEntry
    private let gap = NativeDesign.Space.xs
    private var snapshot: WidgetSnapshot { entry.snapshot }
    var body: some View {
        VStack(alignment: .leading, spacing: gap) {
            HStack(spacing: gap) {
                Text(snapshot.demo ? "TURNI · DEMO" : "TURNI").font(.caption2.weight(.semibold)).lineLimit(1)
                if !snapshot.demo && snapshot.isStale(at: entry.date) {
                    Image(systemName: "arrow.clockwise").font(.caption2)
                        .accessibilityLabel("Dati da aggiornare nell’app")
                }
                Spacer(minLength: NativeDesign.Space.none)
                Button(intent: WidgetQuickAddIntent()) {
                    Image(systemName: "plus.circle.fill").font(.title3)
                        .frame(width: NativeDesign.Layout.touchTarget, height: NativeDesign.Layout.touchTarget)
                        .contentShape(Rectangle())
                }.buttonStyle(.plain).accessibilityLabel("Aggiungi evento o attività")
            }
            HStack(spacing: NativeDesign.Space.xxs) {
                ForEach(snapshot.days(at: entry.date), id: \.self) { day in
                    shiftColumn(day)
                }
            }
            Spacer(minLength: NativeDesign.Space.none)
            routines
            if snapshot.available {
                let counts = snapshot.counts(at: entry.date)
                HStack(spacing: gap) {
                    Image(systemName: "checkmark.circle")
                    Text("\(counts.today)")
                    Spacer(minLength: NativeDesign.Space.none)
                    Image(systemName: "exclamationmark.triangle")
                        .foregroundStyle(counts.overdue > 0 ? NativeDesign.warning : NativeDesign.secondary)
                    Text("\(counts.overdue)")
                }.font(.caption.weight(.medium)).monospacedDigit()
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("\(counts.today) attività oggi, \(counts.overdue) scadute. Ultimi dati salvati.")
            } else {
                Text("Apri Life OS per aggiornare").font(.caption2).foregroundStyle(NativeDesign.secondary)
            }
        }
        .padding(NativeDesign.Space.small)
        .containerBackground(NativeDesign.surface, for: .widget)
        .widgetURL(URL(string: "lifeos://dashboard"))
    }
    private func shiftColumn(_ day: String) -> some View {
        let kind = snapshot.shifts[day].flatMap(ShiftKind.init(rawValue:))
        let today = day == CivilDate.day(entry.date)
        let weekday = CivilDate.calendar.component(.weekday, from: CivilDate.date(day))
        let initial = ["D", "L", "M", "M", "G", "V", "S"][weekday - 1]
        return VStack(spacing: NativeDesign.Space.xxs) {
            Text(initial).foregroundStyle(NativeDesign.secondary)
            Text(kind?.letter ?? "–").fontWeight(.semibold)
                .foregroundStyle(Color.black)
                .frame(maxWidth: .infinity)
                .padding(.vertical, NativeDesign.Space.xs)
                .background(kind?.color ?? Color.gray.opacity(0.4), in: RoundedRectangle(cornerRadius: NativeDesign.badgeRadius))
        }.font(.caption2).frame(maxWidth: .infinity)
            .padding(.vertical, NativeDesign.Space.xxs)
            .overlay {
                RoundedRectangle(cornerRadius: NativeDesign.badgeRadius)
                    .strokeBorder(today ? Color.primary.opacity(0.7) : .clear, lineWidth: NativeDesign.Space.hairline)
            }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("\(today ? "Oggi, " : "")\(CivilDate.label(day)), \(kind?.title ?? "turno non disponibile")")
    }
    private var routines: some View {
        VStack(alignment: .leading, spacing: NativeDesign.Space.xxs) {
            let checks = snapshot.routineChecks(at: entry.date)
            HStack {
                Text("Abitudini")
                Spacer(minLength: NativeDesign.Space.none)
                Text(checks.map { "\($0.filter { $0 }.count)/\($0.count)" } ?? "–")
            }.font(.caption2).foregroundStyle(NativeDesign.secondary)
            if let checks, !checks.isEmpty {
                // At most seven marks; larger lists use a proportional bar and exact count.
                if checks.count <= 7 {
                    HStack(spacing: NativeDesign.Space.xxs) {
                        ForEach(Array(checks.enumerated()), id: \.offset) { _, checked in
                            Capsule().fill(checked ? NativeDesign.accent : NativeDesign.secondary.opacity(0.3))
                        }
                    }.frame(height: NativeDesign.Space.xs)
                } else {
                    ProgressView(value: Double(checks.filter { $0 }.count), total: Double(checks.count))
                        .tint(NativeDesign.accent)
                }
            }
        }.accessibilityElement(children: .ignore)
            .accessibilityLabel(snapshot.routineChecks(at: entry.date).map { "Abitudini: \($0.filter { $0 }.count) completate su \($0.count)" } ?? "Abitudini da aggiornare")
    }
}

@main struct LifeOSDayWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: WidgetStorage.kind, provider: DayProvider()) { DayWidgetView(entry: $0) }
            .configurationDisplayName("La giornata")
            .description("Sette turni, abitudini e attività di oggi. Il + aggiunge un evento o un’attività.")
            .supportedFamilies([.systemSmall])
            .contentMarginsDisabled()
    }
}

#if DEBUG
private func previewSnapshot() -> WidgetSnapshot {
    var a = NativeArchive()
    a.demo = true; a.routineDay = CivilDate.day(); a.refreshedAt = Date()
    let kinds = ["morning", "afternoon", "night", "rest", "rest", "morning", "afternoon"]
    a.life = [
        "routines": .array((0..<5).map { .object(["position": .int($0), "checked": .bool($0 < 3)]) }),
        "tasks": .array((0..<5).map { .object(["list_kind": .string("action"), "status": .string("todo"), "due_date": .string(CivilDate.adding($0 == 4 ? -1 : 0, to: CivilDate.day()))]) }),
        "shifts": .array(kinds.enumerated().map { .object(["day": .string(CivilDate.adding($0.offset, to: CivilDate.day())), "kind": .string($0.element)]) })
    ]
    return WidgetSnapshot(archive: a)
}
#Preview(as: .systemSmall) {
    LifeOSDayWidget()
} timeline: {
    DayEntry(date: Date(), snapshot: previewSnapshot())
}
#endif
