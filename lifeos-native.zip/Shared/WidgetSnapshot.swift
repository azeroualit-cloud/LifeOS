import Foundation

/// Deliberately contains no titles, financial data, endpoint or authentication.
struct WidgetSnapshot: Codable, Equatable {
    struct TaskDates: Codable, Equatable {
        let due: String
        let scheduled: String
    }
    let updatedAt: Date?
    let demo: Bool
    let routineDay: String
    let routines: [Bool]
    let shifts: [String: String]
    let tasks: [TaskDates]
    let available: Bool

    static let empty = WidgetSnapshot(updatedAt: nil, demo: false, routineDay: "", routines: [], shifts: [:], tasks: [], available: false)

    init(archive: NativeArchive) {
        updatedAt = archive.lifeRefreshedAt ?? (archive.demo ? archive.refreshedAt : nil)
        demo = archive.demo
        routineDay = archive.demo ? archive.routineDay : archive.life.text("today")
        routines = archive.life.records("routines").sorted { $0.amount("position") < $1.amount("position") }.map { $0.flag("checked") }
        shifts = archive.life.records("shifts").reduce(into: [:]) { result, row in
            if let kind = ShiftKind(rawValue: row.text("kind")), kind != .erase { result[row.text("day")] = kind.rawValue }
        }
        tasks = archive.life.records("tasks").filter { $0.text("list_kind") == "action" && $0.text("status") == "todo" }
            .map { TaskDates(due: $0.text("due_date"), scheduled: $0.text("scheduled_date")) }
        available = archive.life["tasks"] != nil && archive.life["routines"] != nil
    }
    private init(updatedAt: Date?, demo: Bool, routineDay: String, routines: [Bool], shifts: [String: String], tasks: [TaskDates], available: Bool) {
        self.updatedAt = updatedAt; self.demo = demo; self.routineDay = routineDay
        self.routines = routines; self.shifts = shifts; self.tasks = tasks; self.available = available
    }
    func days(at date: Date) -> [String] { (0..<7).map { CivilDate.adding($0, to: CivilDate.day(date)) } }
    func routineChecks(at date: Date) -> [Bool]? {
        guard available else { return nil }
        if routineDay == CivilDate.day(date) { return routines }
        // Demo routines reset daily; real checks remain unknown until the server confirms them.
        return demo ? routines.map { _ in false } : nil
    }
    func counts(at date: Date) -> (today: Int, overdue: Int) {
        let day = CivilDate.day(date)
        let overdue = tasks.filter { !$0.due.isEmpty && $0.due < day }.count
        let today = tasks.filter { ($0.due == day || $0.scheduled == day) && ($0.due.isEmpty || $0.due >= day) }.count
        return (today, overdue)
    }
    func isStale(at date: Date) -> Bool {
        guard let updatedAt else { return true }
        return date.timeIntervalSince(updatedAt) > 6 * 3600 || routineChecks(at: date) == nil
    }
}
