import Foundation

/// Both targets must retain this App Group when the IPA is signed.
enum WidgetStorage {
    static let group = "group.com.nas.lifeos.probe"
    static let kind = "LifeOSDayWidget"
    static func file() -> URL? {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group)?
            .appendingPathComponent("widget-day-v1.json")
    }
    static func load() -> WidgetSnapshot {
        guard let url = file(), let data = try? Data(contentsOf: url),
              let snapshot = try? JSONDecoder().decode(WidgetSnapshot.self, from: data) else { return .empty }
        return snapshot
    }
    @discardableResult static func save(_ snapshot: WidgetSnapshot) throws -> Bool {
        guard let url = file() else { throw Message(text: "Widget non collegato: la firma deve abilitare il gruppo condiviso Life OS.") }
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
        let data = try encoder.encode(snapshot)
        if let current = try? Data(contentsOf: url), current == data { return false }
        try data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        return true
    }
}
