import AppIntents
import Foundation

/// Runs in the containing app on iOS 17+, including a cold launch.
struct WidgetQuickAddIntent: AppIntent {
    static var title: LocalizedStringResource = "Aggiungi evento o attività"
    static var openAppWhenRun: Bool = true
    static let requestKey = "widget-quick-add-request"
    static let notification = Notification.Name("LifeOSWidgetQuickAdd")
    @MainActor func perform() async throws -> some IntentResult {
        UserDefaults.standard.set(true, forKey: Self.requestKey)
        NotificationCenter.default.post(name: Self.notification, object: nil)
        return .result()
    }
}
