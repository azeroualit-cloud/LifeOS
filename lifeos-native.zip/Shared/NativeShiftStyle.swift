import SwiftUI

extension ShiftKind {
    // Same hues as the original Life OS palette, with a restrained saturation increase.
    var color: Color {
        let light: UInt32, dark: UInt32
        switch self {
        case .morning: light = 0x8FACD9; dark = 0x639BCF
        case .afternoon: light = 0x9BCB83; dark = 0x6CAF7A
        case .night: light = 0x727780; dark = 0xADB2BC
        case .rest: light = 0xE79862; dark = 0xDF986D
        case .holiday: light = 0xA88B18; dark = 0xDEC34E
        case .erase: return .secondary
        }
        return Color(uiColor: UIColor { traits in
            let hex = traits.userInterfaceStyle == .dark ? dark : light
            return UIColor(red: Double((hex >> 16) & 255) / 255, green: Double((hex >> 8) & 255) / 255, blue: Double(hex & 255) / 255, alpha: 1)
        })
    }
    var symbol: String {
        switch self { case .morning: return "sunrise"; case .afternoon: return "sun.max"; case .night: return "moon"; case .rest: return "leaf"; case .holiday: return "sun.horizon"; case .erase: return "eraser" }
    }
}
