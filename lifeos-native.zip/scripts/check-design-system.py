"""Guard UI composition against new magic spacing/radii and fixed-size fonts."""
from pathlib import Path
import re, sys
root = Path(__file__).resolve().parent.parent
patterns = {
    'padding numerico: usa NativeDesign.Space/Layout': r'\.padding\((?:\.[A-Za-z]+,\s*)?\d+(?:\.\d+)?\)',
    'spacing numerico: usa NativeDesign.Space': r'\bspacing:\s*\d+(?:\.\d+)?\b',
    'raggio numerico: usa NativeDesign.*Radius': r'\bcornerRadius:\s*\d+(?:\.\d+)?\b',
    'inset numerico: usa NativeDesign.Space/Layout': r'\b(?:top|leading|bottom|trailing):\s*[1-9]\d*',
    'margine numerico: usa NativeDesign.Space/Layout': r'\.contentMargins\(\.[A-Za-z]+,\s*\d+',
    'font fisso: usa uno stile semantico iOS': r'\.font\(\.system\(size:',
}
errors = []
for path in sorted(path for folder in ['Sources', 'Shared', 'Widgets'] for path in (root/folder).glob('*.swift')):
    code = path.read_text()
    if 'import SwiftUI' not in code: continue
    for i,line in enumerate(code.splitlines(),1):
        if line.lstrip().startswith('//'): continue
        for message,pattern in patterns.items():
            if re.search(pattern,line): errors.append(f'{path.name}:{i}: {message}')
if errors:
    print('\n'.join(errors)); sys.exit(1)
print('DESIGN_SYSTEM_OK: nessun padding, spacing, raggio o font fisso fuori dai token.')
